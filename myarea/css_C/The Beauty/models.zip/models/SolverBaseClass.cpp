/// \file SolverBaseClass.cpp
/// Implementation file for base class for models

#include "stdafx.h"
#include "SolverBaseClass.h"


////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for SolverBaseClass.
///
////////////////////////////////////////////////////////////////////////////////////
SolverBaseClass::SolverBaseClass(void)
{
	m_pdA = NULL;
	m_pdB = NULL;
	m_pdX = NULL;
	m_iRows = 0;
	m_iCols = 0;
	m_bComplex = false;
	m_dDelta = 0.0;
	m_dLambda = 0.0;
	m_dMu = 0;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for SolverBaseClass.
/// Frees preallocated memory
///
////////////////////////////////////////////////////////////////////////////////////
SolverBaseClass::~SolverBaseClass(void)
{
	// Do not do this, alloc in another place
#if 0
	if(m_pdA != NULL)
	{
		free(m_pdA);
		m_pdA = NULL;
	}
	if(m_pdB != NULL)
	{
		free(m_pdB);
		m_pdB = NULL;
	}
	if(m_pdX != NULL)
	{
		free(m_pdX);
		m_pdX = NULL;
	}
#endif
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the \f$A\f$ Matrix parameters
///
/// \param pdA pointer to the matrix \f$A\f$
/// \param iRows number of rows
/// \param iCols number of columns
/// \param bComplex if true, means the A matrix contains both real and complex numbers
///
////////////////////////////////////////////////////////////////////////////////////
void SolverBaseClass::SetAMatrixParameters(double* pdA, int iRows, int iCols, bool bComplex)
{
	m_pdA = pdA;
	m_iRows = iRows;
	m_iCols = iCols;
	m_bComplex = bComplex;

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the \f$b\f$ and \f$x\f$ matrix pointers
///
/// \param pdB pointer to the matrix \f$b\f$
/// \param pdX pointer to the matrix \f$x\f$
///
////////////////////////////////////////////////////////////////////////////////////
void SolverBaseClass::SetOtherMatrixParameters(double* pdB, double* pdX)
{
	m_pdB = pdB;
	m_pdX = pdX;

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets additional parameters (for all adaptive algorithms)
///
/// \param dDelta regression parameter
/// \param dLambda regularization parameter
/// \param dMu LMS parameter
///
////////////////////////////////////////////////////////////////////////////////////
void SolverBaseClass::SetAdditionalParameters(double dDelta, double dLambda, double dMu)
{
	m_dDelta = dDelta;
	m_dLambda = dLambda;
	m_dMu = dMu;

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Copies the \f$x\f$ vector to pdOutputX
///
/// \param [out] pdOutputX preallocated memory of size iCols
///
////////////////////////////////////////////////////////////////////////////////////
//void GetLastCoefficientSet(double* pdOutputX)
//{
//	int iIndex;
//	int iLength = m_iCols;
//
//	if(m_bComplex)
//	{
//		iLength = iLength * 2;
//	}
//
//	for(iIndex = 0; iIndex < iLength; iIndex++)
//	{
//		pdOutputX[iIndex] = m_pdX[
//	}
//
//}