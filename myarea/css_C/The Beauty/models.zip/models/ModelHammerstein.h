/// \file ModelHammerstein.h
/// Header file for class ModelHammerstein

#pragma once

#include "ModelFilterBaseClass.h"
#include "ModelBaseClass.h"

/// \class ModelHammerstein
/// class for Hammerstein model
class ModelHammerstein : public ModelFilterBaseClass
{
public:
	ModelHammerstein(void);
	~ModelHammerstein(void);
	void RunModel(void);

protected:
	void ExtractHammersteinMemoryEffects();
private:

};
