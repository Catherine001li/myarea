/// \file SolverQRRLS.h
/// Header file for solving models using QRRLS


#pragma once
#include "SolverBaseClass.h"
#include "f2c.h"

/// \class SolverQRRLS
/// Solves models using QRRLS method
class SolverQRRLS : public SolverBaseClass
{
public:
	SolverQRRLS(void);
	~SolverQRRLS(void);
	void SolveMatrix();
private:
	void QRRLSAlgComplex(void);
	void QRDRLSGivens(doublecomplex* pcdQRMatrix, doublecomplex* pcdInputX, doublecomplex cdDesired, double dLambda);
	void ApplyGivens(doublecomplex* pcdX, doublecomplex* pcdY, int iLength, doublecomplex cdCos, doublecomplex cdSin);
	doublecomplex ComplexDivide(doublecomplex cdA, doublecomplex cdB);
	void GivensRotation(doublecomplex* pcdF, doublecomplex* pcdG, doublecomplex* pcdCos, doublecomplex* pcdSin);
	void BackSubstitution(doublecomplex* pcdQRMatrix, doublecomplex* pcdCoeffs);
};
