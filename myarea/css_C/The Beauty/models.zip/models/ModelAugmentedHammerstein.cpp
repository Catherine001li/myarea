/// \file ModelAugmentedHammerstein.cpp
/// Implementation file for class ModelAugmentedHammerstein

#include "stdafx.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include "ModelAugmentedHammerstein.h"
#include "..\MyExceptionTrace.h"
#include "..\nsmfunctions.h"
#include "..\matlab\MatlabFunctions.h"


////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for ModelAugmentedHammerstein.
/// Calls base class constructor ModelBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
ModelAugmentedHammerstein::ModelAugmentedHammerstein(void) : ModelHammerstein()
{
	// Set Model Type
	m_eModelType = MODEL_AUGMENTED_HAMMERSTEIN;
	m_csModelType = TypeNameToString(m_eModelType);
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for ModelAugmentedHammerstein.
/// Implicitly calls ModelBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
ModelAugmentedHammerstein::~ModelAugmentedHammerstein(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the ModelAugmentedHammerstein model.
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/solveFilter.m"> solveFilter.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelAugmentedHammerstein::RunModel(void)
{
	try
	{
		// Open Files
		OpenFiles();

		// Call Generate LUT
		GenerateLUT();

		// Extract the training data for the memory filters
		ExtractHammersteinMemoryEffects();

		// Run Filter Identification
		FilterIdentification();

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}

