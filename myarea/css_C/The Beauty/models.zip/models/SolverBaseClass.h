/// \file SolverBaseClass.h
/// Header file for base class of solvers

#pragma once

/// \interface SolverBaseClass
/// base class for solvers
class SolverBaseClass
{
public:
	SolverBaseClass(void);
	virtual ~SolverBaseClass(void);
	virtual void SolveMatrix() = 0;					///< Abstract function, needs to be overridden in derived classes
	/*void GetLastCoefficientSet(double* pdInputX, double* pdOutputX);*/

	void SetAMatrixParameters(double* pdA, int iRows, int iCols, bool bComplex);
	void SetOtherMatrixParameters(double* pdB, double* pdX);
	void SetAdditionalParameters(double dDelta, double dLambda, double dMu);
//	void DestroyParameters(bool bDestroy);

protected:
	// Member Variables
	double* m_pdA;			///< Matrix \f$A\f$	(dimensions of m_iRows x m_iCols)
	int m_iRows;			///< number of Rows in Matrix \f$A\f$ 
	int m_iCols;			///< number of Columns in Matrix \f$A\f$ 
	bool m_bComplex;		///< true if Matrix \f$A\f$ is complex

	double* m_pdB;			///< Matrix \f$b\f$	(dimensions of m_iRows * 1)
	double* m_pdX;			///< Matrix \f$x\f$ (dimensions of m_iCols * 1)

	double m_dDelta;		///< Regularization Parameter QR-RLS/RLS
	double m_dLambda;		///< Regression Parameter for QR-RLS/RLS
	double m_dMu;			///< Mu Parameter

};
