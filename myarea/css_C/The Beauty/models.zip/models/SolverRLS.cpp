/// \file SolverRLS.cpp
/// Implementation file for solving models using RLS


#include "stdafx.h"
#include "SolverRLS.h"
#include "SolverBaseClass.h"
#include "f2c.h"
#include "clapack.h"
#include "..\nsmfunctions.h"
#include "..\MATLAB\MatlabFunctions.h"
#include "..\MyExceptionTrace.h"

////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for SolverRLS.
/// Calls base class constructor SolverBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
SolverRLS::SolverRLS(void) : SolverBaseClass()
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for SolverRLS
/// Implicitly calls SolverBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
SolverRLS::~SolverRLS(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Solves according to input parameters specified...
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/AugFIRDesignByRLSfunc.m"> AugFIRDesignByRLSfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void SolverRLS::SolveMatrix()
{
	if(m_bComplex)
	{
		RLSAlgComplex();
	}
	else
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Non Complex not supported yet"));
		AfxThrowUserException();
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the RLS algorithm (with input parameters being complex valued)
/// Performs similar to MATLAB (not exact, within 0.01 error). Most likely cause of error is
/// the way matrix k is generated.
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/AugFIRDesignByRLSfunc.m"> AugFIRDesignByRLSfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void SolverRLS::RLSAlgComplex(void)
{
	doublecomplex* pcdun = NULL;
	doublecomplex* pcdunH = NULL;
	doublecomplex* pcdwn = NULL;
	doublecomplex* pcdwnH = NULL;
	doublecomplex* pcdPn = NULL;
	doublecomplex* pcdKn = NULL;
	doublecomplex* pcdError = NULL;
	double* pdError = NULL;
	doublecomplex* pcdPi = NULL;

	double dTemp;
	doublecomplex cdTemp;
	doublecomplex cdEps;
	int iIndex, iIndexC, iIndexR, iRowIndex, iColIndex;

	try
	{
		// Preinitialize buffers
		pcdun = new doublecomplex[m_iCols];
		pcdunH = new doublecomplex[m_iCols];
		pcdwn = new doublecomplex[m_iCols];
		pcdwnH = new doublecomplex[m_iCols];
		pcdPn = new doublecomplex[m_iCols * m_iCols];
		pcdKn = new doublecomplex[m_iCols];	////dfjalksdjflajsdfa
		pcdError = new doublecomplex[m_iRows];
		pdError = new double[m_iRows];
		pcdPi = new doublecomplex[m_iCols];

		// Initialize matrix
		// Real or/and Imaginary!?!
		for(iRowIndex = 0; iRowIndex < m_iCols; iRowIndex++)
		{
			for(iColIndex = 0; iColIndex < m_iCols; iColIndex++)
			{
				if(iRowIndex == iColIndex)
				{
					pcdPn[iRowIndex * m_iCols + iColIndex].r = 1 / m_dDelta;
				}
				else
				{
					pcdPn[iRowIndex * m_iCols + iColIndex].r = 0.0;
				}
				pcdPn[iRowIndex * m_iCols + iColIndex].i = 0.0;
			}

			pcdwn[iRowIndex].r = 0.0;
			pcdwn[iRowIndex].i = 0.0;
		}


		// Did not include outer loop for iterator 'i' in MATLAB (line 62)
		for(iRowIndex = 0; iRowIndex < m_iRows; iRowIndex++)
		{
			// Copy Current input signal
			for(iColIndex = 0; iColIndex < m_iCols; iColIndex++)
			{
				pcdun[iColIndex].r = ((doublecomplex*) m_pdA)[iRowIndex * m_iCols + iColIndex].r;
				pcdun[iColIndex].i = ((doublecomplex*) m_pdA)[iRowIndex * m_iCols + iColIndex].i;
				
				// Hermitian transpose of un
				pcdunH[iColIndex].r = pcdun[iColIndex].r;
				pcdunH[iColIndex].i = -1.0 * pcdun[iColIndex].i;
				
				// Hermitian transpose of wn
				pcdwnH[iColIndex].r = pcdwn[iColIndex].r;
				pcdwnH[iColIndex].i = -1.0 * pcdwn[iColIndex].i;
			}

			// Removed if/else statement.
			// Generate temporary matrix Kn
			MatrixMultiply(pcdPn, m_iCols, m_iCols, pcdun, 1, pcdPi);
			MatrixMultiply(pcdunH, 1, m_iCols, pcdPi, 1, &cdTemp);			

			// know that cdTemp is a real variable
			cdTemp.r = m_dLambda + cdTemp.r;

			for(iIndex = 0; iIndex < m_iCols; iIndex++)
			{
				ComplexDivide(&pcdPi[iIndex], &cdTemp, &pcdKn[iIndex]);
				//pcdKn[iIndex].r = pcdPi[iIndex].r / dTemp;
				//pcdKn[iIndex].i = pcdPi[iIndex].i / dTemp;
			}

			// Calculate error
			MatrixMultiply(pcdwnH, 1, m_iCols, pcdun, 1, &cdEps);
			cdEps.r = ((doublecomplex*) m_pdB)[iRowIndex].r - cdEps.r;
			cdEps.i = ((doublecomplex*) m_pdB)[iRowIndex].i - cdEps.i;
			pcdError[iRowIndex].r = cdEps.r;
			pcdError[iRowIndex].i = cdEps.i;
			MatlabAbs(&pcdError[iRowIndex], &pdError[iRowIndex], 1);
			
			// Conjugate Eps to prepare for new weight vector
			cdEps.i = (-1.0) * cdEps.i;

			// Generate new weight vectors
			for(iIndex = 0; iIndex < m_iCols; iIndex++)
			{
				ComplexMultiply(&pcdKn[iIndex], &cdEps, &cdTemp);
				//pcdwn[iIndex].r = pcdwn[iIndex].r + cdTemp.r;
				//pcdwn[iIndex].i = pcdwn[iIndex].i + cdTemp.i;
				ComplexAdd(&pcdwn[iIndex], &cdTemp, &pcdwn[iIndex]);
			}

			// Update correlation matrix Pn
			// try to optimize, do the matrix operation pi = uh*Pn
			MatrixMultiply(pcdunH, 1, m_iCols, pcdPn, m_iCols, pcdPi);

			// then do Pn = 1/lambda * (Pn - kn * pi)
			for(iIndexR = 0; iIndexR < m_iCols; iIndexR++)
			{
				for(iIndexC = 0; iIndexC < m_iCols; iIndexC++)
				{
					ComplexMultiply(&pcdKn[iIndexR], &pcdPi[iIndexC], &cdTemp);
					pcdPn[iIndexR * m_iCols + iIndexC].r = (1 / m_dLambda) * (pcdPn[iIndexR * m_iCols + iIndexC].r - cdTemp.r);
					pcdPn[iIndexR * m_iCols + iIndexC].i = (1 / m_dLambda) * (pcdPn[iIndexR * m_iCols + iIndexC].i - cdTemp.i);
					
				}
			}

			// finish 1 run of RLS
		}


		// Copy Complex Conjugate of last known wn to x
		for(iIndex = 0; iIndex < m_iCols; iIndex++)
		{
			m_pdX[2 * iIndex] = pcdwn[iIndex].r;
			m_pdX[(2 * iIndex) + 1] = (-1.0) * pcdwn[iIndex].i;
		}

	}
/*	catch(CMemoryException *pEx)
	{
		MESSAGEBOX_MEMORYEXCEPTION;
		bError = true;
	}
*/	catch(CException *pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		
		SAFE_DELETE_ARRAY(pcdun);
		SAFE_DELETE_ARRAY(pcdunH);
		SAFE_DELETE_ARRAY(pcdwn);
		SAFE_DELETE_ARRAY(pcdwnH);
		SAFE_DELETE_ARRAY(pcdPn);
		SAFE_DELETE_ARRAY(pcdKn);
		SAFE_DELETE_ARRAY(pcdError);
		SAFE_DELETE_ARRAY(pdError);
		SAFE_DELETE_ARRAY(pcdPi);

		throw;
	}

	// Free Variables

	SAFE_DELETE_ARRAY(pcdun);
	SAFE_DELETE_ARRAY(pcdunH);
	SAFE_DELETE_ARRAY(pcdwn);
	SAFE_DELETE_ARRAY(pcdwnH);
	SAFE_DELETE_ARRAY(pcdPn);
	SAFE_DELETE_ARRAY(pcdKn);
	SAFE_DELETE_ARRAY(pcdError);
	SAFE_DELETE_ARRAY(pdError);
	SAFE_DELETE_ARRAY(pcdPi);

	return;
}
