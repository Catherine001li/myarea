/// \file SolverRLS.h
/// Header file for solving models using RLS


#pragma once
#include "SolverBaseClass.h"
#include "f2c.h"

/// \class SolverRLS
/// Solves models using RLS method
class SolverRLS : public SolverBaseClass
{
public:
	SolverRLS(void);
	~SolverRLS(void);
	void SolveMatrix();
private:
	void RLSAlgComplex(void);
};
