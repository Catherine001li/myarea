/// \file ModelMemoryless.h
/// Header file for class ModelMemoryless

#pragma once

#include "ModelFilterBaseClass.h"
//#include "..\global.h"
#include "f2c.h"

/// \class ModelMemoryless
/// class for Memoryless model
class ModelMemoryless : public ModelFilterBaseClass
{
public:
	ModelMemoryless(void);
	~ModelMemoryless(void);
	void RunModel(void);		///< Virtual Function
	void RunGenerateSSG(void);
private:
};
