/// \file SolverLMS.h
/// Header file for solving models using LMS


#pragma once
#include "SolverBaseClass.h"
#include "f2c.h"

/// \class SolverLMS
/// Solves models using LMS method
class SolverLMS : public SolverBaseClass
{
public:
	SolverLMS(void);
	~SolverLMS(void);
	void SolveMatrix();
private:
	void LMSAlgComplex(void);
};
