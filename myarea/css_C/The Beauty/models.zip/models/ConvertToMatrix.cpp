/// \file ConvertToMatrix.cpp
/// Implementation file for converting data to matrix format using various methods

#include "stdafx.h"
#include <math.h>
#include "ConvertToMatrix.h"
#include "..\nsmfunctions.h"
#include "..\MyExceptionTrace.h"


////////////////////////////////////////////////////////////////////////////////////
///
/// Default Constructor, sets all values to NULL
///
////////////////////////////////////////////////////////////////////////////////////
ConvertToMatrix::ConvertToMatrix(void)
{
	m_pcdInputX1 = NULL;
	m_iLengthInputX1 = 0;
	m_pcdInputX = NULL;
	m_iLengthInputX = 0;
	m_pcdOutputY = NULL;
	m_iLengthOutputY = 0;

	m_pcdAMatrix = NULL;
	m_iRowsA = 0;
	m_iColsA = 0;

	m_pcdResultX = NULL;
	m_pcdResultY = NULL;
	m_iResultLength = 0;

	m_iTaps = 0;
	m_iOrder = 0;
	m_eConvert = CONVERSION_UNKNOWN;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor, frees all allocated variables if not set to NULL
///
////////////////////////////////////////////////////////////////////////////////////
ConvertToMatrix::~ConvertToMatrix(void)
{
	SAFE_DELETE_ARRAY(m_pcdInputX1);
	SAFE_DELETE_ARRAY(m_pcdInputX);
	SAFE_DELETE_ARRAY(m_pcdOutputY);
	SAFE_DELETE_ARRAY(m_pcdAMatrix);
	SAFE_DELETE_ARRAY(m_pcdResultX);
	SAFE_DELETE_ARRAY(m_pcdResultY);
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes a matrix conversion based on the input parameters.  Throws exceptions
/// if invalid parameters are set.
///
////////////////////////////////////////////////////////////////////////////////////
void ConvertToMatrix::Run(void)
{
	// Validate all input arguments
	if(!m_pcdInputX || (m_eConvert == CONVERSION_UNKNOWN))
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Some Parameters have not been set"));
		AfxThrowUserException();
	}

	// if everything has already been allocated, means that this function has been run
	// already
	if(m_pcdAMatrix || m_pcdResultX || m_pcdResultY)
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Matrix has already been converted"));
		AfxThrowUserException();
	}

	// if input vectors are not the same, error
	//if(m_iLengthInputX != m_iLengthOutputY)
	//{
	//	EXCEPTION_ADDUSERMESSAGE(_T("Input/Output Lengths are not the same"));
	//	AfxThrowUserException();
	//}

	switch(m_eConvert)
	{
		case CONVERSION_POLYSEA1:
		case CONVERSION_POLYA1:
			ConvertToPolyLSE();
			break;
		case CONVERSION_X2_FIRA1:
			ConvertToX2FIR();
			break;
		case CONVERSION_NONREV_POLYLSE_FULL:
			ConvertToPolyLSERecreate();
			break;
		default:
			EXCEPTION_ADDUSERMESSAGE(_T("Undefined Model"));
			AfxThrowUserException();
	}

	return;
}

////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the internal parameters
///
/// \param iTaps number of taps
/// \param iOrder order number
/// \param eConvert the model type
///
////////////////////////////////////////////////////////////////////////////////////
void ConvertToMatrix::SetParameters(int iTaps, int iOrder, CONVERSION_TYPE eConvert)
{
	m_iTaps = iTaps;
	m_iOrder = iOrder;
	m_eConvert = eConvert;

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs a deep copy of the incoming variable to the member variable
///
/// \param pcdInputX input vector X
/// \param iLength length of X
///
////////////////////////////////////////////////////////////////////////////////////
void ConvertToMatrix::SetInputX(doublecomplex* pcdInputX, int iLength)
{
	int iIndex;

	// if input has already been assigned, throw an error
	if(m_pcdInputX)
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Input X has already been assigned"));
		AfxThrowUserException();
	}

	m_pcdInputX = new doublecomplex[iLength];
	m_iLengthInputX = iLength;

	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		m_pcdInputX[iIndex].r = pcdInputX[iIndex].r;
		m_pcdInputX[iIndex].i = pcdInputX[iIndex].i;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs a deep copy of the incoming variable to the member variable
///
/// \param pcdInputX1 input vector X1
/// \param iLength length of X1
///
////////////////////////////////////////////////////////////////////////////////////
void ConvertToMatrix::SetInputX1(doublecomplex* pcdInputX1, int iLength)
{
	int iIndex;

	// if input has already been assigned, throw an error
	if(m_pcdInputX1)
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Input X1 has already been assigned"));
		AfxThrowUserException();
	}

	m_pcdInputX1 = new doublecomplex[iLength];
	m_iLengthInputX1 = iLength;

	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		m_pcdInputX1[iIndex].r = pcdInputX1[iIndex].r;
		m_pcdInputX1[iIndex].i = pcdInputX1[iIndex].i;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs a deep copy of the incoming variable to the member variable
///
/// \param pcdOutputY output vector Y
/// \param iLength length of Y
///
////////////////////////////////////////////////////////////////////////////////////
void ConvertToMatrix::SetOutputY(doublecomplex* pcdOutputY, int iLength)
{
	int iIndex;

	// if input has already been assigned, throw an error
	if(m_pcdOutputY)
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Output Y has already been assigned"));
		AfxThrowUserException();
	}

	m_pcdOutputY = new doublecomplex[iLength];
	m_iLengthOutputY = iLength;

	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		m_pcdOutputY[iIndex].r = pcdOutputY[iIndex].r;
		m_pcdOutputY[iIndex].i = pcdOutputY[iIndex].i;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Returns the result length
///
/// \return the result length
///
////////////////////////////////////////////////////////////////////////////////////
int ConvertToMatrix::GetResultLength()
{
	if(m_iResultLength == 0)
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Matrix has not been converted yet"));
		AfxThrowUserException();
	}

	return m_iResultLength;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs a deep copy of the member variable, and returns the pointer to X allocated
/// on the heap
///
/// \return the pointer to the heap for X
///
////////////////////////////////////////////////////////////////////////////////////
doublecomplex* ConvertToMatrix::GetResultX(int* piLength)
{
	doublecomplex* pcdReturn;
	int iIndex;

	if(m_iResultLength < 0 || m_pcdResultX == NULL)
	{
		EXCEPTION_ADDUSERMESSAGE(_T("ConvertToMatrix was not executed before getting X"));
		AfxThrowUserException();
	}

	if(piLength)
		*piLength = m_iResultLength;

	pcdReturn = new doublecomplex[m_iResultLength];

	for(iIndex = 0; iIndex < m_iResultLength; iIndex++)
	{
		pcdReturn[iIndex].r = m_pcdResultX[iIndex].r;
		pcdReturn[iIndex].i = m_pcdResultX[iIndex].i;
	}

	return pcdReturn;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs a deep copy of the member variable, and returns the pointer to Y allocated
/// on the heap. If Y was not set, then return NULL
///
/// \return the pointer to the heap for Y
///
////////////////////////////////////////////////////////////////////////////////////
doublecomplex* ConvertToMatrix::GetResultY(int* piLength)
{
	doublecomplex* pcdReturn;
	int iIndex;

	if(m_iResultLength < 0 || m_pcdResultY == NULL)
	{
		return NULL;
	}

	if(piLength)
		*piLength = m_iResultLength;

	pcdReturn = new doublecomplex[m_iResultLength];

	for(iIndex = 0; iIndex < m_iResultLength; iIndex++)
	{
		pcdReturn[iIndex].r = m_pcdResultY[iIndex].r;
		pcdReturn[iIndex].i = m_pcdResultY[iIndex].i;
	}

	return pcdReturn;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs a deep copy of the member variable, and returns the pointer to A allocated
/// on the heap
///
/// \return the pointer to the heap for A
///
////////////////////////////////////////////////////////////////////////////////////
doublecomplex* ConvertToMatrix::GetResultAMatrix(int* piRows, int* piCols)
{
	doublecomplex* pcdReturn;
	int iIndex;

	if(m_iResultLength < 0 || m_pcdAMatrix == NULL)
	{
		EXCEPTION_ADDUSERMESSAGE(_T("ConvertToMatrix was not executed before getting A"));
		AfxThrowUserException();
	}

	if(piRows)
		*piRows = m_iRowsA;
	if(piCols)
		*piCols = m_iColsA;

	pcdReturn = new doublecomplex[m_iRowsA * m_iColsA];

	// Faster than doing 2 fors
	for(iIndex = 0; iIndex < m_iRowsA * m_iColsA; iIndex++)
	{
		pcdReturn[iIndex].r = m_pcdAMatrix[iIndex].r;
		pcdReturn[iIndex].i = m_pcdAMatrix[iIndex].i;
	}

	return pcdReturn;

}

////////////////////////////////////////////////////////////////////////////////////
///
/// Performs matrix conversion for Multibranch Polynomial models.
/// Combines both conversion types found in the matlab reference
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/Global/convert2_POLYLSEA1_Matrix.m"> convert2_POLYLSEA1_Matrix.m </a>
/// - <a href = "../../NonlinearSystemModeler/Global/convert2_POLYLSEA1_Matrix_ham.m"> convert2_POLYLSEA1_Matrix_ham.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ConvertToMatrix::ConvertToPolyLSE()
{
	int iWIndex;
	int iInIndex;

	int iIndexI, iIndexQ;
	int iAdjustOffset = 1;
	int iTapIndex, iOrderIndex, iTimeIndex;
	int iAMatrixIndex;
	double dTemp;
	int iLength;
	doublecomplex* pcdXCopy;

	try
	{

		// Allocate A Matrix and result vectors
		iLength = m_iLengthInputX;
		m_iRowsA = (iLength - (m_iTaps - 1));
		m_iColsA = m_iTaps * (m_iOrder + 1);
		m_pcdAMatrix = new doublecomplex[m_iRowsA * m_iColsA];
		m_pcdResultX = new doublecomplex[m_iRowsA];
		
		// Only allocate Y if inputY was specified.
		if(m_pcdOutputY)
			m_pcdResultY = new doublecomplex[m_iRowsA];

		// Depending on if InputX1 is specified or not
		if(m_pcdInputX1)
			pcdXCopy = m_pcdInputX1;
		else
			pcdXCopy = m_pcdInputX;

		// Start Iteration
		for(iTimeIndex = 0; iTimeIndex < m_iRowsA; iTimeIndex++)
		{
			for(iTapIndex = 0; iTapIndex < m_iTaps; iTapIndex++)
			{
				// Current value to compute
				iInIndex = ((iLength - 1) - iTapIndex - iTimeIndex);

				for(iOrderIndex = 0; iOrderIndex < (m_iOrder + 1); iOrderIndex++)
				{
					// Compute Matrix Offset
					iAMatrixIndex = iTimeIndex * (m_iTaps * (m_iOrder + 1)) + iTapIndex * (m_iOrder + 1) + iOrderIndex;

					// Compute Order
//					dTemp = sqrt(pow(m_pcdInputX[iInIndex].r, 2) + pow(m_pcdInputX[iInIndex].i, 2));
					dTemp = sqrt(pow(pcdXCopy[iInIndex].r, 2) + pow(pcdXCopy[iInIndex].i, 2));
					dTemp = pow(dTemp, iOrderIndex);

//					m_pcdAMatrix[iAMatrixIndex].r = m_pcdInputX[iInIndex].r * dTemp;
//					m_pcdAMatrix[iAMatrixIndex].i = m_pcdInputX[iInIndex].i * dTemp;
					m_pcdAMatrix[iAMatrixIndex].r = pcdXCopy[iInIndex].r * dTemp;
					m_pcdAMatrix[iAMatrixIndex].i = pcdXCopy[iInIndex].i * dTemp;
				}
			}
		}

		// Depending on if InputX1 is specified or not
		//if(m_pcdInputX1)
		//	pcdXCopy = m_pcdInputX1;
		//else
		//	pcdXCopy = m_pcdInputX;

		// Generate y1/x1
		for(iWIndex = 0; iWIndex < m_iRowsA; iWIndex++)
		{
			iInIndex = (iLength - 1) - iWIndex;
//			m_pcdResultX[iWIndex].r = pcdXCopy[iInIndex].r;
//			m_pcdResultX[iWIndex].i = pcdXCopy[iInIndex].i;
			m_pcdResultX[iWIndex].r = m_pcdInputX[iInIndex].r;
			m_pcdResultX[iWIndex].i = m_pcdInputX[iInIndex].i;

			// Only generate Y if exists.
			if(m_pcdOutputY)
			{
				m_pcdResultY[iWIndex].r = m_pcdOutputY[iInIndex].r;
				m_pcdResultY[iWIndex].i = m_pcdOutputY[iInIndex].i;
			}
		}

		m_iResultLength = m_iRowsA;

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs matrix conversion for FIR models.
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/Global/convert2_X2_FIRA1_Matrix.m"> convert2_X2_FIRA1_Matrix.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ConvertToMatrix::ConvertToX2FIR()
{
	int iWIndex;
	int iInIndex;

	int iIndexI, iIndexQ;
	int iAdjustOffset = 1;
	int iTapIndex, iOrderIndex, iTimeIndex;
	int iAMatrixIndex;
	double dAbs;
	int iLength;
	doublecomplex* pcdXCopy;

	try
	{
		// Allocate A Matrix and result vectors
		iLength = m_iLengthInputX;
		m_iRowsA = (iLength - (m_iTaps - 1));
		m_iColsA = m_iTaps * 2;						// Order == 0 here
		m_pcdAMatrix = new doublecomplex[m_iRowsA * m_iColsA];
		m_pcdResultX = new doublecomplex[m_iRowsA];

		// Only Allocate Y if inputY was specified
		if(m_pcdOutputY)
			m_pcdResultY = new doublecomplex[m_iRowsA];

		// Depending on if InputX1 is specified or not
		if(m_pcdInputX1)
			pcdXCopy = m_pcdInputX1;
		else
			pcdXCopy = m_pcdInputX;

		// Start Iteration
		// Derives from implementation, the indexing variable is offsetted already
		for(iTimeIndex = 0; iTimeIndex < m_iRowsA; iTimeIndex++)
		{
			// DataX
			for(iTapIndex = 0; iTapIndex < m_iTaps; iTapIndex++)
			{
				iAMatrixIndex = iTimeIndex * m_iColsA + iTapIndex;
				iInIndex = iTimeIndex + m_iTaps - 1 - iTapIndex;
//				m_pcdAMatrix[iAMatrixIndex].r = m_pcdInputX[iInIndex].r;
//				m_pcdAMatrix[iAMatrixIndex].i = m_pcdInputX[iInIndex].i;
				m_pcdAMatrix[iAMatrixIndex].r = pcdXCopy[iInIndex].r;
				m_pcdAMatrix[iAMatrixIndex].i = pcdXCopy[iInIndex].i;
			}

			// DataX2
			for(iTapIndex = 0; iTapIndex < m_iTaps; iTapIndex++)
			{
				// Offset by DataX
				iAMatrixIndex = iTimeIndex * m_iColsA + iTapIndex + m_iTaps;
				iInIndex = iTimeIndex + m_iTaps - 1 - iTapIndex;
				
//				dAbs = sqrt(m_pcdInputX[iInIndex].r * m_pcdInputX[iInIndex].r + m_pcdInputX[iInIndex].i * m_pcdInputX[iInIndex].i);

//				m_pcdAMatrix[iAMatrixIndex].r = m_pcdInputX[iInIndex].r * dAbs;
//				m_pcdAMatrix[iAMatrixIndex].i = m_pcdInputX[iInIndex].i * dAbs;
				dAbs = sqrt(pcdXCopy[iInIndex].r * pcdXCopy[iInIndex].r + pcdXCopy[iInIndex].i * pcdXCopy[iInIndex].i);

				m_pcdAMatrix[iAMatrixIndex].r = pcdXCopy[iInIndex].r * dAbs;
				m_pcdAMatrix[iAMatrixIndex].i = pcdXCopy[iInIndex].i * dAbs;
			}
		}

		// Depending on if InputX1 is specified or not
//		if(m_pcdInputX1)
//			pcdXCopy = m_pcdInputX1;
//		else
//			pcdXCopy = m_pcdInputX;

		// Generate y1/x1
		for(iWIndex = 0; iWIndex < m_iRowsA; iWIndex++)
		{
			iInIndex = iWIndex + m_iTaps - 1;
//			m_pcdResultX[iWIndex].r = pcdXCopy[iInIndex].r;
//			m_pcdResultX[iWIndex].i = pcdXCopy[iInIndex].i;
			m_pcdResultX[iWIndex].r = m_pcdInputX[iInIndex].r;
			m_pcdResultX[iWIndex].i = m_pcdInputX[iInIndex].i;

			// Only generate Y if exists.
			if(m_pcdOutputY)
			{
				m_pcdResultY[iWIndex].r = m_pcdOutputY[iInIndex].r;
				m_pcdResultY[iWIndex].i = m_pcdOutputY[iInIndex].i;
			}
		}

		m_iResultLength = m_iRowsA;

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs matrix conversion for Multibranch Polynomial models.
/// Combines both conversion types found in the matlab reference
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/Global/convert2_POLYLSEA1_Matrix.m"> convert2_POLYLSEA1_Matrix.m </a>
/// - <a href = "../../NonlinearSystemModeler/Global/convert2_POLYLSEA1_Matrix_ham.m"> convert2_POLYLSEA1_Matrix_ham.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ConvertToMatrix::ConvertToPolyLSERecreate()
{
	int iWIndex;
	int iInIndex;

	int iIndexI, iIndexQ;
	int iAdjustOffset = 1;
	int iTapIndex, iOrderIndex, iTimeIndex;
	int iAMatrixIndex;
	double dTemp;
	int iLength;
	doublecomplex* pcdXCopy;

	try
	{

		// Allocate A Matrix and result vectors
		iLength = m_iLengthInputX;
		m_iRowsA = iLength;
		m_iColsA = m_iTaps * (m_iOrder + 1);
		m_pcdAMatrix = new doublecomplex[m_iRowsA * m_iColsA];
		m_pcdResultX = new doublecomplex[m_iRowsA];
		
		// Only allocate Y if inputY was specified.
		if(m_pcdOutputY)
			m_pcdResultY = new doublecomplex[m_iRowsA];

		// Depending on if InputX1 is specified or not
		if(m_pcdInputX1)
			pcdXCopy = m_pcdInputX1;
		else
			pcdXCopy = m_pcdInputX;




		// Start Iteration
		for(iTimeIndex = 0; iTimeIndex < m_iRowsA; iTimeIndex++)
		{
			for(iTapIndex = 0; iTapIndex < m_iTaps; iTapIndex++)
			{
				// Current value to compute
				iInIndex = iTimeIndex - iTapIndex;

				for(iOrderIndex = 0; iOrderIndex < (m_iOrder + 1); iOrderIndex++)
				{
					iAMatrixIndex = iTimeIndex * (m_iTaps * (m_iOrder + 1)) + iTapIndex * (m_iOrder + 1) + iOrderIndex;
					
					if(iInIndex < 0)
					{
						m_pcdAMatrix[iAMatrixIndex].r = 0.0;
						m_pcdAMatrix[iAMatrixIndex].i = 0.0;
					}
					else
					{
						// Compute Matrix Offset

						// Compute Order
						dTemp = sqrt(pow(pcdXCopy[iInIndex].r, 2) + pow(pcdXCopy[iInIndex].i, 2));
						dTemp = pow(dTemp, iOrderIndex);

						m_pcdAMatrix[iAMatrixIndex].r = pcdXCopy[iInIndex].r * dTemp;
						m_pcdAMatrix[iAMatrixIndex].i = pcdXCopy[iInIndex].i * dTemp;
					}
				}
			}
		}


		// Generate y1/x1
		for(iWIndex = 0; iWIndex < m_iRowsA; iWIndex++)
		{
			iInIndex = (iLength - 1) - iWIndex;
			m_pcdResultX[iWIndex].r = m_pcdInputX[iInIndex].r;
			m_pcdResultX[iWIndex].i = m_pcdInputX[iInIndex].i;

			// Only generate Y if exists.
			if(m_pcdOutputY)
			{
				m_pcdResultY[iWIndex].r = m_pcdOutputY[iInIndex].r;
				m_pcdResultY[iWIndex].i = m_pcdOutputY[iInIndex].i;
			}
		}

		m_iResultLength = m_iRowsA;

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}