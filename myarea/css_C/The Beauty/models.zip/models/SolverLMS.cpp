/// \file SolverLMS.cpp
/// Implementation file for solving models using LMS


#include "stdafx.h"
#include "SolverLMS.h"
#include "SolverBaseClass.h"
#include "f2c.h"
#include "clapack.h"
#include "..\nsmfunctions.h"
#include "..\MATLAB\MatlabFunctions.h"
#include "..\MyExceptionTrace.h"
#include "..\resource.h"
#include "..\NtGraphDialog.h"

////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for SolverLMS.
/// Calls base class constructor SolverBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
SolverLMS::SolverLMS(void) : SolverBaseClass()
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for SolverLMS
/// Implicitly calls SolverBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
SolverLMS::~SolverLMS(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Solves according to input parameters specified...
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/AugFIRDesignByLMSfunc.m"> AugFIRDesignByLMSfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void SolverLMS::SolveMatrix()
{
	if(m_bComplex)
	{
		LMSAlgComplex();
	}
	else
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Non Complex not supported yet"));
		AfxThrowUserException();
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the LMS algorithm (with input parameters being complex valued)
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/AugFIRDesignByLMSfunc.m"> AugFIRDesignByLMSfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void SolverLMS::LMSAlgComplex(void)
{
	int iIndex;
	doublecomplex* pcdA;
	doublecomplex* pcdX;
	doublecomplex* pcdB;
	doublecomplex* pcdU = NULL;
	doublecomplex* pcdY = NULL;
	doublecomplex* pcdE = NULL;
	double* pdEAbs = NULL;
	double* pdTime = NULL;
	double* pdUAbs = NULL;
	int iRowIndex;
	double dMu0;
	double dMu;
	double dMuMax;
	double dSum;
	doublecomplex cdTemp;
	CNtGraphDialog* pAbsError;

	try
	{
		pcdA = (doublecomplex*) m_pdA;
		pcdB = (doublecomplex*) m_pdB;
		pcdX = (doublecomplex*) m_pdX;
		pcdU = new doublecomplex[m_iCols];
		pcdY = new doublecomplex[m_iRows];
		pcdE = new doublecomplex[m_iRows];
		pdEAbs = new double[m_iRows];
		pdTime = new double[m_iRows];
		pdUAbs = new double[m_iCols];

		// Initialize the Weight Vector (Coefficients)
		// Don't allocate a new vector
		for(iIndex = 0; iIndex < m_iCols; iIndex++)
		{
			pcdX[iIndex].r = 0.0;
			pcdX[iIndex].i = 0.0;
		}

		// LMS ALG
		dMu0 = m_dMu;
		for(iRowIndex = 0; iRowIndex < m_iRows; iRowIndex++)
		{
			// Copy current row to U
			for(iIndex = 0; iIndex < m_iCols; iIndex++)
			{
				pcdU[iIndex].r = pcdA[iRowIndex * m_iCols + iIndex].r;
				pcdU[iIndex].i = pcdA[iRowIndex * m_iCols + iIndex].i;
			}

			if(iRowIndex == 0)
			{
				// Calculate mu0
				MatlabAbs(pcdU, pdUAbs, m_iCols);
				dSum = 0.0;
				for(iIndex = 0; iIndex < m_iCols; iIndex++)
				{
					dSum = dSum + (pdUAbs[iIndex] * pdUAbs[iIndex]);
				}
				
				dMuMax = 1.0 / dSum;

				if(dMu0 > (0.7 * dMuMax))
				{
					dMu0 = 0.7 * dMuMax;
				}
			}

			// Estimated 'y'
			pcdY[iRowIndex].r = 0.0;
			pcdY[iRowIndex].i = 0.0;
			for(iIndex = 0; iIndex < m_iCols; iIndex++)
			{
				/// \note refactor later
				pcdY[iRowIndex].r += ((pcdU[iIndex].r * pcdX[iIndex].r) + (pcdU[iIndex].i * pcdX[iIndex].i));
				pcdY[iRowIndex].i += ((pcdU[iIndex].i * pcdX[iIndex].r) - (pcdU[iIndex].r * pcdX[iIndex].i));
			}

			// Error
			pcdE[iRowIndex].r = pcdB[iRowIndex].r - pcdY[iRowIndex].r;
			pcdE[iRowIndex].i = pcdB[iRowIndex].i - pcdY[iRowIndex].i;
			pdEAbs[iRowIndex] = MatlabAbs(pcdE[iRowIndex]);

			// Start with big mu for speeding the convergence then slow down to reach the correct weights
			if(iRowIndex < (200 - 1))
			{
				dMu = dMu0;
			}
			else if(iRowIndex < (500 - 1))
			{
				dMu = 0.7 * dMu0;
			}
			else if(iRowIndex < (1000 - 1))
			{
				dMu = 0.4 * dMu0;
			}
			else if(iRowIndex < (1600 - 1))
			{
				dMu = 0.1 * dMu0;
				if(dMu > 1)
				{
					dMu = 0.1;
				}
			}
			else
			{
				dMu = 0.01;
			}

			// Adjust weights
			for(iIndex = 0; iIndex < m_iCols; iIndex++)
			{
				cdTemp.r = (pcdU[iIndex].r * pcdE[iRowIndex].r) + (pcdU[iIndex].i * pcdE[iRowIndex].i);
				cdTemp.i = (pcdU[iIndex].i * pcdE[iRowIndex].r) - (pcdU[iIndex].r * pcdE[iRowIndex].i);
				pcdX[iIndex].r = pcdX[iIndex].r + dMu * cdTemp.r;
				pcdX[iIndex].i = pcdX[iIndex].i + dMu * cdTemp.i;
			}
		}
		
		for(iIndex = 0; iIndex < m_iRows; iIndex++)
		{
			pdTime[iIndex] = iIndex + 1;
		}
		
		// Plot
		CREATE_NTDIALOG_MODELESS(pAbsError);
		pAbsError->AddData(pdTime, pdEAbs, m_iRows);
		pAbsError->SetDataProperties(0, 'b', 1, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);
		pAbsError->SetYLabel(_T("MSE"));
		pAbsError->SetXLabel(_T("Time"));
		pAbsError->MyAutoFixAxis();
		pAbsError->ShowLegend(0);

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pcdU);
		SAFE_DELETE_ARRAY(pcdY);
		SAFE_DELETE_ARRAY(pcdE);
		SAFE_DELETE_ARRAY(pdEAbs);
		SAFE_DELETE_ARRAY(pdTime);
		SAFE_DELETE_ARRAY(pdUAbs);

		throw;
	}

	SAFE_DELETE_ARRAY(pcdU);
	SAFE_DELETE_ARRAY(pcdY);
	SAFE_DELETE_ARRAY(pcdE);
	SAFE_DELETE_ARRAY(pdEAbs);
	SAFE_DELETE_ARRAY(pdTime);
	SAFE_DELETE_ARRAY(pdUAbs);

	return;
}
