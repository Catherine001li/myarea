/// \file ModelBaseClass.h
/// Header file for base class for models

#pragma once

#include "f2c.h"
#include "..\nsmfunctions.h"

/// \interface ModelBaseClass
/// base class for models
class ModelBaseClass
{
public:
	ModelBaseClass(void);
	virtual ~ModelBaseClass(void);
	virtual void RunModel(void) = 0;		///< Virutal Function
	void SaveParameters(doublecomplex* pcdCoeff, int iLength, CString csLUTFilename, CString csPhaseOffsetFilename, CString csModelParametersFilename);
	
	void SetInputFiles(CString csFilenameInI, CString csFilenameInQ, BOOL bInputIQ, CString csFilenameOutI, CString csFilenameOutQ, BOOL bOutputIQ);
	void SetFilepath(CString csFilepath);
	void SetSolverSettings(METHOD_TYPE eMethodType, bool bAppType, int iTaps, int iOrder, FILTER_TYPE eFilterType, double dDelta, double dLambda, double dMu);
	void SetAttenuationSettings(double dInputAttenuation, double dOutputAttenuation);
	void SetTypeNames(CString csSystemType, CString csSignalType);
	void SetLUTSettings(LUT_ALGORITHM eLUTAlgorithm, double dLUTTruncate, int iLUTSize);
	bool OpenFiles();

	void NMSEdBVarFunc(double* pdSim, double* pdDes, int iLength, double* pdNMSE, double* pdNMSEdB, double* pdVar, double* pdVardB, double* pdPAR, double* pdPARdB);
	void NMSEdBVarFunc(doublecomplex* pcdSim, doublecomplex* pcdDes, int iLength, double* pdNMSE, double* pdNMSEdB, double* pdVar, double* pdVardB, double* pdPAR, double* pdPARdB);
	void SetRunningSetting(int iExtractLUT, int iExtractFilter, int iFilterIdentification);
	void SetLinearGainFilename(CString csFilename);
	void SetSpectrumParameters(SPECTRUM_PARAMS& rsSpectrumParams);
	void DisplayInputMaxSSG();

protected:
	void GetSmallSignalParameters(double* pdSmallSignal, double* pdPhaseOffset, double* pdPhaseOffsetDPD = NULL, double* pdPhaseOffsetPostDPD = NULL);
	void SavePolynomialCoefficients(doublecomplex* pdCoeffs, int iLength, CString csADSFilename, CString csTXTFilename);
	void MakeLUTWithPoly(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double* pdMagInLUT, double* pdGainLUT, double* pdPhaseLUT, double* pdOffsetLUT);
	void MakeLUTWithPoly(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, MAGGAINPHASE* psOutputLUT, double* pdOffsetLUT, int iDataBits);
	void TimeToPowerDomain(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, int iDataBits, double dPinCutTh, double* pdMagInLUT, double* pdGainLUT, double* pdPhaseLUT, int* piLUTSize);
	int DownsamplingAveragewithoutInterpolationKeepLargeSignal(int iMaxDSPoints, int iLargeSignalPoints, double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double* pdMagInDown, double* pdGainDown, double* pdPhaseDown);
	int DownsamplingAveragewithoutInterpolation(int iMaxPoints, double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double* pdMagInDown, double* pdGainDown, double* pdPhaseDown);
	int LagrangeInterpolation(double* pdYin, int iLength, int iGranul, int iOrder, double* pdXout, double* pdYout, int iComputeLength = 0);
	void MakePALUT(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double* pdMagInLUT, double* pdGainLUT, double* pdPhaseLUT, int iLUTLength);

	// Member Variables
	CString m_csFilenameInI;			///< Filename for Input I
	CString m_csFilenameInQ;			///< Filename for Input Q
	CString m_csFilenameOutI;			///< Filename for Output I
	CString m_csFilenameOutQ;			///< Filename for Output Q
	BOOL m_bInputIQ;					///< Flag if Input contains both I/Q
	BOOL m_bOutputIQ;					///< Flag if Output contains both I/Q
	
	CString m_csFilepath;				///< Filepath to store output files
	
	MODEL_TYPE m_eModelType;			///< Model type used (only for converting to string)
	CString m_csModelType;				///< Specific string for Model type
	METHOD_TYPE m_eMethodType;			///< Method type used to solve function (SVD, RLS...)
	CString m_csMethodType;				///< Specific string for Method type
	bool m_bAppType;					///< true for DPD, false for PA
	CString m_csAppType;				///< Specific string for forward/reverse mdoel
	int m_iTaps;						///< Number of taps
	int m_iOrder;						///< Order of algorithm

	FILTER_TYPE m_eFilterType;			///< Filter type
	CString m_csFilterType;				///< Specific string for Filter type
	double m_dDelta;					///< Regularization parameter for QR-RLS/RLS
	double m_dLambda;					///< Regression parameter for QR-RLS/RLS
	double m_dMu;						///< Training parameter for LMS

	double m_dInputAttenuation;			///< Input Attenuation of the PA
	double m_dOutputAttenuation;		///< Output Attenuation of the PA

	CString m_csSystemType;				///< Name of the system type
	CString m_csSignalType;				///< Name of the signal type

	LUT_ALGORITHM m_eLUTAlgorithm;		///< LUT Algorithm
	CString m_csLUTAlgorithm;			///< Specific string for LUT Algorithm
	double m_dLUTTruncate;				///< dB which to truncate LUT
	int m_iLUTSize;						///< LUT Size

	double* m_pdInputI;					///< Pointer to allocated memory for Input I
	double* m_pdInputQ;					///< Pointer to allocated memory for Input Q
	double* m_pdOutputI;				///< Pointer to allocated memory for Output I
	double* m_pdOutputQ;				///< Pointer to allocated memory for Output Q
	int m_iLength;						///< Length of input vectors read, min(length(inputI, inputQ, outputI, outputQ)).

	int m_iExtractFilter;				///< Setting for Extracting Filter
	int m_iExtractLUT;					///< Setting for Extracting LUT
	int m_iFilterIdentification;		///< Setting for Filter Identification

//	CString m_csMDFOutputFilename;			///< .mdf output filename
//	CString m_csTXTOutputFilename;			///< .txt output filename
//	CString m_csLUTOutputFilename;			///< the LUT filename
//	CString m_csPhaseOffsetOutputFilename;	///< phase offset filename (?)
//	CString m_csModelParamOutputFilename;	///< Model parameters output filename
	CString m_csLinearGainFilename;			///< the linear gain filename

	SPECTRUM_PARAMS m_sSpectrumParams;		///< Spectrum Parameters
private:

};

