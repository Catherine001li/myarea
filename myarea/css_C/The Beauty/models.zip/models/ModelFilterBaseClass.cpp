/// \file ModelFilterBaseClass.cpp
/// Implementation file for class ModelFilterBaseClass

#include "stdafx.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "ModelFilterBaseClass.h"
#include "..\nsmfunctions.h"
#include "..\MATLAB\MatlabFunctions.h"
#include "..\MyExceptionTrace.h"
#include "..\resource.h"
#include "..\NtGraphDialog.h"
#include "..\PlotUtility.h"
#include "ConvertToMatrix.h"
#include "SolverSVD.h"
#include "SolverRLS.h"
#include "SolverQRRLS.h"
#include "SolverLMS.h"
#include "..\global.h"

////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for ModelFilterBaseClass.
/// Calls base class constructor ModelBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
ModelFilterBaseClass::ModelFilterBaseClass(void) : ModelBaseClass()
{
	m_bSmallSignalGain = false;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for ModelFilterBaseClass.
/// Implicitly calls ModelBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
ModelFilterBaseClass::~ModelFilterBaseClass(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Generates the LUT based on the current LUT setting.
/// Basically does a if/else statement on the current LUT Algorithm.
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::GenerateLUT()
{
	// If the Extract LUT box has not been checked, exit.
	if(!m_iExtractLUT)
	{
		return;
	}

	// If none of the files have been opened, then exit
	if(m_pdInputI == NULL || m_pdInputQ == NULL || m_pdOutputI == NULL || m_pdOutputQ == NULL)
		return;

	// Now, perform a switch on the LUTAlg.
	switch(m_eLUTAlgorithm)
	{
		case LUT_ALGORITHM_EWMA:
			m_iTraining = 80;
			GenerateLUTwithEWMA();
			break;
		case LUT_ALGORITHM_POLY:
			m_iTraining = 50;
			GenerateLUTwithPoly();
			break;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Generates the LUT using EWMA function
/// Note: Did not refactor this function, because it seems easier to debug when
/// compared to the matlab file.
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/LUTwithnewDEWMA.m"> LUTwithnewDEWMA.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::GenerateLUTwithEWMA(void)
{
	doublecomplex* pcdInputTrun = NULL;
	doublecomplex* pcdOutputTrun = NULL;
	doublecomplex* pcdInputTrained = NULL;
	doublecomplex* pcdOutputTrained = NULL;
	int iLengthTrun;
	int iIndex;
	double dOffsetIn;
	double dOffsetOut;
	double dUpperLimitRatio;
	double dLowerLimitRatio;
	int iNumTrainingData;
	int iNumActualTrainedData;
	int iMovingAverageExecution = 150;
	MAGGAINPHASE sPALUT = MAGGAINPHASE_INIT;
	MAGGAINPHASE sDPDLUT = MAGGAINPHASE_INIT;
	MAGGAINPHASE sPostDPDLUT = MAGGAINPHASE_INIT;
	double dPhaseOffset;
	double dGainMax;
	double dGainLinear;
	double* pdGainLUTNormalized = NULL;
	doublecomplex* pcdOutputTrainedNormalized = NULL;
	double dPhaseOffsetDPD;
	double* pdMagInDPDOrg = NULL;
	double* pdMagOutDPDOrg = NULL;
	double* pdGainDPDOrg = NULL;
	double* pdPhaseDPDOrg = NULL;
	double* pdPhaseDPDOrgPreUnwrap = NULL;
	doublecomplex cdA, cdB, cdC;
	doublecomplex* pcdInputTrainedWithGain = NULL;
	double dPhaseOffsetPostDPD;
	double* pdIPALUT = NULL;
	double* pdQPALUT = NULL;
	double* pdIDPDLUT = NULL;
	double* pdQDPDLUT = NULL;
	double* pdIPostDPDLUT = NULL;
	double* pdQPostDPDLUT = NULL;
	double dMaxMagInDPDOrg, dMaxMagInDPDLUT, dMaxDPDMagDiff, dMinMagInDPDLUT;
	double dMaxMagInPALUT, dMinMagInPALUT;
	double dLowerBound, dUpperBoundDPD, dUpperBoundPA;
	double dAmpDPD, dAmpPA, dOffsetDPD, dOffsetPA;
	double* pdMagInLUTdB = NULL;
	double* pdMagInDPDLUTdB = NULL;
	double* pdMagInPostDPDLUTdB = NULL;
	double* pdGainLUTdB = NULL;
	double* pdGainDPDLUTdB = NULL;
	double* pdGainPostDPDLUTdB = NULL;
	double* pdGainLUTNormalizeddB = NULL;
	double dMagInCutTh;
	int iCutIndex;
	double dDPDGainOffset;
	double dDPDPhaseOffset;
	double dPostDPDGainOffset;
	double dPostDPDPhaseOffset;
	double dPAGainOffset;
	double dPAPhaseOffset;
	int iADSLUTSize;
	double* pdPhaseLUTNorm = NULL;
	double* pdPhaseDPDLUTNorm = NULL;
	double* pdPhasePostDPDLUTNorm = NULL;
	double* pdXTemp = NULL;
	double* pdYTemp = NULL;

	CString csFilename;
	MAGGAINPHASE sTempContainer;
	CNtGraphDialog* pAMAM;
	CNtGraphDialog* pAMPM;
	CNtGraphDialog* pAMAMPost;


	try
	{
		// Already Opened the files before reaching here
		
		// Remove the first 1000 data
		iLengthTrun = m_iLength - 1000;
		pcdInputTrun = new doublecomplex[iLengthTrun];
		pcdOutputTrun = new doublecomplex[iLengthTrun];

		for(iIndex = 0; iIndex < iLengthTrun; iIndex++)
		{
			pcdInputTrun[iIndex].r = m_pdInputI[iIndex + 1000];
			pcdInputTrun[iIndex].i = m_pdInputQ[iIndex + 1000];
			pcdOutputTrun[iIndex].r = m_pdOutputI[iIndex + 1000];
			pcdOutputTrun[iIndex].i = m_pdOutputQ[iIndex + 1000];
		}

		dOffsetIn = pow(10, m_dInputAttenuation / 20.0);
		dOffsetOut = pow(10, m_dOutputAttenuation / 20.0);

		dUpperLimitRatio = 0.8;
		dLowerLimitRatio = 100;
		iNumTrainingData = m_iTraining * 128;

		// Call training data
		// before that, initialize the incoming variables to the correct size
		// this should be done by the calling function, but made it not so
		iNumActualTrainedData = ExtractModelTrainingData(pcdInputTrun, pcdOutputTrun, iLengthTrun, iNumTrainingData, pcdInputTrained, pcdOutputTrained, 1);
		pcdInputTrained = new doublecomplex[iNumActualTrainedData];
		pcdOutputTrained = new doublecomplex[iNumActualTrainedData];
		ExtractModelTrainingData(pcdInputTrun, pcdOutputTrun, iLengthTrun, iNumTrainingData, pcdInputTrained, pcdOutputTrained);
		
		// Divide by Offsets
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			pcdInputTrained[iIndex].r = pcdInputTrained[iIndex].r / dOffsetIn;
			pcdInputTrained[iIndex].i = pcdInputTrained[iIndex].i / dOffsetIn;
			pcdOutputTrained[iIndex].r = pcdOutputTrained[iIndex].r * dOffsetOut;
			pcdOutputTrained[iIndex].i = pcdOutputTrained[iIndex].i * dOffsetOut;
		}

		// Execute smoothing function for X number of times.
		DeembedNonlinearityDEWMA(iMovingAverageExecution, pcdInputTrained, pcdOutputTrained, iNumActualTrainedData, m_iLUTSize, m_dLUTTruncate, &sPALUT, &dPhaseOffset);

		// Now create the DPD look-up Table
		// dGainMax = MatlabMax(sPALUT.m_pdGain, sPALUT.m_iLength);
		dGainLinear = MatlabMax(&sPALUT.m_pdGain[(sPALUT.m_iLength / 2) - 1], sPALUT.m_iLength / 2);

		// Normalize the gain LUT
		pdGainLUTNormalized = new double[sPALUT.m_iLength];
		for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
		{
			pdGainLUTNormalized[iIndex] = sPALUT.m_pdGain[iIndex] / dGainLinear;
		}

		// Normalize the trained Y
		pcdOutputTrainedNormalized = new doublecomplex[iNumActualTrainedData];
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			pcdOutputTrainedNormalized[iIndex].r = pcdOutputTrained[iIndex].r / dGainLinear;
			pcdOutputTrainedNormalized[iIndex].i = pcdOutputTrained[iIndex].i / dGainLinear;
		}

		// Take trained Y over trained X to get the DPD LUT
		// DeembedNonlinearityDEWMA(iMovingAverageExecution, pcdOutputTrainedNormalized, pcdInputTrained, iNumActualTrainedData, m_iLUTSize, m_dLUTTruncate, &sDPDLUT, &dPhaseOffsetDPD);
		
		// Rotate phase so that it begins at 0
		dPhaseOffset += sPALUT.m_pdPhase[0];
		for(iIndex = sPALUT.m_iLength - 1; iIndex >= 0; iIndex--)
		{
			sPALUT.m_pdPhase[iIndex] -= sPALUT.m_pdPhase[0];
		}
		// Small Signal Gain selected is the first gain in the LUT
		dGainLinear = sPALUT.m_pdGain[0];
		// Phase offset for DPD should be -PA Phase
		dPhaseOffsetDPD = -dPhaseOffset;
		GenerateDPD(sPALUT, sDPDLUT, m_dLUTTruncate, 20 * log10(dGainLinear), 0.0, m_iLUTSize);
		
		// Compute Some Variables
		pdMagInDPDOrg = new double[iNumActualTrainedData];
		pdMagOutDPDOrg = new double[iNumActualTrainedData];
		pdPhaseDPDOrgPreUnwrap =  new double[iNumActualTrainedData];
		pdPhaseDPDOrg = new double[iNumActualTrainedData];
		pdGainDPDOrg = new double[iNumActualTrainedData];
		MatlabAbs(pcdOutputTrainedNormalized, pdMagInDPDOrg, iNumActualTrainedData);
		MatlabAbs(pcdInputTrained, pdMagOutDPDOrg, iNumActualTrainedData);
		
		// This is for the line inside the unwrap function
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			cdA.r = pcdOutputTrainedNormalized[iIndex].r;
			cdA.i = -1.0 * pcdOutputTrainedNormalized[iIndex].i;

			cdB.r = pcdInputTrained[iIndex].r;
			cdB.i = pcdInputTrained[iIndex].i;
			
			ComplexMultiply(&cdA, &cdB, &cdC);

			pdPhaseDPDOrgPreUnwrap[iIndex] = atan2(cdC.i, cdC.r);
		}
		MatlabUnwrap(pdPhaseDPDOrgPreUnwrap, pdPhaseDPDOrg, iNumActualTrainedData);
		VectorDivide(pdMagOutDPDOrg, pdMagInDPDOrg, iNumActualTrainedData, pdGainDPDOrg);

		// Extract the post-distortion LUT
		pcdInputTrainedWithGain = new doublecomplex[iNumActualTrainedData];
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			//pcdInputTrainedWithGain[iIndex].r = pcdInputTrained[iIndex].r * dGainLinear;
			//pcdInputTrainedWithGain[iIndex].i = pcdInputTrained[iIndex].i * dGainLinear;
			pcdInputTrainedWithGain[iIndex].r = pcdInputTrained[iIndex].r * 1.0;
			pcdInputTrainedWithGain[iIndex].i = pcdInputTrained[iIndex].i * 1.0;
		}

		//DeembedNonlinearityDEWMA(iMovingAverageExecution, pcdOutputTrained, pcdInputTrainedWithGain, iNumActualTrainedData, m_iLUTSize, m_dLUTTruncate, &sPostDPDLUT, &dPhaseOffsetPostDPD);
		dPhaseOffsetPostDPD = -dPhaseOffset;
		GenerateDPD(sPALUT, sPostDPDLUT, m_dLUTTruncate + m_dOutputAttenuation, 0.0, 0.0, m_iLUTSize);


		// save the post distortion LUT to a file, actually maybe convert to archive if needed
		// Mar 27/08
		// commented out file generation
		// SaveLUTwithPhaseOffset(m_csFilepath + _T("postDPD_LUT.txt"), sPostDPDLUT.m_pdMagIn, sPostDPDLUT.m_pdGain, sPostDPDLUT.m_pdPhase, sPostDPDLUT.m_iLength, dPhaseOffsetPostDPD);

		// Save Phase Offsets
		SavePhaseOffset(dGainLinear, dPhaseOffset, dPhaseOffsetDPD, dPhaseOffsetPostDPD);

		// Convert the polar to rectangular
		pdIPALUT = new double[sPALUT.m_iLength];
		pdQPALUT = new double[sPALUT.m_iLength];
		pdIDPDLUT = new double[sDPDLUT.m_iLength];
		pdQDPDLUT = new double[sDPDLUT.m_iLength];
		pdIPostDPDLUT = new double[sPostDPDLUT.m_iLength];
		pdQPostDPDLUT = new double[sPostDPDLUT.m_iLength];

		// Knowing that all lengths are the same...
		for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
		{
			pdIPALUT[iIndex] = sPALUT.m_pdGain[iIndex] * cos(sPALUT.m_pdPhase[iIndex]);
			pdQPALUT[iIndex] = sPALUT.m_pdGain[iIndex] * sin(sPALUT.m_pdPhase[iIndex]);
			pdIDPDLUT[iIndex] = sDPDLUT.m_pdGain[iIndex] * cos(sDPDLUT.m_pdPhase[iIndex]);
			pdQDPDLUT[iIndex] = sDPDLUT.m_pdGain[iIndex] * sin(sDPDLUT.m_pdPhase[iIndex]);
			pdIPostDPDLUT[iIndex] = sPostDPDLUT.m_pdGain[iIndex] * cos(sPostDPDLUT.m_pdPhase[iIndex]);
			pdQPostDPDLUT[iIndex] = sPostDPDLUT.m_pdGain[iIndex] * sin(sPostDPDLUT.m_pdPhase[iIndex]);
		}

		// Compute some normalization parameters, and save to a file
		// Calculate DPD LUT index normalization parameters
		dMaxMagInDPDOrg = MatlabMax(pdMagInDPDOrg, iNumActualTrainedData);
		dMaxMagInDPDLUT = MatlabMax(sDPDLUT.m_pdMagIn, sDPDLUT.m_iLength);
		dMaxDPDMagDiff = dMaxMagInDPDOrg - dMaxMagInDPDLUT;
		dMinMagInDPDLUT = 0;
		dLowerBound = 0;
		dUpperBoundDPD = 1;
		dAmpDPD = (dUpperBoundDPD - dLowerBound) / (dMaxMagInDPDLUT - dMinMagInDPDLUT);
		dOffsetDPD = dUpperBoundDPD - dAmpDPD * dMaxMagInDPDLUT;
		
		// Calculate PA LUT index normalization parameters
		dMaxMagInPALUT = MatlabMax(sPALUT.m_pdMagIn, sPALUT.m_iLength);
		dMinMagInPALUT = 0;
		dLowerBound = 0;
		dUpperBoundPA = 1;
		dAmpPA = (dUpperBoundPA - dLowerBound) / (dMaxMagInPALUT - dMinMagInPALUT);
		dOffsetPA = dUpperBoundPA - dAmpPA * dMaxMagInPALUT;

		SaveNormalizationParameters(dAmpPA, dOffsetPA, dMaxMagInPALUT, dUpperBoundPA,
									dAmpDPD, dOffsetDPD, dMaxMagInDPDLUT, dUpperBoundDPD);


		// Save PA LUT
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
		SaveLUT(csFilename, &sPALUT);

		// Save DPD LUT
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		SaveLUT(csFilename, &sDPDLUT);
		
		csFilename.Format(_T("%s%s_%s_DPD_MaginIQ_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		sTempContainer.m_pdMagIn = sDPDLUT.m_pdMagIn;
		sTempContainer.m_pdGain = pdIDPDLUT;
		sTempContainer.m_pdPhase = pdQDPDLUT;
		sTempContainer.m_iLength = sDPDLUT.m_iLength;
		// Mar 27/08
		// commented out file generation
		// SaveLUT(csFilename, &sTempContainer);

		// Save Post DPD LUT
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_POST_COMPENSATION_NAME);
		SaveLUT(csFilename, &sPostDPDLUT);
		
		// Mar 27/08
		// commented out file generation
		 csFilename.Format(_T("%s%s_%s_postDPD_MaginIQ_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		sTempContainer.m_pdMagIn = sPostDPDLUT.m_pdMagIn;
		sTempContainer.m_pdGain = pdIPostDPDLUT;
		sTempContainer.m_pdPhase = pdQPostDPDLUT;
		sTempContainer.m_iLength = sPostDPDLUT.m_iLength;
		//SaveLUT(csFilename, &sTempContainer);

		// Save baseband data
		// Mar 27/08
		// commented out file generation
		// csFilename.Format(_T("%s%s_%s_DPD_IQ_LUT_nonlinearity_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		// SaveBasebandADSFile(csFilename, pdIDPDLUT, pdQDPDLUT, sDPDLUT.m_iLength);
		//csFilename.Format(_T("%s%s_%s_PA_IQ_LUT_nonlinearity_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		//SaveBasebandADSFile(csFilename, pdIPALUT, pdQPALUT, sPALUT.m_iLength);

		// Convert to dB Values
		pdMagInLUTdB = new double[sPALUT.m_iLength];
		pdMagInDPDLUTdB = new double[sDPDLUT.m_iLength];
		pdMagInPostDPDLUTdB = new double[sPostDPDLUT.m_iLength];
		pdGainLUTdB = new double[sPALUT.m_iLength];
		pdGainDPDLUTdB = new double[sDPDLUT.m_iLength];
		pdGainPostDPDLUTdB = new double[sPostDPDLUT.m_iLength];
		pdGainLUTNormalizeddB = new double[sPALUT.m_iLength];
		pdPhaseLUTNorm =  new double[sPALUT.m_iLength];
		pdPhaseDPDLUTNorm = new double[sDPDLUT.m_iLength];
		pdPhasePostDPDLUTNorm = new double[sPostDPDLUT.m_iLength];

		/// \bug definately a bug, line 295 in LUTwithnewDEWMA.m, gain_post_dpd_lut_dB derived from gain_dpd_lut
		// Know that they are all the same length
		for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
		{
			pdMagInLUTdB[iIndex] = 10 * log10((0.5 * pow(sPALUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdMagInDPDLUTdB[iIndex] = 10 * log10((0.5 * pow(sDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdMagInPostDPDLUTdB[iIndex] = 10 * log10((0.5 * pow(sPostDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdGainLUTdB[iIndex] = 20 * log10(sPALUT.m_pdGain[iIndex]);
			pdGainDPDLUTdB[iIndex] = 20 * log10(sDPDLUT.m_pdGain[iIndex]);
			pdGainPostDPDLUTdB[iIndex] = 20 * log10(sPostDPDLUT.m_pdGain[iIndex]);
			pdGainLUTNormalizeddB[iIndex] = 20 * log10(pdGainLUTNormalized[iIndex]);
			pdPhaseLUTNorm[iIndex] = sPALUT.m_pdPhase[iIndex];
			pdPhaseDPDLUTNorm[iIndex] = sDPDLUT.m_pdPhase[iIndex];
			pdPhasePostDPDLUTNorm[iIndex] = sPostDPDLUT.m_pdPhase[iIndex];
		}

		// Discard all data corresponding < -70 dBm
		dMagInCutTh = -70;
		iCutIndex = 0;
		
		for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
		{
			if(pdMagInLUTdB[iIndex] >= dMagInCutTh)
			{
				iCutIndex = iIndex;
				break;
			}
		}

		iADSLUTSize = sPALUT.m_iLength - iCutIndex;

		// Shift without creating new data structures
		// all gain_*_dB1 MATLAB variables are not used later.

		// Mar 27/08
		// Do not normalize
		dDPDGainOffset = 0;//pdGainDPDLUTdB[iCutIndex];
		dDPDPhaseOffset = 0;//pdPhaseDPDLUTNorm[iCutIndex];
		dPostDPDGainOffset = 0;//pdGainPostDPDLUTdB[iCutIndex];
		dPostDPDPhaseOffset = 0;//pdPhasePostDPDLUTNorm[iCutIndex];
		dPAGainOffset = 0;//pdGainLUTdB[iCutIndex];
		dPAPhaseOffset = 0;//pdPhaseLUTNorm[iCutIndex];

		for(iIndex = 0; iIndex < iADSLUTSize; iIndex++)
		{
			// DPD Part
			pdGainDPDLUTdB[iIndex] = pdGainDPDLUTdB[iIndex + iCutIndex] - dDPDGainOffset;
			pdPhaseDPDLUTNorm[iIndex] = pdPhaseDPDLUTNorm[iIndex + iCutIndex] - dDPDPhaseOffset;
			pdMagInDPDLUTdB[iIndex] = pdMagInDPDLUTdB[iIndex + iCutIndex];

			// Post DPD Part
			pdGainPostDPDLUTdB[iIndex] = pdGainPostDPDLUTdB[iIndex + iCutIndex] - dPostDPDGainOffset;
			pdPhasePostDPDLUTNorm[iIndex] = pdPhasePostDPDLUTNorm[iIndex + iCutIndex] - dPostDPDPhaseOffset;
			pdMagInPostDPDLUTdB[iIndex] = pdMagInPostDPDLUTdB[iIndex + iCutIndex];

			// PA Part
			pdGainLUTdB[iIndex] = pdGainLUTdB[iIndex + iCutIndex] - dPAGainOffset;
			pdPhaseLUTNorm[iIndex] = pdPhaseLUTNorm[iIndex + iCutIndex] - dPAPhaseOffset;
			pdMagInLUTdB[iIndex] = pdMagInLUTdB[iIndex + iCutIndex];
		}

		// Save gain start point to a mdf file
		csFilename.Format(_T("%s%s_%s_LUT_GainOffset.mdf"), m_csFilepath, m_csSystemType, m_csSignalType);
		SaveMDFGainStartingPoint(csFilename, dDPDGainOffset, dPAGainOffset);

		// Save LUTs in ADS format
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
		SaveLUTADS(csFilename, pdMagInLUTdB, pdGainLUTdB, pdPhaseLUTNorm, iADSLUTSize);

		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		SaveLUTADS(csFilename, pdMagInDPDLUTdB, pdGainDPDLUTdB, pdPhaseDPDLUTNorm, iADSLUTSize);

		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_POST_COMPENSATION_NAME);
		SaveLUTADS(csFilename, pdMagInPostDPDLUTdB, pdGainPostDPDLUTdB, pdPhasePostDPDLUTNorm, iADSLUTSize);

		// Plot AM-AM and AM-PM

		// Since I overwrote the vectors and did not want to recreate new ones, redo all dB calculations
		// overallocating
		if(!m_bSmallSignalGain)
		{
			/// \bug, xTemp and yTemp should be max(iNumActualTrainedData)
			//pdXTemp = new double[iNumActualTrainedData];
			//pdYTemp = new double[iNumActualTrainedData];
			/*
			pdXTemp = (iNumActualTrainedData > sPALUT.m_iLength) ? new double[iNumActualTrainedData] : new double[sPALUT.m_iLength];
			pdYTemp = (iNumActualTrainedData > sPALUT.m_iLength) ? new double[iNumActualTrainedData] : new double[sPALUT.m_iLength];

			CREATE_NTDIALOG_MODELESS(pAMAM);
			for(iIndex = 0; iIndex < sDPDLUT.m_iLength; iIndex++)
			{
				pdXTemp[iIndex] = 10 * log10((0.5 * pow(sDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
				pdYTemp[iIndex] = 20 * log10(sDPDLUT.m_pdGain[iIndex]);
			}
			pAMAM->AddData(pdXTemp, pdYTemp, sPALUT.m_iLength, _T("DPD LUT"));
			pAMAM->SetDataProperties(0, 'b', 2, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);
			
			for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
			{
				pdXTemp[iIndex] = 10 * log10((0.5 * pow(sPALUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			}
			pAMAM->AddData(pdXTemp, pdGainLUTNormalizeddB, iADSLUTSize, _T("Normalized Gain"));
			pAMAM->SetDataProperties(1, 'r', 2, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);
			pAMAM->SetTitle(_T("AM-AM"));
			pAMAM->SetYLabel(_T("Gain (dB)"));
			pAMAM->SetXLabel(_T("Pin (dBm)"));
			pAMAM->MyAutoFixAxis();
			pAMAM->ShowLegend(0);


			CREATE_NTDIALOG_MODELESS(pAMPM);
			// Mar 27/08
			// Rotate phases
			RotatePhase(sPALUT.m_pdPhase, sPALUT.m_iLength, true);
			RotatePhase(sDPDLUT.m_pdPhase, sDPDLUT.m_iLength, true);
			for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
			{
				pdXTemp[iIndex] = 10 * log10((0.5 * pow(sDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
				pdYTemp[iIndex] = sDPDLUT.m_pdPhase[iIndex] * 180 / M_PI;
			}
			pAMPM->AddData(pdXTemp, pdYTemp, sPALUT.m_iLength, _T("DPD phase LUT"));
			pAMPM->SetDataProperties(0, 'b', 2, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);

			for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
			{
				pdXTemp[iIndex] = 10 * log10((0.5 * pow(sPALUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
				pdYTemp[iIndex] = sPALUT.m_pdPhase[iIndex] * 180 / M_PI;
			}
			pAMPM->AddData(pdXTemp, pdYTemp, sPALUT.m_iLength, _T("PA Phase"));
			pAMPM->SetDataProperties(1, 'r', 2, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);
			pAMPM->SetTitle(_T("AM-PM"));
			pAMPM->SetYLabel(_T("Phase (degree)"));
			pAMPM->SetXLabel(_T("Pin (dBm)"));
			pAMPM->MyAutoFixAxis();
			pAMPM->ShowLegend(0);


			CREATE_NTDIALOG_MODELESS(pAMAMPost);
			// Mar 27/08
			// Adjusted Input Power to reflect change
			for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
			{
				pdXTemp[iIndex] = 10 * log10((0.5 * pow(MatlabAbs(pcdOutputTrained[iIndex]), 2.0)) / 50) + 30;
				pdYTemp[iIndex] = 20 * log10(MatlabAbs(pcdInputTrainedWithGain[iIndex]) / MatlabAbs(pcdOutputTrained[iIndex]));
			}
			pAMAMPost->AddData(pdXTemp, pdYTemp, iNumActualTrainedData, _T("Measurement Data"));
			pAMAMPost->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

			for(iIndex = 0; iIndex < sPostDPDLUT.m_iLength; iIndex++)
			{
				// Abs does nothing here
				pdXTemp[iIndex] = 10 * log10((0.5 * pow(sPostDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
				pdYTemp[iIndex] = 20 * log10(sPostDPDLUT.m_pdGain[iIndex]);
			}
			pAMAMPost->AddData(pdXTemp, pdYTemp, sPostDPDLUT.m_iLength, _T("LUT"));
			pAMAMPost->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);
			pAMAMPost->SetTitle(_T("AM-AM Post"));
			pAMAMPost->SetYLabel(_T("Gain (dB)"));
			pAMAMPost->SetXLabel(_T("Pin (dBm)"));
			pAMAMPost->MyAutoFixAxis();
			pAMAMPost->ShowLegend(0);
			*/
			PlotMemoryless(pcdInputTrained, pcdOutputTrained, iNumActualTrainedData, sPALUT, sDPDLUT, sPostDPDLUT, dGainLinear, dPhaseOffset, dPhaseOffsetDPD, dPhaseOffsetPostDPD);
		}

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_MAGGAINPHASE(sPALUT);
		SAFE_DELETE_MAGGAINPHASE(sDPDLUT);
		SAFE_DELETE_MAGGAINPHASE(sPostDPDLUT);
		SAFE_DELETE_ARRAY(pcdInputTrun);
		SAFE_DELETE_ARRAY(pcdOutputTrun);
		SAFE_DELETE_ARRAY(pcdInputTrained);
		SAFE_DELETE_ARRAY(pcdOutputTrained);
		SAFE_DELETE_ARRAY(pdGainLUTNormalized);
		SAFE_DELETE_ARRAY(pcdOutputTrainedNormalized);
		SAFE_DELETE_ARRAY(pdMagInDPDOrg);
		SAFE_DELETE_ARRAY(pdMagOutDPDOrg);
		SAFE_DELETE_ARRAY(pdGainDPDOrg);
		SAFE_DELETE_ARRAY(pdPhaseDPDOrg);
		SAFE_DELETE_ARRAY(pdPhaseDPDOrgPreUnwrap);
		SAFE_DELETE_ARRAY(pcdInputTrainedWithGain);
		SAFE_DELETE_ARRAY(pdIPALUT);
		SAFE_DELETE_ARRAY(pdQPALUT);
		SAFE_DELETE_ARRAY(pdIDPDLUT);
		SAFE_DELETE_ARRAY(pdQDPDLUT);
		SAFE_DELETE_ARRAY(pdIPostDPDLUT);
		SAFE_DELETE_ARRAY(pdQPostDPDLUT);
		SAFE_DELETE_ARRAY(pdMagInLUTdB);
		SAFE_DELETE_ARRAY(pdMagInDPDLUTdB);
		SAFE_DELETE_ARRAY(pdMagInPostDPDLUTdB);
		SAFE_DELETE_ARRAY(pdGainLUTdB);
		SAFE_DELETE_ARRAY(pdGainDPDLUTdB);
		SAFE_DELETE_ARRAY(pdGainPostDPDLUTdB);
		SAFE_DELETE_ARRAY(pdGainLUTNormalizeddB);
		SAFE_DELETE_ARRAY(pdPhaseLUTNorm);
		SAFE_DELETE_ARRAY(pdPhaseDPDLUTNorm);
		SAFE_DELETE_ARRAY(pdPhasePostDPDLUTNorm);
		SAFE_DELETE_ARRAY(pdXTemp);
		SAFE_DELETE_ARRAY(pdYTemp);

		throw;
	}

	// Epilogue
	SAFE_DELETE_MAGGAINPHASE(sPALUT);
	SAFE_DELETE_MAGGAINPHASE(sDPDLUT);
	SAFE_DELETE_MAGGAINPHASE(sPostDPDLUT);
	SAFE_DELETE_ARRAY(pcdInputTrun);
	SAFE_DELETE_ARRAY(pcdOutputTrun);
	SAFE_DELETE_ARRAY(pcdInputTrained);
	SAFE_DELETE_ARRAY(pcdOutputTrained);
	SAFE_DELETE_ARRAY(pdGainLUTNormalized);
	SAFE_DELETE_ARRAY(pcdOutputTrainedNormalized);
	SAFE_DELETE_ARRAY(pdMagInDPDOrg);
	SAFE_DELETE_ARRAY(pdMagOutDPDOrg);
	SAFE_DELETE_ARRAY(pdGainDPDOrg);
	SAFE_DELETE_ARRAY(pdPhaseDPDOrg);
	SAFE_DELETE_ARRAY(pdPhaseDPDOrgPreUnwrap);
	SAFE_DELETE_ARRAY(pcdInputTrainedWithGain);
	SAFE_DELETE_ARRAY(pdIPALUT);
	SAFE_DELETE_ARRAY(pdQPALUT);
	SAFE_DELETE_ARRAY(pdIDPDLUT);
	SAFE_DELETE_ARRAY(pdQDPDLUT);
	SAFE_DELETE_ARRAY(pdIPostDPDLUT);
	SAFE_DELETE_ARRAY(pdQPostDPDLUT);
	SAFE_DELETE_ARRAY(pdMagInLUTdB);
	SAFE_DELETE_ARRAY(pdMagInDPDLUTdB);
	SAFE_DELETE_ARRAY(pdMagInPostDPDLUTdB);
	SAFE_DELETE_ARRAY(pdGainLUTdB);
	SAFE_DELETE_ARRAY(pdGainDPDLUTdB);
	SAFE_DELETE_ARRAY(pdGainPostDPDLUTdB);
	SAFE_DELETE_ARRAY(pdGainLUTNormalizeddB);
	SAFE_DELETE_ARRAY(pdPhaseLUTNorm);
	SAFE_DELETE_ARRAY(pdPhaseDPDLUTNorm);
	SAFE_DELETE_ARRAY(pdPhasePostDPDLUTNorm);
	SAFE_DELETE_ARRAY(pdXTemp);
	SAFE_DELETE_ARRAY(pdYTemp);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Generates the LUT using Polynomial Function
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/SingleTapPolyLUTNewfunc.m"> SingleTapPolyLUTNewfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::GenerateLUTwithPoly(void)
{
	doublecomplex* pcdInputTrun = NULL;
	doublecomplex* pcdOutputTrun = NULL;
	doublecomplex* pcdInputTrained = NULL;
	doublecomplex* pcdOutputTrained = NULL;
	int iLengthTrun;
	int iIndex;
	double dOffsetIn;
	double dOffsetOut;
	double dUpperLimitRatio;
	double dLowerLimitRatio;
	int iNumTrainingData;
	int iNumActualTrainedData;
	int iMovingAverageExecution = 150;
	MAGGAINPHASE sPALUT = MAGGAINPHASE_INIT;
	MAGGAINPHASE sDPDLUT = MAGGAINPHASE_INIT;
	MAGGAINPHASE sPostDPDLUT = MAGGAINPHASE_INIT;
	double dPhaseOffset;
	double dGainMax;
	double dGainLinear;
	double* pdGainLUTNormalized = NULL;
	doublecomplex* pcdOutputTrainedNormalized = NULL;
	double dPhaseOffsetDPD;
	double* pdMagInDPDOrg = NULL;
	double* pdMagOutDPDOrg = NULL;
	double* pdGainDPDOrg = NULL;
	double* pdPhaseDPDOrg = NULL;
	double* pdPhaseDPDOrgPreUnwrap = NULL;
	doublecomplex cdA, cdB, cdC;
	doublecomplex* pcdInputTrainedWithGain = NULL;
	double dPhaseOffsetPostDPD;
	double* pdIPALUT = NULL;
	double* pdQPALUT = NULL;
	double* pdIDPDLUT = NULL;
	double* pdQDPDLUT = NULL;
	double* pdIPostDPDLUT = NULL;
	double* pdQPostDPDLUT = NULL;
	double dMaxMagInDPDOrg, dMaxMagInDPDLUT, dMaxDPDMagDiff, dMinMagInDPDLUT;
	double dMaxMagInPALUT, dMinMagInPALUT;
	double dLowerBound, dUpperBoundDPD, dUpperBoundPA;
	double dAmpDPD, dAmpPA, dOffsetDPD, dOffsetPA;
	double* pdMagInLUTdB = NULL;
	double* pdMagInDPDLUTdB = NULL;
	double* pdMagInPostDPDLUTdB = NULL;
	double* pdGainLUTdB = NULL;
	double* pdGainDPDLUTdB = NULL;
	double* pdGainPostDPDLUTdB = NULL;
	double* pdGainLUTNormalizeddB = NULL;
	double dMagInCutTh;
	int iCutIndex;
	double dDPDGainOffset;
	double dDPDPhaseOffset;
	double dPostDPDGainOffset;
	double dPostDPDPhaseOffset;
	double dPAGainOffset;
	double dPAPhaseOffset;
	int iADSLUTSize;
	double* pdPhaseLUTNorm = NULL;
	double* pdPhaseDPDLUTNorm = NULL;
	double* pdPhasePostDPDLUTNorm = NULL;
	int iM;

	int iDataBits;
	double dPinCutTh;
	double* pdMagInDPDPowerD = NULL;
	double* pdGainDPDPowerD = NULL;
	double* pdPhaseDPDPowerD = NULL;
	int iPowerDLength;
	double dMaginPhaseTh;
	double dV_phaseth_dB;
	double dV_phaseth;
	double dDPDPhaseOffsetPowerD;
	double* pdMagInDPDPowerDdB = NULL;
	double* pdGainDPDPowerDdB = NULL;
	double* pdPhaseDPDPowerDdeg = NULL;
	MAGGAINPHASE sPAInverseLUT = MAGGAINPHASE_INIT;
	double dPhaseOffsetPAInverse;

	CString csFilename;
	MAGGAINPHASE sTempContainer;

	doublecomplex* pcdW1 = NULL;
	doublecomplex* pcdW2 = NULL;
	doublecomplex* pcdW3 = NULL;
	double* pdXTemp = NULL;
	double* pdYTemp = NULL;
	CNtGraphDialog* pAMAM;
	CNtGraphDialog* pAMPM;
	CNtGraphDialog* pAMAMPost;

	try
	{
		// Already Opened the files before reaching here
		iM = 1;

		// Remove the first 1000 data
		iLengthTrun = m_iLength - 1000;
		pcdInputTrun = new doublecomplex[iLengthTrun];
		pcdOutputTrun = new doublecomplex[iLengthTrun];

		for(iIndex = 0; iIndex < iLengthTrun; iIndex++)
		{
			pcdInputTrun[iIndex].r = m_pdInputI[iIndex + 1000];
			pcdInputTrun[iIndex].i = m_pdInputQ[iIndex + 1000];
			pcdOutputTrun[iIndex].r = m_pdOutputI[iIndex + 1000];
			pcdOutputTrun[iIndex].i = m_pdOutputQ[iIndex + 1000];
		}

		dOffsetIn = pow(10, m_dInputAttenuation / 20.0);
		dOffsetOut = pow(10, m_dOutputAttenuation / 20.0);

		dUpperLimitRatio = 0.8;
		dLowerLimitRatio = 100;
		iNumTrainingData = m_iTraining * 128;

		// Call training data
		// before that, initialize the incoming variables to the correct size
		// this should be done by the calling function, but made it not so
		iNumActualTrainedData = ExtractModelTrainingData(pcdInputTrun, pcdOutputTrun, iLengthTrun, iNumTrainingData, pcdInputTrained, pcdOutputTrained, 1);
		pcdInputTrained = new doublecomplex[iNumActualTrainedData];
		pcdOutputTrained = new doublecomplex[iNumActualTrainedData];
		ExtractModelTrainingData(pcdInputTrun, pcdOutputTrun, iLengthTrun, iNumTrainingData, pcdInputTrained, pcdOutputTrained);
		
		// Divide by Offsets
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			pcdInputTrained[iIndex].r = pcdInputTrained[iIndex].r / dOffsetIn;
			pcdInputTrained[iIndex].i = pcdInputTrained[iIndex].i / dOffsetIn;
			pcdOutputTrained[iIndex].r = pcdOutputTrained[iIndex].r * dOffsetOut;
			pcdOutputTrained[iIndex].i = pcdOutputTrained[iIndex].i * dOffsetOut;
		}

		// Make PA LUT
		//DeembedNonlinearityDEWMA(iMovingAverageExecution, pcdInputTrained, pcdOutputTrained, iNumActualTrainedData, m_iLUTSize, m_dLUTTruncate, &sPALUT, &dPhaseOffset);
		pcdW1 = new doublecomplex[m_iOrder + 1];
		DeembedNonlinearityLSE(iM, m_iOrder, pcdInputTrained, pcdOutputTrained, iNumActualTrainedData, m_dLUTTruncate, &sPALUT, &dPhaseOffset, pcdW1);

		// Now create the DPD look-up Table
		dGainMax = MatlabMax(sPALUT.m_pdGain, sPALUT.m_iLength);
		dGainLinear = MatlabMax(&sPALUT.m_pdGain[(sPALUT.m_iLength / 2) - 1], sPALUT.m_iLength / 2);

		// Normalize the gain LUT
		pdGainLUTNormalized = new double[sPALUT.m_iLength];
		for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
		{
			pdGainLUTNormalized[iIndex] = sPALUT.m_pdGain[iIndex] / dGainMax;
		}

		// Normalize the trained Y
		pcdOutputTrainedNormalized = new doublecomplex[iNumActualTrainedData];
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			pcdOutputTrainedNormalized[iIndex].r = pcdOutputTrained[iIndex].r / dGainLinear;
			pcdOutputTrainedNormalized[iIndex].i = pcdOutputTrained[iIndex].i / dGainLinear;
		}

		// Take trained Y over trained X to get the DPD LUT
//		DeembedNonlinearityDEWMA(iMovingAverageExecution, pcdOutputTrainedNormalized, pcdInputTrained, iNumActualTrainedData, m_iLUTSize, m_dLUTTruncate, &sDPDLUT, &dPhaseOffsetDPD);
		pcdW2 = new doublecomplex[m_iOrder + 1];
		//DeembedNonlinearityLSE(iM, m_iOrder, pcdOutputTrainedNormalized, pcdInputTrained, iNumActualTrainedData, m_dLUTTruncate, &sDPDLUT, &dPhaseOffsetDPD, pcdW2);
		
		// Rotate the phase so that it begins at 0
		dPhaseOffset += sPALUT.m_pdPhase[0];
		for(iIndex = sPALUT.m_iLength - 1; iIndex >= 0; iIndex--)
		{
			sPALUT.m_pdPhase[iIndex] -= sPALUT.m_pdPhase[0];
		}
		// Small Signal Gain selected is the first gain in the LUT
		dGainLinear = sPALUT.m_pdGain[0];
		// Phase offset for DPD should be -PAPhase
		dPhaseOffsetDPD = -dPhaseOffset;
		GenerateDPD(sPALUT, sDPDLUT, m_dLUTTruncate, 20 * log10(dGainLinear), 0.0, m_iLUTSize);

		// I don't think this section of code is used, however, it is implemented for completeness
		// Calculate measurement DPD data in power domain
		iDataBits = 12;
		dPinCutTh = -40;

		// Compute Some Variables
		pdMagInDPDOrg = new double[iNumActualTrainedData];
		pdMagOutDPDOrg = new double[iNumActualTrainedData];
		pdPhaseDPDOrgPreUnwrap =  new double[iNumActualTrainedData];
		pdPhaseDPDOrg = new double[iNumActualTrainedData];
		pdGainDPDOrg = new double[iNumActualTrainedData];
		MatlabAbs(pcdOutputTrainedNormalized, pdMagInDPDOrg, iNumActualTrainedData);
		MatlabAbs(pcdInputTrained, pdMagOutDPDOrg, iNumActualTrainedData);
		
		// This is for the line inside the unwrap function
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			cdA.r = pcdOutputTrainedNormalized[iIndex].r;
			cdA.i = -1.0 * pcdOutputTrainedNormalized[iIndex].i;

			cdB.r = pcdInputTrained[iIndex].r;
			cdB.i = pcdInputTrained[iIndex].i;
			
			ComplexMultiply(&cdA, &cdB, &cdC);

			pdPhaseDPDOrgPreUnwrap[iIndex] = atan2(cdC.i, cdC.r);
		}
		MatlabUnwrap(pdPhaseDPDOrgPreUnwrap, pdPhaseDPDOrg, iNumActualTrainedData);
		VectorDivide(pdMagOutDPDOrg, pdMagInDPDOrg, iNumActualTrainedData, pdGainDPDOrg);

		iPowerDLength = (int) pow(2.0, iDataBits);
		pdMagInDPDPowerD = new double[iPowerDLength];
		pdGainDPDPowerD = new double[iPowerDLength];
		pdPhaseDPDPowerD = new double[iPowerDLength];
		// do not use 'newFunc'
		ModelBaseClass::TimeToPowerDomain(pdMagInDPDOrg, pdGainDPDOrg, pdPhaseDPDOrg, iNumActualTrainedData, iDataBits, dPinCutTh, pdMagInDPDPowerD, pdGainDPDPowerD, pdPhaseDPDPowerD, &iPowerDLength);

		// Find the Phase Offset
		dMaginPhaseTh = 10.0;
		dV_phaseth_dB = 10 * log10(pow(MatlabMax(pdMagInDPDPowerD, iPowerDLength), 2.0) / 50) + 30 - dMaginPhaseTh;
		dV_phaseth = sqrt(pow(10, 0.1 * (dV_phaseth_dB - 30) + 2));
		
		// \bug In MATLAB, this shouldn't go all the way to 1.
		dDPDPhaseOffsetPowerD = 0;
		for(iIndex = (iPowerDLength - 1); iIndex >= 20; iIndex--)
		{
			if(pdMagInDPDPowerD[iIndex] <= dV_phaseth)
			{
				// in MATLAB, takes the current and last 20 elements.
				dDPDPhaseOffsetPowerD = MatlabMean(&pdPhaseDPDPowerD[iIndex - 20], 21);
				break;
			}
		}

		// Shift the phase
		for(iIndex = 0; iIndex < iPowerDLength; iIndex++)
		{
			pdPhaseDPDPowerD[iIndex] = pdPhaseDPDPowerD[iIndex] - dDPDPhaseOffsetPowerD;
		}

		// Convert to dB Values
		pdMagInDPDPowerDdB = new double[iPowerDLength];
		pdGainDPDPowerDdB = new double[iPowerDLength];
		pdPhaseDPDPowerDdeg = new double[iPowerDLength];

		for(iIndex = 0; iIndex < iPowerDLength; iIndex++)
		{
			pdMagInDPDPowerDdB[iIndex] = 10 * log10((0.5 * pow(pdMagInDPDPowerD[iIndex], 2.0) )/ 50) + 30;
			pdGainDPDPowerDdB[iIndex] = 20 * log10(pdGainDPDPowerD[iIndex]);
			pdPhaseDPDPowerDdeg[iIndex] = pdPhaseDPDPowerD[iIndex] * 180 / M_PI;
		}

		/// \note W3 gets overwritten in ~10 lines due to same call
		pcdW3 = new doublecomplex[m_iOrder + 1];
		DeembedNonlinearityLSE(iM, m_iOrder, pcdOutputTrained, pcdInputTrained, iNumActualTrainedData, m_dLUTTruncate, &sPAInverseLUT, &dPhaseOffsetPAInverse, pcdW3);

		// Extract the post-distortion LUT
		pcdInputTrainedWithGain = new doublecomplex[iNumActualTrainedData];
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			//pcdInputTrainedWithGain[iIndex].r = pcdInputTrained[iIndex].r * dGainLinear;
			//pcdInputTrainedWithGain[iIndex].i = pcdInputTrained[iIndex].i * dGainLinear;
			pcdInputTrainedWithGain[iIndex].r = pcdInputTrained[iIndex].r * 1.0;
			pcdInputTrainedWithGain[iIndex].i = pcdInputTrained[iIndex].i * 1.0;
		}

		//DeembedNonlinearityDEWMA(iMovingAverageExecution, pcdOutputTrained, pcdInputTrainedWithGain, iNumActualTrainedData, m_iLUTSize, m_dLUTTruncate, &sPostDPDLUT, &dPhaseOffsetPostDPD);
		//DeembedNonlinearityLSE(iM, m_iOrder, pcdOutputTrained, pcdInputTrainedWithGain, iNumActualTrainedData, m_dLUTTruncate, &sPostDPDLUT, &dPhaseOffsetPostDPD, pcdW3);
		dPhaseOffsetPostDPD = -dPhaseOffset;
		GenerateDPD(sPALUT, sPostDPDLUT, m_dLUTTruncate + m_dOutputAttenuation, 0.0, 0.0, m_iLUTSize);

		// save the post distortion LUT to a file, actually maybe convert to archive if needed
		// Mar 27/08
		// commented out file generation
		// SaveLUTwithPhaseOffset(m_csFilepath + _T("postDPD_LUT.txt"), sPostDPDLUT.m_pdMagIn, sPostDPDLUT.m_pdGain, sPostDPDLUT.m_pdPhase, sPostDPDLUT.m_iLength, dPhaseOffsetPostDPD);

		// Save Phase Offsets
		SavePhaseOffset(dGainLinear, dPhaseOffset, dPhaseOffsetDPD, dPhaseOffsetPostDPD);

		// Convert the polar to rectangular
		pdIPALUT = new double[sPALUT.m_iLength];
		pdQPALUT = new double[sPALUT.m_iLength];
		pdIDPDLUT = new double[sDPDLUT.m_iLength];
		pdQDPDLUT = new double[sDPDLUT.m_iLength];
		pdIPostDPDLUT = new double[sPostDPDLUT.m_iLength];
		pdQPostDPDLUT = new double[sPostDPDLUT.m_iLength];

		// Knowing that all lengths are the same...
		for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
		{
			pdIPALUT[iIndex] = sPALUT.m_pdGain[iIndex] * cos(sPALUT.m_pdPhase[iIndex]);
			pdQPALUT[iIndex] = sPALUT.m_pdGain[iIndex] * sin(sPALUT.m_pdPhase[iIndex]);
			pdIDPDLUT[iIndex] = sDPDLUT.m_pdGain[iIndex] * cos(sDPDLUT.m_pdPhase[iIndex]);
			pdQDPDLUT[iIndex] = sDPDLUT.m_pdGain[iIndex] * sin(sDPDLUT.m_pdPhase[iIndex]);
			pdIPostDPDLUT[iIndex] = sPostDPDLUT.m_pdGain[iIndex] * cos(sPostDPDLUT.m_pdPhase[iIndex]);
			pdQPostDPDLUT[iIndex] = sPostDPDLUT.m_pdGain[iIndex] * sin(sPostDPDLUT.m_pdPhase[iIndex]);
		}

		// Compute some normalization parameters, and save to a file
		// Calculate DPD LUT index normalization parameters
		dMaxMagInDPDOrg = MatlabMax(pdMagInDPDOrg, iNumActualTrainedData);
		dMaxMagInDPDLUT = MatlabMax(sDPDLUT.m_pdMagIn, sDPDLUT.m_iLength);
		dMaxDPDMagDiff = dMaxMagInDPDOrg - dMaxMagInDPDLUT;
		dMinMagInDPDLUT = 0;
		dLowerBound = 0;
		dUpperBoundDPD = 1;
		dAmpDPD = (dUpperBoundDPD - dLowerBound) / (dMaxMagInDPDLUT - dMinMagInDPDLUT);
		dOffsetDPD = dUpperBoundDPD - dAmpDPD * dMaxMagInDPDLUT;
		
		// Calculate PA LUT index normalization parameters
		dMaxMagInPALUT = MatlabMax(sPALUT.m_pdMagIn, sPALUT.m_iLength);
		dMinMagInPALUT = 0;
		dLowerBound = 0;
		dUpperBoundPA = 1;
		dAmpPA = (dUpperBoundPA - dLowerBound) / (dMaxMagInPALUT - dMinMagInPALUT);
		dOffsetPA = dUpperBoundPA - dAmpPA * dMaxMagInPALUT;

		SaveNormalizationParameters(dAmpPA, dOffsetPA, dMaxMagInPALUT, dUpperBoundPA,
									dAmpDPD, dOffsetDPD, dMaxMagInDPDLUT, dUpperBoundDPD);


		// Save PA LUT
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
		SaveLUT(csFilename, &sPALUT);

		// Save DPD LUT
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		SaveLUT(csFilename, &sDPDLUT);
		
		csFilename.Format(_T("%s%s_%s_DPD_MaginIQ_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		sTempContainer.m_pdMagIn = sDPDLUT.m_pdMagIn;
		sTempContainer.m_pdGain = pdIDPDLUT;
		sTempContainer.m_pdPhase = pdQDPDLUT;
		sTempContainer.m_iLength = sDPDLUT.m_iLength;
		// Mar 27/08
		// commented out file generation
		// SaveLUT(csFilename, &sTempContainer);

		// Save Post DPD LUT
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_POST_COMPENSATION_NAME);
		SaveLUT(csFilename, &sPostDPDLUT);
		
		csFilename.Format(_T("%s%s_%s_postDPD_MaginIQ_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		sTempContainer.m_pdMagIn = sPostDPDLUT.m_pdMagIn;
		sTempContainer.m_pdGain = pdIPostDPDLUT;
		sTempContainer.m_pdPhase = pdQPostDPDLUT;
		sTempContainer.m_iLength = sPostDPDLUT.m_iLength;
		// Mar 27/08
		// commented out file generation
		// SaveLUT(csFilename, &sTempContainer);

		// Save Neural Network Data
		SaveNNFiles(&sPALUT, &sDPDLUT);

		// Save baseband data
		// Mar 27/08
		// commented out file generation
		//csFilename.Format(_T("%s%s_%s_DPD_IQ_LUT_nonlinearity_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		//SaveBasebandADSFile(csFilename, pdIDPDLUT, pdQDPDLUT, sDPDLUT.m_iLength);
		//csFilename.Format(_T("%s%s_%s_PA_IQ_LUT_nonlinearity_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		//SaveBasebandADSFile(csFilename, pdIPALUT, pdQPALUT, sPALUT.m_iLength);

		// Convert to dB Values
		pdMagInLUTdB = new double[sPALUT.m_iLength];
		pdMagInDPDLUTdB = new double[sDPDLUT.m_iLength];
		pdMagInPostDPDLUTdB = new double[sPostDPDLUT.m_iLength];
		pdGainLUTdB = new double[sPALUT.m_iLength];
		pdGainDPDLUTdB = new double[sDPDLUT.m_iLength];
		pdGainPostDPDLUTdB = new double[sPostDPDLUT.m_iLength];
		pdGainLUTNormalizeddB = new double[sPALUT.m_iLength];
		pdPhaseLUTNorm =  new double[sPALUT.m_iLength];
		pdPhaseDPDLUTNorm = new double[sDPDLUT.m_iLength];
		pdPhasePostDPDLUTNorm = new double[sPostDPDLUT.m_iLength];

		/// \bug definately a bug, line 431 in SingleTapPolyLUTNewfunc.m, gain_post_dpd_lut_dB derived from gain_dpd_lut
		// Know that they are all the same length
		for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
		{
			pdMagInLUTdB[iIndex] = 10 * log10((0.5 * pow(sPALUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdMagInDPDLUTdB[iIndex] = 10 * log10((0.5 * pow(sDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdMagInPostDPDLUTdB[iIndex] = 10 * log10((0.5 * pow(sPostDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdGainLUTdB[iIndex] = 20 * log10(sPALUT.m_pdGain[iIndex]);
			pdGainDPDLUTdB[iIndex] = 20 * log10(sDPDLUT.m_pdGain[iIndex]);
			pdGainPostDPDLUTdB[iIndex] = 20 * log10(sPostDPDLUT.m_pdGain[iIndex]);
			pdGainLUTNormalizeddB[iIndex] = 20 * log10(pdGainLUTNormalized[iIndex]);
			pdPhaseLUTNorm[iIndex] = sPALUT.m_pdPhase[iIndex];
			pdPhaseDPDLUTNorm[iIndex] = sDPDLUT.m_pdPhase[iIndex];
			pdPhasePostDPDLUTNorm[iIndex] = sPostDPDLUT.m_pdPhase[iIndex];
		}

		// Discard all data corresponding < -70 dBm
		dMagInCutTh = -70;
		iCutIndex = 0;
		
		for(iIndex = 0; iIndex < sPALUT.m_iLength; iIndex++)
		{
			if(pdMagInLUTdB[iIndex] >= dMagInCutTh)
			{
				iCutIndex = iIndex;
				break;
			}
		}

		iADSLUTSize = sPALUT.m_iLength - iCutIndex;

		// Shift without creating new data structures
		// all gain_*_dB1 MATLAB variables are not used later.

		// Mar 27/08
		// Do not normalize
		dDPDGainOffset = 0;//pdGainDPDLUTdB[iCutIndex];
		dDPDPhaseOffset = 0;//pdPhaseDPDLUTNorm[iCutIndex];
		dPostDPDGainOffset = 0;//pdGainPostDPDLUTdB[iCutIndex];
		dPostDPDPhaseOffset = 0;//pdPhasePostDPDLUTNorm[iCutIndex];
		dPAGainOffset = 0;//pdGainLUTdB[iCutIndex];
		dPAPhaseOffset = 0;//pdPhaseLUTNorm[iCutIndex];

		for(iIndex = 0; iIndex < iADSLUTSize; iIndex++)
		{
			// DPD Part
			pdGainDPDLUTdB[iIndex] = pdGainDPDLUTdB[iIndex + iCutIndex] - dDPDGainOffset;
			pdPhaseDPDLUTNorm[iIndex] = pdPhaseDPDLUTNorm[iIndex + iCutIndex] - dDPDPhaseOffset;
			pdMagInDPDLUTdB[iIndex] = pdMagInDPDLUTdB[iIndex + iCutIndex];

			// Post DPD Part
			pdGainPostDPDLUTdB[iIndex] = pdGainPostDPDLUTdB[iIndex + iCutIndex] - dPostDPDGainOffset;
			pdPhasePostDPDLUTNorm[iIndex] = pdPhasePostDPDLUTNorm[iIndex + iCutIndex] - dPostDPDPhaseOffset;
			pdMagInPostDPDLUTdB[iIndex] = pdMagInPostDPDLUTdB[iIndex + iCutIndex];

			// PA Part
			pdGainLUTdB[iIndex] = pdGainLUTdB[iIndex + iCutIndex] - dPAGainOffset;
			pdPhaseLUTNorm[iIndex] = pdPhaseLUTNorm[iIndex + iCutIndex] - dPAPhaseOffset;
			pdMagInLUTdB[iIndex] = pdMagInLUTdB[iIndex + iCutIndex];
		}

		// Save gain start point to a mdf file
		csFilename.Format(_T("%s%s_%s_LUT_GainOffset.mdf"), m_csFilepath, m_csSystemType, m_csSignalType);
		SaveMDFGainStartingPoint(csFilename, dDPDGainOffset, dPAGainOffset, dPostDPDGainOffset);

		// Save LUTs in ADS format
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
		SaveLUTADS(csFilename, pdMagInLUTdB, pdGainLUTdB, pdPhaseLUTNorm, iADSLUTSize);

		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		SaveLUTADS(csFilename, pdMagInDPDLUTdB, pdGainDPDLUTdB, pdPhaseDPDLUTNorm, iADSLUTSize);

		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_POST_COMPENSATION_NAME);
		SaveLUTADS(csFilename, pdMagInPostDPDLUTdB, pdGainPostDPDLUTdB, pdPhasePostDPDLUTNorm, iADSLUTSize);


		if(!m_bSmallSignalGain)
		{
			// Plot AM-AM and AM-PM
			/// \bug, xTemp and yTemp should be max(iNumActualTrainedData)
			//pdXTemp = new double[iNumActualTrainedData];
			//pdYTemp = new double[iNumActualTrainedData];
/*			pdXTemp = (iNumActualTrainedData > sPALUT.m_iLength) ? new double[iNumActualTrainedData] : new double[sPALUT.m_iLength];
			pdYTemp = (iNumActualTrainedData > sPALUT.m_iLength) ? new double[iNumActualTrainedData] : new double[sPALUT.m_iLength];

			CREATE_NTDIALOG_MODELESS(pAMAM);
			pAMAM->AddData(pdMagInDPDPowerDdB, pdGainDPDPowerDdB, iPowerDLength, _T("Measurement"));
			pAMAM->SetDataProperties(0, 'b', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
			for(iIndex = 0; iIndex < iADSLUTSize; iIndex++)
			{
				pdYTemp[iIndex] = (pdGainDPDLUTdB[iIndex] + dDPDGainOffset);
			}
			pAMAM->AddData(pdMagInDPDLUTdB, pdYTemp, iADSLUTSize, _T("DPD LUT"));
			pAMAM->SetDataProperties(1, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
			pAMAM->SetTitle(_T("AM-AM"));
			pAMAM->SetYLabel(_T("Gain (dB)"));
			pAMAM->SetXLabel(_T("Pin (dBm)"));
			pAMAM->MyAutoFixAxis();
			pAMAM->ShowLegend(0);


			CREATE_NTDIALOG_MODELESS(pAMPM);
			pAMPM->AddData(pdMagInDPDPowerDdB, pdPhaseDPDPowerDdeg, iPowerDLength, _T("Measurement"));
			pAMPM->SetDataProperties(0, 'b', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
			for(iIndex = 0; iIndex < iADSLUTSize; iIndex++)
			{
				pdYTemp[iIndex] = (pdPhaseDPDLUTNorm[iIndex] + dDPDPhaseOffset) * 180 / M_PI;
			}
			pAMPM->AddData(pdMagInDPDLUTdB, pdYTemp, iADSLUTSize, _T("DPD LUT"));
			pAMPM->SetDataProperties(1, 'r', 2, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);
			pAMPM->SetTitle(_T("AM-PM"));
			pAMPM->SetYLabel(_T("Phi (degree)"));
			pAMPM->SetXLabel(_T("Pin (dBm)"));
			pAMPM->MyAutoFixAxis();
			pAMPM->ShowLegend(0);


			CREATE_NTDIALOG_MODELESS(pAMAMPost);
			// Mar 27/08
			// Adjusted Input Power to reflect change
			for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
			{
				pdXTemp[iIndex] = 10 * log10((0.5 * pow(MatlabAbs(pcdOutputTrained[iIndex]), 2.0)) / 50) + 30;
				pdYTemp[iIndex] = 20 * log10(MatlabAbs(pcdInputTrainedWithGain[iIndex]) / MatlabAbs(pcdOutputTrained[iIndex]));
			}
			pAMAMPost->AddData(pdXTemp, pdYTemp, iNumActualTrainedData, _T("Measurement Data"));
			pAMAMPost->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

			for(iIndex = 0; iIndex < sPostDPDLUT.m_iLength; iIndex++)
			{
				// Abs does nothing here
				pdXTemp[iIndex] = 10 * log10((0.5 * pow(sPostDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
				pdYTemp[iIndex] = 20 * log10(sPostDPDLUT.m_pdGain[iIndex]);
			}
			pAMAMPost->AddData(pdXTemp, pdYTemp, sPostDPDLUT.m_iLength, _T("LUT"));
			pAMAMPost->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);
			pAMAMPost->SetTitle(_T("AM-AM Post"));
			pAMAMPost->SetYLabel(_T("Gain (dB)"));
			pAMAMPost->SetXLabel(_T("Pin (dBm)"));
			pAMAMPost->MyAutoFixAxis();
			pAMAMPost->ShowLegend(0);
			*/
			PlotMemoryless(pcdInputTrained, pcdOutputTrained, iNumActualTrainedData, sPALUT, sDPDLUT, sPostDPDLUT, dGainLinear, dPhaseOffset, dPhaseOffsetDPD, dPhaseOffsetPostDPD);

		}

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_MAGGAINPHASE(sPALUT);
		SAFE_DELETE_MAGGAINPHASE(sDPDLUT);
		SAFE_DELETE_MAGGAINPHASE(sPostDPDLUT);
		SAFE_DELETE_ARRAY(pcdInputTrun);
		SAFE_DELETE_ARRAY(pcdOutputTrun);
		SAFE_DELETE_ARRAY(pcdInputTrained);
		SAFE_DELETE_ARRAY(pcdOutputTrained);
		SAFE_DELETE_ARRAY(pdGainLUTNormalized);
		SAFE_DELETE_ARRAY(pcdOutputTrainedNormalized);
		SAFE_DELETE_ARRAY(pdMagInDPDOrg);
		SAFE_DELETE_ARRAY(pdMagOutDPDOrg);
		SAFE_DELETE_ARRAY(pdGainDPDOrg);
		SAFE_DELETE_ARRAY(pdPhaseDPDOrg);
		SAFE_DELETE_ARRAY(pdPhaseDPDOrgPreUnwrap);
		SAFE_DELETE_ARRAY(pcdInputTrainedWithGain);
		SAFE_DELETE_ARRAY(pdIPALUT);
		SAFE_DELETE_ARRAY(pdQPALUT);
		SAFE_DELETE_ARRAY(pdIDPDLUT);
		SAFE_DELETE_ARRAY(pdQDPDLUT);
		SAFE_DELETE_ARRAY(pdIPostDPDLUT);
		SAFE_DELETE_ARRAY(pdQPostDPDLUT);
		SAFE_DELETE_ARRAY(pdMagInLUTdB);
		SAFE_DELETE_ARRAY(pdMagInDPDLUTdB);
		SAFE_DELETE_ARRAY(pdMagInPostDPDLUTdB);
		SAFE_DELETE_ARRAY(pdGainLUTdB);
		SAFE_DELETE_ARRAY(pdGainDPDLUTdB);
		SAFE_DELETE_ARRAY(pdGainPostDPDLUTdB);
		SAFE_DELETE_ARRAY(pdGainLUTNormalizeddB);
		SAFE_DELETE_ARRAY(pdPhaseLUTNorm);
		SAFE_DELETE_ARRAY(pdPhaseDPDLUTNorm);
		SAFE_DELETE_ARRAY(pdPhasePostDPDLUTNorm);
		SAFE_DELETE_ARRAY(pcdW1);
		SAFE_DELETE_ARRAY(pcdW2);
		SAFE_DELETE_ARRAY(pcdW3);
		SAFE_DELETE_ARRAY(pdMagInDPDPowerD);
		SAFE_DELETE_ARRAY(pdGainDPDPowerD);
		SAFE_DELETE_ARRAY(pdPhaseDPDPowerD);
		SAFE_DELETE_ARRAY(pdMagInDPDPowerDdB);
		SAFE_DELETE_ARRAY(pdGainDPDPowerDdB);
		SAFE_DELETE_ARRAY(pdPhaseDPDPowerDdeg);
		SAFE_DELETE_MAGGAINPHASE(sPAInverseLUT);
		SAFE_DELETE_ARRAY(pdXTemp);
		SAFE_DELETE_ARRAY(pdYTemp);

		throw;
	}

	// Epilogue
	SAFE_DELETE_MAGGAINPHASE(sPALUT);
	SAFE_DELETE_MAGGAINPHASE(sDPDLUT);
	SAFE_DELETE_MAGGAINPHASE(sPostDPDLUT);
	SAFE_DELETE_ARRAY(pcdInputTrun);
	SAFE_DELETE_ARRAY(pcdOutputTrun);
	SAFE_DELETE_ARRAY(pcdInputTrained);
	SAFE_DELETE_ARRAY(pcdOutputTrained);
	SAFE_DELETE_ARRAY(pdGainLUTNormalized);
	SAFE_DELETE_ARRAY(pcdOutputTrainedNormalized);
	SAFE_DELETE_ARRAY(pdMagInDPDOrg);
	SAFE_DELETE_ARRAY(pdMagOutDPDOrg);
	SAFE_DELETE_ARRAY(pdGainDPDOrg);
	SAFE_DELETE_ARRAY(pdPhaseDPDOrg);
	SAFE_DELETE_ARRAY(pdPhaseDPDOrgPreUnwrap);
	SAFE_DELETE_ARRAY(pcdInputTrainedWithGain);
	SAFE_DELETE_ARRAY(pdIPALUT);
	SAFE_DELETE_ARRAY(pdQPALUT);
	SAFE_DELETE_ARRAY(pdIDPDLUT);
	SAFE_DELETE_ARRAY(pdQDPDLUT);
	SAFE_DELETE_ARRAY(pdIPostDPDLUT);
	SAFE_DELETE_ARRAY(pdQPostDPDLUT);
	SAFE_DELETE_ARRAY(pdMagInLUTdB);
	SAFE_DELETE_ARRAY(pdMagInDPDLUTdB);
	SAFE_DELETE_ARRAY(pdMagInPostDPDLUTdB);
	SAFE_DELETE_ARRAY(pdGainLUTdB);
	SAFE_DELETE_ARRAY(pdGainDPDLUTdB);
	SAFE_DELETE_ARRAY(pdGainPostDPDLUTdB);
	SAFE_DELETE_ARRAY(pdGainLUTNormalizeddB);
	SAFE_DELETE_ARRAY(pdPhaseLUTNorm);
	SAFE_DELETE_ARRAY(pdPhaseDPDLUTNorm);
	SAFE_DELETE_ARRAY(pdPhasePostDPDLUTNorm);
	SAFE_DELETE_ARRAY(pcdW1);
	SAFE_DELETE_ARRAY(pcdW2);
	SAFE_DELETE_ARRAY(pcdW3);
	SAFE_DELETE_ARRAY(pdMagInDPDPowerD);
	SAFE_DELETE_ARRAY(pdGainDPDPowerD);
	SAFE_DELETE_ARRAY(pdPhaseDPDPowerD);
	SAFE_DELETE_ARRAY(pdMagInDPDPowerDdB);
	SAFE_DELETE_ARRAY(pdGainDPDPowerDdB);
	SAFE_DELETE_ARRAY(pdPhaseDPDPowerDdeg);
	SAFE_DELETE_MAGGAINPHASE(sPAInverseLUT);
	SAFE_DELETE_ARRAY(pdXTemp);
	SAFE_DELETE_ARRAY(pdYTemp);


	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Try to extract iNumTrainingData number of elements from the input/output vectors,
/// while having the maximum value in the middle of the vector.
///
/// \param pcdInput the input data
/// \param pcdOutput the output data
/// \param iLength length of input/output data
/// \param iNumTrainingData proposed number of training data elements
/// \param [out] pcdInputTrained input data trained
/// \param [out] pcdOutputTrained output data trained
/// \param iComputeLength if != 0, returns the number of elements to allocate for Lagrange
///
/// \return the length
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/extractModeltrainData.m"> extractModeltrainData.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
int ModelFilterBaseClass::ExtractModelTrainingData(doublecomplex* pcdInput,doublecomplex* pcdOutput, int iLength, int iNumTrainingData, doublecomplex* pcdInputTrained, doublecomplex* pcdOutputTrained, int iComputeLength)
{
	double* pdMagIn = NULL;
	double dMagInMin;
	double dMagInMax;
	int iMagInMaxIndex;
	int iNumHalfTrainingData;
	int iIndex;
	int iTrainingIndex;
	int iBeginIndex;
	int iEndIndex;

	if(iComputeLength != 0)
	{
		return ((iLength < iNumTrainingData) ? iLength : iNumTrainingData);
	}


	try
	{
		// do some transposes in Matlab

		// Calculate Magnitude of input data
		pdMagIn = new double[iLength];
		MatlabAbs(pcdInput, pdMagIn, iLength);
		dMagInMin = MatlabMin(pdMagIn, iLength);
		dMagInMax = MatlabMax(pdMagIn, iLength, &iMagInMaxIndex);

		/// \note this function is an error if iNumTrainingData is not divisible by 2.
		iNumHalfTrainingData = floor(double(iNumTrainingData) / 2.0);
		
		// Always want the maximum data point, ensure it is at half
		// if the maximum is over half the training data
		if(iMagInMaxIndex >= iNumHalfTrainingData)
		{
			// if the maximum is nowhere close to the end, take up to iTrainingData
			if(iMagInMaxIndex + iNumHalfTrainingData <= iLength)
			{
				// offset by 1 here.
				iBeginIndex = iMagInMaxIndex - iNumHalfTrainingData + 1;
				iEndIndex = iMagInMaxIndex + iNumHalfTrainingData + 1;
			}
			// else, grab the values at the end
			else
			{
				// no need for +1 offset here.
				iBeginIndex = iLength - iNumTrainingData;
				iEndIndex = iLength;
			}
		}
		// Else it is near the beginning
		else
		{
			if(iMagInMaxIndex + iNumHalfTrainingData <= iLength)
			{
				iBeginIndex = 0;
				iEndIndex = iNumTrainingData;
			}
			// Condition where expected training data is greater than length
			else
			{
				iBeginIndex = 0;
				iEndIndex = iLength;
			}
		}

		iTrainingIndex = 0;
		for(iIndex = iBeginIndex; iIndex < iEndIndex; iIndex++)
		{
			pcdInputTrained[iTrainingIndex].r = pcdInput[iIndex].r;
			pcdInputTrained[iTrainingIndex].i = pcdInput[iIndex].i;
			pcdOutputTrained[iTrainingIndex].r = pcdOutput[iIndex].r;
			pcdOutputTrained[iTrainingIndex].i = pcdOutput[iIndex].i;
			iTrainingIndex++;
		}

		// Added January 28, 2008
		// if minimum does not meet truncation paramter, exit.
		// Added January 29, 2008
		// Sends a window message to update the LUT truncate value
		double dMinLog = 10 * log10((0.5 * pow(dMagInMin, 2.0)) /50) + 30;
		if(dMinLog > m_dLUTTruncate)
		{
			EXCEPTION_ADDUSERMESSAGE(_T("Error: LUT Truncate value less than minimum of input values"));

			AfxGetMainWnd()->SendMessageToDescendants(WM_LUT_TRUNCATE_ERROR, (WPARAM) &dMinLog, 0);
			AfxThrowUserException();
		}

		// Done
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pdMagIn);
		throw;
	}
	

	// Epilogue
	SAFE_DELETE_ARRAY(pdMagIn);

	return ((iLength < iNumTrainingData) ? iLength : iNumTrainingData);;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the EWMA function
///
/// \param iMATimes number of times to execute
/// \param pcdXTrained input trained data
/// \param pcdYTrained output trained data
/// \param iTrainedLength length of input arrays
/// \param iLUTSize the lut size
/// \param dPinThreshdB minimum pin threshold
/// \param [out] psOutputLUT generated output LUT
/// \param [out] pdPhaseOffset generated phase offset
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/DeEmbedingNonlinearitynewDEWMAfunc.m"> DeEmbedingNonlinearitynewDEWMAfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::DeembedNonlinearityDEWMA(int iMATimes, doublecomplex* pcdXTrained, doublecomplex* pcdYTrained, int iTrainedLength, int iLUTSize, double dPinThreshdB, MAGGAINPHASE* psOutputLUT, double* pdPhaseOffset)
{
	double dMagCutTh;
	double dMagInMax;
	double dMagInMin;
	double dInterval;
	double* pdMagIn = NULL;
	double* pdGain = NULL;
	double* pdPhase = NULL;
	doublecomplex* pcdOutputOverInput = NULL;
	double* pdMagInPd = NULL;
	double* pdGainPd = NULL;
	double* pdPhasePd = NULL;
	int iPdLength;
	int iIndex;
	int iMaxPoints;
	double dMagInPhaseTh;
	double dMagInPdMax;
	double dVPhaseThdB;
	double dVPhaseTh;
	double* pdPhaseUnwrap = NULL;
	double* pdPhasePdUnwrap = NULL;
	double* pdGainMa = NULL;
	double* pdPhaseMa = NULL;
	PlotUtility cPlot;

	try
	{
		// Convert Threshold to magnitude scale
		dMagCutTh = sqrt(2 * 50 * pow(10.0, (dPinThreshdB - 30) / 10.0));

		// Compute Maximum Points
		pdMagIn = new double[iTrainedLength];
		MatlabAbs(pcdXTrained, pdMagIn, iTrainedLength);
		dMagInMin = MatlabMin(pdMagIn, iTrainedLength);
		dMagInMax = MatlabMax(pdMagIn, iTrainedLength);

		if(iTrainedLength > 2501 && iLUTSize < 2501)
		{
			iMaxPoints = 2501;
		}
		else if(iLUTSize > 2501 && iTrainedLength > iLUTSize)
		{
			iMaxPoints = iLUTSize;
		}
		else
		{
			iMaxPoints = iTrainedLength;
		}

		dInterval = (dMagInMax - dMagInMin) / (iMaxPoints - 1);

		// Calculate gain and phase of the training data
		pcdOutputOverInput = new doublecomplex[iTrainedLength];
		pdGain = new double[iTrainedLength];
		pdPhase = new double[iTrainedLength];
		for(iIndex = 0; iIndex < iTrainedLength; iIndex++)
		{
			ComplexDivide(&pcdYTrained[iIndex], &pcdXTrained[iIndex], &pcdOutputOverInput[iIndex]);
		}

		MatlabAbs(pcdOutputOverInput, pdGain, iTrainedLength);
		MatlabPhase(pcdOutputOverInput, pdPhase, iTrainedLength);

		// Change the gain and phase to power domain
		// Know that TimeToPowerDomain will not generate more points than its input
		pdMagInPd = new double[iTrainedLength];
		pdGainPd = new double[iTrainedLength];
		pdPhasePd = new double[iTrainedLength];
		TimeToPowerDomain(pdMagIn, pdGain, pdPhase, iTrainedLength, dInterval, pdMagInPd, pdGainPd, pdPhasePd, &iPdLength);


		// Find the phase offset
		dMagInPhaseTh = 10;
		// V_phaseth_dB=(10*log10(max(mag_in_pd)^2/100)+30)-Magin_phase_th;
		dVPhaseThdB = (10 * log10( pow(MatlabMax(pdMagInPd, iPdLength), 2.0) / 100) + 30) - dMagInPhaseTh;
		// V_phaseth=sqrt(10^(0.1*(V_phaseth_dB-30)+2));
		dVPhaseTh = sqrt(pow(10, 0.1 * (dVPhaseThdB - 30) + 2));

		// \bug In MATLAB, this shouldn't go all the way to 1.
		*pdPhaseOffset = 0;
		for(iIndex = iPdLength - 1; iIndex >= 20; iIndex--)
		{
			if(pdMagInPd[iIndex] <= dVPhaseTh)
			{
				*pdPhaseOffset = MatlabMean(&pdPhasePd[iIndex - 20], 21);
				break;
			}
		}

		// Shift the phase (of both phase and phasepd), and unwrap
		for(iIndex = 0; iIndex < iTrainedLength; iIndex++)
		{
			pdPhase[iIndex] = pdPhase[iIndex] - *pdPhaseOffset;
		}
		for(iIndex = 0; iIndex < iPdLength; iIndex++)
		{
			pdPhasePd[iIndex] = pdPhasePd[iIndex] - *pdPhaseOffset;
		}
		pdPhaseUnwrap = new double[iTrainedLength];
		pdPhasePdUnwrap = new double[iPdLength];
		MatlabUnwrap(pdPhase, pdPhaseUnwrap, iTrainedLength);
		MatlabUnwrap(pdPhasePd, pdPhasePdUnwrap, iPdLength);

		// Apply the new dynamic exponential weighted moving average to gain and phase
		pdGainMa = new double[iPdLength];
		pdPhaseMa = new double[iPdLength];

		for(iIndex = 0; iIndex < iPdLength; iIndex++)
		{
			pdGainMa[iIndex] = pdGainPd[iIndex];
			pdPhaseMa[iIndex] = pdPhasePdUnwrap[iIndex];
		}

		// Pin_pd variable not used
		for(iIndex = 0; iIndex < iMATimes; iIndex++)
		{
			DEWMA(pdMagInPd, pdGainMa, iPdLength, pdGainMa);
			DEWMA(pdMagInPd, pdPhaseMa, iPdLength, pdPhaseMa);
		}

		// Create LUT
		dInterval = (dMagInMax - dMagCutTh) / (iLUTSize - 1);

		psOutputLUT->m_pdMagIn = new double[iLUTSize];
		psOutputLUT->m_pdGain = new double[iLUTSize];
		psOutputLUT->m_pdPhase = new double[iLUTSize];
		psOutputLUT->m_iLength = iLUTSize;

		// the interpolated X axis
		for(iIndex = 0; iIndex < iLUTSize; iIndex++)
		{
			psOutputLUT->m_pdMagIn[iIndex] = dMagCutTh + (iIndex * dInterval);
		}

		MatlabInterp1(pdMagInPd, pdGainMa, iPdLength, psOutputLUT->m_pdMagIn, iLUTSize, psOutputLUT->m_pdGain);
		MatlabInterp1(pdMagInPd, pdPhaseMa, iPdLength, psOutputLUT->m_pdMagIn, iLUTSize, psOutputLUT->m_pdPhase);

		// Plot Results
		/// \note need to fix this
		MAGGAINPHASE sOrig = {pdMagIn, pdGain, pdPhase, iTrainedLength};
		MAGGAINPHASE sSim = {psOutputLUT->m_pdMagIn, psOutputLUT->m_pdGain, psOutputLUT->m_pdPhase, psOutputLUT->m_iLength};
/*
		if(!m_bSmallSignalGain)
			cPlot.PlotAMAM_AMPMinDB(sOrig, sSim);
*/		// Assign to output variables (already done)
		

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pdMagIn);
		SAFE_DELETE_ARRAY(pdGain);
		SAFE_DELETE_ARRAY(pdPhase);
		SAFE_DELETE_ARRAY(pcdOutputOverInput);
		SAFE_DELETE_ARRAY(pdMagInPd);
		SAFE_DELETE_ARRAY(pdGainPd);
		SAFE_DELETE_ARRAY(pdPhasePd);
		SAFE_DELETE_ARRAY(pdPhaseUnwrap);
		SAFE_DELETE_ARRAY(pdPhasePdUnwrap);
		SAFE_DELETE_ARRAY(pdGainMa);
		SAFE_DELETE_ARRAY(pdPhaseMa);

		throw;
	}

	// Epilogue
	SAFE_DELETE_ARRAY(pdMagIn);
	SAFE_DELETE_ARRAY(pdGain);
	SAFE_DELETE_ARRAY(pdPhase);
	SAFE_DELETE_ARRAY(pcdOutputOverInput);
	SAFE_DELETE_ARRAY(pdMagInPd);
	SAFE_DELETE_ARRAY(pdGainPd);
	SAFE_DELETE_ARRAY(pdPhasePd);
	SAFE_DELETE_ARRAY(pdPhaseUnwrap);
	SAFE_DELETE_ARRAY(pdPhasePdUnwrap);
	SAFE_DELETE_ARRAY(pdGainMa);
	SAFE_DELETE_ARRAY(pdPhaseMa);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Convert the data from time to power domain and sort them by input magnitude.
/// This function is different from the one coded by MemoryPolynomial class
///
/// \param pdMagIn input magnitude vector
/// \param pdGain input gain vector
/// \param pdPhase input phase vector
/// \param iLength length of input vectors
/// \param dInterval proposed downsampled interval
/// \param [out] pdMagInPdDs output (input magnitude vector)
/// \param [out] pdGainPdDs output gain vector
/// \param [out] pdPhasePdDs output phase vector
/// \param [out] piDownsampledLength the length of output vectors
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/Time2PowerDomainDataConvertNewFunc.m"> Time2PowerDomainDataConvertNewFunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::TimeToPowerDomain(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double dInterval, double* pdMagInPdDs, double* pdGainPdDs, double* pdPhasePdDs, int* piDownsampledLength)
{
	double* pdMagInSorted = NULL;
	int* piMagIndices = NULL;
	int iIndex;
	int iIndexI;
	int iStep;
	int iCounter;
	int iRepeatCounter;
	double* pdMagInPd = NULL;
	double* pdGainPd = NULL;
	double* pdPhasePd = NULL;
	double dGainPdSum;
	double dPhasePdSum;

	try
	{
		// Create a new array for sorted variables
		pdMagInSorted = new double[iLength];
		piMagIndices =  new int[iLength];
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pdMagInSorted[iIndex] = pdMagIn[iIndex];
			piMagIndices[iIndex] = iIndex;
		}

		MatlabSort(pdMagInSorted, 0, iLength - 1, piMagIndices);

		pdMagInPd = new double[iLength];
		pdGainPd = new double[iLength];
		pdPhasePd = new double[iLength];

		// Check the repeat data, delete from sorted, average corresponding gain and phase
		iStep = 1;
		iCounter = -1;

		for(iIndex = 0; iIndex < iLength; iIndex = iIndex + iStep)
		{
			if(iIndex > 0)
			{
				if(pdMagInSorted[iIndex] == pdMagInSorted[iCounter])
				{
					// Continue...
				}
			}

			iCounter = iCounter + 1;
			pdMagInPd[iCounter] = pdMagInSorted[iIndex];
			dGainPdSum = pdGain[piMagIndices[iIndex]];
			dPhasePdSum = pdPhase[piMagIndices[iIndex]];

			iRepeatCounter = 0;
			for(iIndexI = 0; iIndexI < iLength - iIndex; iIndexI++)
			{
				if((iIndex + iIndexI) <= iLength)
				{
					if(pdMagInSorted[iIndex] == pdMagInSorted[iIndex + iIndexI])
					{
						iRepeatCounter = iRepeatCounter + 1;
						dGainPdSum = dGainPdSum + pdGain[piMagIndices[iIndex + iIndexI]];
						dPhasePdSum = dPhasePdSum + pdPhase[piMagIndices[iIndex + iIndexI]];
					}

					if(pdMagInSorted[iIndex + iIndexI] > pdMagInSorted[iIndex])
					{
						break;
					}
				}
			}

			pdGainPd[iCounter] = dGainPdSum / (iRepeatCounter + 1);
			pdPhasePd[iCounter] = dPhasePdSum / (iRepeatCounter + 1);
		} // end for loop

		// Needed
		iCounter = iCounter + 1;


		// Now, call downsampling on the interval
		DownsamplingBasedOnInterval(dInterval, pdMagInPd, pdGainPd, pdPhasePd, iCounter, pdMagInPdDs, pdGainPdDs, pdPhasePdDs, piDownsampledLength);

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		
		SAFE_DELETE_ARRAY(pdMagInSorted);
		SAFE_DELETE_ARRAY(piMagIndices);
		SAFE_DELETE_ARRAY(pdMagInPd);
		SAFE_DELETE_ARRAY(pdGainPd);
		SAFE_DELETE_ARRAY(pdPhasePd);

		throw;
	}

	// Epilogue
	SAFE_DELETE_ARRAY(pdMagInSorted);
	SAFE_DELETE_ARRAY(piMagIndices);
	SAFE_DELETE_ARRAY(pdMagInPd);
	SAFE_DELETE_ARRAY(pdGainPd);
	SAFE_DELETE_ARRAY(pdPhasePd);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Downsampling based on the interval specified
///
/// \param dInterval the interval to downsample
/// \param pdMagInPd input magnitude vector
/// \param pdGainPd input gain vector
/// \param pdPhasePd input phase vector
/// \param iLength length of input vectors
/// \param [out] pdMagInPdDs output (input magnitude) vector
/// \param [out] pdGainPdDs output gain vector
/// \param [out] pdPhasePdDs output phase vector
/// \param [out] piDownsampledLength length of output vectors
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/DownSamplingBasedOnIntervalFunc.m"> DownSamplingBasedOnIntervalFunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::DownsamplingBasedOnInterval(double dInterval, double* pdMagInPd, double* pdGainPd, double* pdPhasePd, int iLength, double* pdMagInPdDs, double* pdGainPdDs, double* pdPhasePdDs, int* piDownsampledLength)
{
	int iCounter;
	int iPrePoint;
	int iIndex;

	try
	{
		// Copy First Point
		pdMagInPdDs[0] = pdMagInPd[0];
		pdGainPdDs[0] = pdGainPd[0];
		pdPhasePdDs[0] = pdPhasePd[0];

		iCounter = 1;
		iPrePoint = 0;
		for(iIndex = 1; iIndex < iLength - 1; iIndex++)
		{
			if((pdMagInPd[iIndex] - pdMagInPd[iPrePoint]) > dInterval)
			{
				pdMagInPdDs[iCounter] = pdMagInPd[iIndex];
				pdGainPdDs[iCounter] = pdGainPd[iIndex];
				pdPhasePdDs[iCounter] = pdPhasePd[iIndex];
				iCounter = iCounter + 1;
				iPrePoint = iIndex;
			}
		} // end for

		// Copy Last Point
		pdMagInPdDs[iCounter] = pdMagInPd[iLength - 1];
		pdGainPdDs[iCounter] = pdGainPd[iLength - 1];
		pdPhasePdDs[iCounter] = pdPhasePd[iLength - 1];
		*piDownsampledLength = iCounter + 1;
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs the Dynamic Exponentially Weighted moving Average
///
/// \param pdX input array X
/// \param pdY input array Y
/// \param iLength length of X/Y
/// \param [out] pdOutput output array Y, with DEWMA applied
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/newDEWMAfunc.m"> newDEWMAfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::DEWMA(double* pdX, double* pdY, int iLength, double* pdOutput)
{
	double* pddX = NULL;
	double* pddY = NULL;
	double* pdddX = NULL;
	double* pdddY = NULL;
	double* pdYma = NULL;
	double dAlpha;
	double dYY;
	int iIndex;

	try
	{
		pddX = new double[iLength - 1];
		pddY = new double[iLength - 1];
		pdddX = new double[iLength - 2];
		pdddY = new double[iLength - 2];

		// First calculate the first derivative of Y
		Derive(pdX, pdY, iLength, pddX, pddY);
		
		// Then, calculate the second derivative of Y
		// \bug possible misuse of x, should be using dx.
		Derive(pdX, pddY, (iLength - 1), pdddX, pdddY);

		// Intiialize the moving average of Y to Y
		pdYma = new double[iLength];
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pdYma[iIndex] = pdY[iIndex];
		}

		// Apply MA based on 3 points, current, previous, and after poitns
		for(iIndex = 1; iIndex < (iLength - 1); iIndex++)
		{
			dAlpha = exp(-(dabs(pdddY[iIndex - 1])));
			dYY = pdYma[iIndex - 1] + ((pdX[iIndex] - pdX[iIndex - 1]) / (pdX[iIndex + 1] - pdX[iIndex - 1])) * (pdY[iIndex + 1] - pdYma[iIndex - 1]);
			pdYma[iIndex] = dAlpha * pdY[iIndex] + (1 - dAlpha) * dYY;
		}

		// Process the first point
		pdYma[0] = pdYma[1];

		// Copy back to output
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pdOutput[iIndex] = pdYma[iIndex];
		}

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pddX);
		SAFE_DELETE_ARRAY(pddY);
		SAFE_DELETE_ARRAY(pdddX);
		SAFE_DELETE_ARRAY(pdddY);
		SAFE_DELETE_ARRAY(pdYma);

		throw;
	}

	SAFE_DELETE_ARRAY(pddX);
	SAFE_DELETE_ARRAY(pddY);
	SAFE_DELETE_ARRAY(pdddX);
	SAFE_DELETE_ARRAY(pdddY);
	SAFE_DELETE_ARRAY(pdYma);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Calculates the discrete derivative of the input vectors X and Y
///
/// \param pdX input vector X
/// \param pdY input vector Y
/// \param iLength length of X/Y
/// \param [out] pddX averaged value between two consecutive X's (of length iLength - 1)
/// \param [out] pddY derivative of Y (of length iLength - 1)
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/derive.m"> derive.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::Derive(double* pdX, double* pdY, int iLength, double* pddX, double* pddY)
{
	int iIndex;

	try
	{
		for(iIndex = 0; iIndex < iLength - 1; iIndex++)
		{
			pddY[iIndex] = (pdY[iIndex + 1] - pdY[iIndex]) / (pdX[iIndex + 1] - pdX[iIndex]);
			pddX[iIndex] = (pdX[iIndex + 1] + pdX[iIndex]) / 2;
		}
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		throw;
	}

	return;
}

////////////////////////////////////////////////////////////////////////////////////
///
/// Saves the post dpd LUT to a file (may need to change later)
///
/// \param csFilename input filename
/// \param pdMagIn input magnitude
/// \param pdGain gain
/// \param pdPhase phase
/// \param iLength length of vectors
/// \param dPhaseOffset phase offset
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::SaveLUTwithPhaseOffset(CString csFilename, double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double dPhaseOffset)
{
	CStdioFile cfOutput;
	CString csWriteLine;
	int iIndex;

	try
	{
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		
		csWriteLine.Format(_T("Phase Offset: %f\n"), dPhaseOffset);
		cfOutput.WriteString(csWriteLine);
		
		csWriteLine.Format(_T("Magnitude In\tGain\tPhase\n"));
		cfOutput.WriteString(csWriteLine);
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			csWriteLine.Format(_T("%f\t%f\t%f\n"), pdMagIn[iIndex], pdGain[iIndex], pdPhase[iIndex]);
			cfOutput.WriteString(csWriteLine);
		}

		cfOutput.Close();
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Saves offsets to a file
///
/// \param dGainLinear the linear gain
/// \param dPhaseOffset the phase offset for PA
/// \param dPhaseOffsetDPD the phase offset for DPD
/// \param dPhaseOffsetPostDPD the phase offset for Post DPD
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::SavePhaseOffset(double dGainLinear, double dPhaseOffset, double dPhaseOffsetDPD, double dPhaseOffsetPostDPD)
{
	CStdioFile cfOutput;
	CString csWriteLine;
	CString csFilename;

	try
	{
		csFilename.Format(_T("%s%s_%s_LinearGain.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		
		/// \note move this to somewhere else?
		m_csLinearGainFilename = csFilename;

		csWriteLine.Format(_T("%8.10f  %8.10f  %8.10f  %8.10f\n"), dGainLinear, dPhaseOffset, dPhaseOffsetDPD, dPhaseOffsetPostDPD);
		cfOutput.WriteString(csWriteLine);

		cfOutput.Close();
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Saves normalization parameters to a text file
///
/// \param dAmpPA 
/// \param dOffsetPA 
/// \param dMaxMagInPALUT 
/// \param dUpperBoundPA 
/// \param dAmpDPD 
/// \param dOffsetDPD 
/// \param dMaxMagInDPDLUT 
/// \param dUpperBoundDPD 
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/.m"> .m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::SaveNormalizationParameters(double dAmpPA, double dOffsetPA, double dMaxMagInPALUT, double dUpperBoundPA, double dAmpDPD, double dOffsetDPD, double dMaxMagInDPDLUT, double dUpperBoundDPD)
{
	CStdioFile cfOutput;
	CString csWriteLine;
	CString csFilename;

	try
	{
		csFilename.Format(_T("%s%s_%s_AddressNormalizationParameter.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);

		// PA Parameters
		cfOutput.WriteString(_T("PA LUT model normalization parameters: \n"));
		csWriteLine.Format(_T("Amp_pa= %8.10f \n"), dAmpPA);
		cfOutput.WriteString(csWriteLine);
		csWriteLine.Format(_T("Offset_pa= %8.10f \n"), dOffsetPA);
		cfOutput.WriteString(csWriteLine);
		csWriteLine.Format(_T("Maxmag_pa= %8.10f \n"), dMaxMagInPALUT);
		cfOutput.WriteString(csWriteLine);
		csWriteLine.Format(_T("UpperBound_pa= %8.10f \n\n\n"), dUpperBoundPA);
		cfOutput.WriteString(csWriteLine);

		// DPD Parameters
		cfOutput.WriteString(_T("DPD LUT model normalization parameters: \n"));
		csWriteLine.Format(_T("Amp_dpd= %8.10f \n"), dAmpDPD);
		cfOutput.WriteString(csWriteLine);
		csWriteLine.Format(_T("Offset_dpd= %8.10f \n"), dOffsetDPD);
		cfOutput.WriteString(csWriteLine);
		csWriteLine.Format(_T("Maxmag_dpd= %8.10f \n"), dMaxMagInDPDLUT);
		cfOutput.WriteString(csWriteLine);
		csWriteLine.Format(_T("UpperBound_dpd= %8.10f \n\n\n"), dUpperBoundDPD);
		cfOutput.WriteString(csWriteLine);

		cfOutput.Close();
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// This should be somewhere else.
///
////////////////////////////////////////////////////////////////////////////////////
/*void ModelFilterBaseClass::SetupOutputNames(void)
{
	// Consistent or not throughtout all files?
	CString csPrefix;

	csPrefix = m_csFilepath + m_csSystemType + _T("_") + m_csSignalType + _T("_");
	m_csPostDPDLUTFilename = m_csFilepath + _T("postDPD_LUT.txt");
	m_csAddressNormalizationFilename = csPrefix + _T("AddressNormalizationParameter.txt");
	m_csPALUTGainPhaseFilename = csPrefix + _T("PA_MaginGainPhi_LUT.txt");
	m_csDPDLUTGainPhaseFilename = csPrefix + _T("DPD_MaginGainPhi_LUT.txt");
	m_csDPDLUTIQFilename = csPrefix + _T("DPD_MaginIQ_LUT.txt");
	m_csPostDPDLUTGainPhaseFilename = csPrefix + _T("postDPD_MaginGainPhi_LUT.txt");
	m_csPostDPDLUTIQFilename = csPrefix + _T("postDPD_MaginIQ_LUT.txt");
	m_csDPDADSFilename = csPrefix + _T("DPD_IQ_LUT_nonlinearity_ads.txt");
	m_csPAADSFilename = csPrefix + _T("PA_IQ_LUT_nonlinearity_ads.txt");
	m_csMDFOutputFilename = csPrefix + _T("LUT_GainOffset.mdf");
	m_csPALUTADSFilename = csPrefix + _T("PA_MaginGainPhi_LUT_ads.txt");
	m_csDPDLUTADSFilename = csPrefix + _T("DPD_MaginGainPhi_LUT_ads.txt");
	m_csPostDPDLUTADSFilename = csPrefix + _T("postDPD_MaginGainPhi_LUT_ads.txt");

	m_csLinearGainFilename = csPrefix + _T("PA_LinearGain.txt");

	return;
}
*/

////////////////////////////////////////////////////////////////////////////////////
///
/// Saves a copy of the I/Q vectors to a ads formatted output
///
/// \param csFilename filename to write to
/// \param pdI in-phase vector
/// \param pdQ quadrature-phase vector
/// \param iLength length of vectors
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::SaveBasebandADSFile(CString csFilename, double* pdI, double* pdQ, int iLength)
{
	CStdioFile cfOutput;
	CString csWriteLine;
	int iIndex;

	try
	{
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			csWriteLine.Format(_T("(%8.10f, %8.10f)\n"), pdI[iIndex], pdQ[iIndex]);
			cfOutput.WriteString(csWriteLine);
		}

		cfOutput.Close();
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Saves the gain start poitn value in a .mdf file
///
/// \param csFilename filename to write to
/// \param dDPDGainOffset the dpd gain offset
/// \param dPAGainOffset the pa gain offset
/// \param dPostDPDGainOffset (optional) the postdpd gain
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::SaveMDFGainStartingPoint(CString csFilename, double dDPDGainOffset, double dPAGainOffset, double dPostDPDGainOffset)
{
	CStdioFile cfOutput;
	CString csWriteLine;

	try
	{
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		
		cfOutput.WriteString(_T("BEGIN DSCRDATA\n"));
		if(dPostDPDGainOffset != 0)
		{
			cfOutput.WriteString(_T("%%INDEX     DPDGainOffset      PAGainOffset     postDPDGainOffset\n0"));
			csWriteLine.Format(_T("        %2.14f      %2.14f        %2.14f"), dDPDGainOffset, dPAGainOffset, dPostDPDGainOffset);
			cfOutput.WriteString(csWriteLine);
		}
		else
		{
			cfOutput.WriteString(_T("%%INDEX     DPDGainOffset      PAGainOffset\n0"));
			csWriteLine.Format(_T("        %2.14f      %2.14f"), dDPDGainOffset, dPAGainOffset);
			cfOutput.WriteString(csWriteLine);
		}
		cfOutput.WriteString(_T("\nEND"));

		cfOutput.Close();
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Saves the LUT in ADS GainRF's file format
///
/// \param csFilename filename to write to
/// \param pdMagIn input magnitude vector
/// \param pdGain gain vector
/// \param pdPhase phase vector
/// \param iLength length of vectors
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::SaveLUTADS(CString csFilename, double* pdMagIn, double* pdGain, double* pdPhase, int iLength)
{
	CStdioFile cfOutput;
	CString csWriteLine;
	int iIndex;

	try
	{
		// Mar 27/08
		// Adjusted so that the -100 variable has the same parameters as the first variable
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		csWriteLine.Format(_T("-100.0    %8.10f    %8.10f \n"), pdGain[0], pdPhase[0] * 180 / M_PI);
		cfOutput.WriteString(csWriteLine);

		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			csWriteLine.Format(_T("%8.10f    %8.10f    %8.10f \n"), pdMagIn[iIndex], pdGain[iIndex], pdPhase[iIndex] * 180 / M_PI);
			cfOutput.WriteString(csWriteLine);
		}

		cfOutput.Close();
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Returns the linear gain filename
///
/// \return linear gain filename
///
////////////////////////////////////////////////////////////////////////////////////
CString ModelFilterBaseClass::GetLinearGainFilename()
{
	return m_csLinearGainFilename;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Identifies the filter for (Augmented) Hammerstein/Wiener models
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/filterIdentification.m"> filterIdentification.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::FilterIdentification(void)
{
	CString csFilenameIn;
	CString csFilenameOut;
	
	doublecomplex* pcdDataIn = NULL;
	doublecomplex* pcdDataOut = NULL;
	double* pdI_in = NULL;
	double* pdQ_in = NULL;
	double* pdI_out = NULL;
	double* pdQ_out = NULL;
	int iLength_in;
	int iLength_out;
	int iLength;
	int iIndex;

	int iMM;
	
	// If the Filter Identification box has not been checked, exit.
	if(!m_iFilterIdentification)
	{
		return;
	}

	try
	{
		// Recreate Filenames for extracted filter data
		if(m_bAppType)
		{
			// Hammerstein
			if(m_eModelType == MODEL_HAMMERSTEIN || m_eModelType == MODEL_AUGMENTED_HAMMERSTEIN)
			{
				csFilenameIn.Format(_T("%s%s_IQin_%s_%s_HammFilterNT.txt"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType, m_csSignalType);
				csFilenameOut.Format(_T("%s%s_IQout_%s_%s_HammFilterNT.txt"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType, m_csSignalType);
			}
			// Wiener
			else
			{
				csFilenameIn.Format(_T("%s%s_IQin_%s_%s_WienerFilterNT.txt"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType, m_csSignalType);
				csFilenameOut.Format(_T("%s%s_IQout_%s_%s_WienerFilterNT.txt"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType, m_csSignalType);
			}
		}
		else
		{
			// Hammerstein
			if(m_eModelType == MODEL_HAMMERSTEIN || m_eModelType == MODEL_AUGMENTED_HAMMERSTEIN)
			{
				csFilenameIn.Format(_T("%s%s_IQin_%s_%s_HammFilterNT.txt"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType, m_csSignalType);
				csFilenameOut.Format(_T("%s%s_IQout_%s_%s_HammFilterNT.txt"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType, m_csSignalType);
			}
			// Wiener
			else
			{
				csFilenameIn.Format(_T("%s%s_IQin_%s_%s_WienerFilterNT.txt"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType, m_csSignalType);
				csFilenameOut.Format(_T("%s%s_IQout_%s_%s_WienerFilterNT.txt"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType, m_csSignalType);
			}
		}

		// Read in Data
		iLength_in = GetNumDataInTxtFile(TRUE, csFilenameIn);
		if(iLength_in <= 0)
		{
			EXCEPTION_ADDUSERMESSAGE(_T("Invalid File") + csFilenameIn);
			AfxThrowUserException();
		}

		pdI_in = new double[iLength_in];
		pdQ_in = new double[iLength_in];
		ReadDataFromTxtFile(pdI_in, pdQ_in, iLength_in, csFilenameIn);
		
		iLength_out = GetNumDataInTxtFile(TRUE, csFilenameOut);
		if(iLength_out <= 0)
		{
			EXCEPTION_ADDUSERMESSAGE(_T("Invalid File") + csFilenameIn);
			AfxThrowUserException();
		}

		pdI_out = new double[iLength_out];
		pdQ_out = new double[iLength_out];
		ReadDataFromTxtFile(pdI_out, pdQ_out, iLength_out, csFilenameOut);

		// Taking smaller of two lengths
		if(iLength_in < iLength_out)
		{
			iLength = iLength_in;
		}
		else
		{
			iLength = iLength_out;
		}
		
		pcdDataIn = new doublecomplex[iLength];
		pcdDataOut = new doublecomplex[iLength];
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pcdDataIn[iIndex].r = pdI_in[iIndex];
			pcdDataIn[iIndex].i = pdQ_in[iIndex];
			pcdDataOut[iIndex].r = pdI_out[iIndex];
			pcdDataOut[iIndex].i = pdQ_out[iIndex];
		}

		iMM = 64;

		int iOrder = 0;
		// Call Traning Algorithms
		if(m_eModelType == MODEL_HAMMERSTEIN || m_eModelType == MODEL_WIENER)
		{
			TrainMBPoly(pcdDataIn, pcdDataOut, iLength, iMM, iOrder);
		}
		// Else augmented filter
		else
		{
			TrainX2FIR(pcdDataIn, pcdDataOut, iLength, iMM, iOrder);
		}
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pcdDataIn);
		SAFE_DELETE_ARRAY(pcdDataOut);
		SAFE_DELETE_ARRAY(pdI_in);
		SAFE_DELETE_ARRAY(pdQ_in);
		SAFE_DELETE_ARRAY(pdI_out);
		SAFE_DELETE_ARRAY(pdQ_out);
		
		throw;
	}

	SAFE_DELETE_ARRAY(pcdDataIn);
	SAFE_DELETE_ARRAY(pcdDataOut);
	SAFE_DELETE_ARRAY(pdI_in);
	SAFE_DELETE_ARRAY(pdQ_in);
	SAFE_DELETE_ARRAY(pdI_out);
	SAFE_DELETE_ARRAY(pdQ_out);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Fits the data using a polynomial fitting
///
/// \param pcdDataIn input data
/// \param pcdDataOut output data
/// \param iLength length of data vectors
/// \param iMM training length
/// \param iOrder order (should be 0 for TDL)
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/trainMB_POLYfunc.m"> trainMB_POLYfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::TrainMBPoly(doublecomplex* pcdDataIn, doublecomplex* pcdDataOut, int iLength, int iMM, int iOrder)
{
	CString csFilterType;
	CString csFilename;
	CString csTxtFilename;
	doublecomplex* pcdXin = NULL;
	doublecomplex* pcdYin = NULL;
	int iO;
	int iK;
	int iIndex;
	doublecomplex* pcdX1 = NULL;
	doublecomplex* pcdY1 = NULL;
	doublecomplex* pcdAMatrix = NULL;
	int iNumRows;
	int iNumCols;

	ConvertToMatrix cConvertMatrix;
	SolverBaseClass* pSolverBaseClass = NULL;

	doublecomplex* pcdCoeffs = NULL;

	CString csLUTFilename;
	CString csModelParametersFilename;
	CString csPhaseOffsetFilename;
	doublecomplex* pcdYSim = NULL;

	double dNMSE;
	double dNMSEdB;
	double dVar;
	double dVardB;
	double dPAR;
	double dPARdB;

	PlotUtility cPlot;
	MODEL_PARAMS sModelParams;

	CStdioFile cfOutput;
	CString csWriteLine;

	try
	{
		if(m_bAppType)
		{
			if(m_eModelType == MODEL_HAMMERSTEIN)
			{
				csFilterType.Format(_T("%s_HammFilter_%s"), APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType);
			}
			else
			{
				csFilterType.Format(_T("%s_WienerFilter_%s"), APP_TYPE_REVERSE_MODEL_NAME,m_csSystemType);
			}
		}
		else
		{
			if(m_eModelType == MODEL_HAMMERSTEIN)
			{
				csFilterType.Format(_T("%s_HammFilter_%s"), APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType);
			}
			else
			{
				csFilterType.Format(_T("%s_WienerFilter_%s"), APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType);
			}
		}

		csFilename.Format(_T("%s%s_%s_Coeff%dtaps%dorder%sdata%dx.mdf"), m_csFilepath, csFilterType, m_csMethodType, m_iTaps, iOrder, m_csSignalType, iMM);
		csTxtFilename.Format(_T("%s%s_%s_Coeff%dtaps%dorder%sdata%dx.txt"), m_csFilepath, csFilterType, m_csMethodType, m_iTaps, iOrder, m_csSignalType, iMM);

		// length already passed in.
		iK = iMM * 128;
		iO = 0;

		pcdXin = new doublecomplex[iK];
		pcdYin = new doublecomplex[iK];

		for(iIndex = iO; iIndex < iK + iO; iIndex++)
		{
			pcdXin[iIndex - iO].r = pcdDataIn[iIndex].r;
			pcdXin[iIndex - iO].i = pcdDataIn[iIndex].i;
			pcdYin[iIndex - iO].r = pcdDataOut[iIndex].r;
			pcdYin[iIndex - iO].i = pcdDataOut[iIndex].i;
		}

		// Initialization of A matrix
		cConvertMatrix.SetInputX(pcdXin, iK);
		cConvertMatrix.SetOutputY(pcdYin, iK);
		cConvertMatrix.SetParameters(m_iTaps, iOrder, CONVERSION_POLYA1);
		cConvertMatrix.Run();
		pcdAMatrix = cConvertMatrix.GetResultAMatrix(&iNumRows, &iNumCols);
		pcdX1 = cConvertMatrix.GetResultX();
		pcdY1 = cConvertMatrix.GetResultY();


		// Case Statement for switching.
		switch(m_eMethodType)
		{
			case METHOD_SVD:
				pSolverBaseClass = new SolverSVD;
				break;
			case METHOD_QRRLS:
				pSolverBaseClass = new SolverQRRLS;
				break;
			case METHOD_RLS:
				pSolverBaseClass = new SolverRLS;
				break;
			case METHOD_LMS:
				pSolverBaseClass = new SolverLMS;
				break;
			default:
				AfxMessageBox(_T("Invalid Method Type, exiting..."));
				AfxThrowUserException();
		}

		pcdCoeffs = new doublecomplex[iNumCols];

		pSolverBaseClass->SetAMatrixParameters((double*) pcdAMatrix, iNumRows, iNumCols, true);
		pSolverBaseClass->SetOtherMatrixParameters((double*) pcdY1, (double*) pcdCoeffs);
		pSolverBaseClass->SetAdditionalParameters(m_dDelta, m_dLambda, m_dMu);
		pSolverBaseClass->SolveMatrix();

		if(m_bAppType)
		{
			csLUTFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
			csModelParametersFilename.Format(_T("%s%s_%s_%s_%s_%s_modelParameters.nsm"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csModelType, m_csMethodType, m_csSystemType, m_csSignalType);
		}
		else
		{
			csLUTFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
			csModelParametersFilename.Format(_T("%s%s_%s_%s_%s_%s_modelParameters.nsm"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csModelType, m_csMethodType, m_csSystemType, m_csSignalType);
		}
		csPhaseOffsetFilename.Format(_T("%s%s_%s_LinearGain.txt"), m_csFilepath, m_csSystemType, m_csSignalType);


		SaveParameters(pcdCoeffs, iNumCols, csLUTFilename, csPhaseOffsetFilename, csModelParametersFilename);

		// Recreate Outputs
		pcdYSim = new doublecomplex[iNumRows];
		MatrixMultiply(pcdAMatrix, iNumRows, iNumCols, pcdCoeffs, 1, pcdYSim);
		// Ignore Condition Number

		// Calculate NMSE of training Results
		NMSEdBVarFunc(pcdYSim, pcdY1, iNumRows, &dNMSE, &dNMSEdB, &dVar, &dVardB, &dPAR, &dPARdB);

		// Ignore nmsedbfunc, including making FFTS, etc. Does not seem to be used later.
		// Also ignore the coefficients, calculating min/max, dynamic range

		SavePolynomialCoefficients(pcdCoeffs, iNumCols, csFilename, csTxtFilename);

		// if Order == 0
		if(iOrder == 0)
		{
			csTxtFilename.Format(_T("%s%s_%s_Coeff%dtaps%dorder%sdata%dx_adsFIR1.txt"), m_csFilepath, csFilterType, m_csModelType, m_iTaps, iOrder, m_csSignalType, iMM);

			cfOutput.Open(csTxtFilename, CFile::modeWrite | CFile::modeCreate);

			for(iIndex = 0; iIndex < iNumCols; iIndex++)
			{
				csWriteLine.Format(_T("(%2.14f, %2.14f)\n"), pcdCoeffs[iIndex].r, pcdCoeffs[iIndex].i);
				cfOutput.WriteString(csWriteLine);
			}
			cfOutput.Close();

		}

		if(!m_bSmallSignalGain)
		{
			/// Verify with display filter training results....
			cPlot.SetInputs(pcdX1, pcdY1, pcdYSim, iNumRows);
			
			////////////////////////////////////
			sModelParams.m_csAppType = m_csAppType;
			sModelParams.m_csLUTFilename = csLUTFilename;
			sModelParams.m_csPhaseOffsetFilename = csPhaseOffsetFilename;
			sModelParams.m_csPAType = m_csSystemType;
			sModelParams.m_csSignalType = m_csSignalType;
			sModelParams.m_dInputAttenuation = m_dInputAttenuation;
			sModelParams.m_dOutputAttenuation = m_dOutputAttenuation;
			sModelParams.m_eMethod = m_eMethodType;
			sModelParams.m_iTaps = m_iTaps;
			sModelParams.m_iOrder = iOrder;
			sModelParams.m_eModel = m_eModelType;
			sModelParams.m_iCoeffLength = iNumCols;

			sModelParams.m_pcdCoeff = new doublecomplex[iNumCols];

			for(iIndex = 0; iIndex < iNumCols; iIndex++)
			{
				sModelParams.m_pcdCoeff[iIndex].r = pcdCoeffs[iIndex].r;
				sModelParams.m_pcdCoeff[iIndex].i = pcdCoeffs[iIndex].i;
			}

			/////////////////////////////////////
			cPlot.SetModelParameters(sModelParams);
			cPlot.SetSpectrumParameters(m_sSpectrumParams);
			cPlot.DisplayFilterTrainingResults();
			delete [] sModelParams.m_pcdCoeff;

		}

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE(pSolverBaseClass);
		SAFE_DELETE_ARRAY(pcdXin);
		SAFE_DELETE_ARRAY(pcdYin);
		SAFE_DELETE_ARRAY(pcdAMatrix);
		SAFE_DELETE_ARRAY(pcdX1);
		SAFE_DELETE_ARRAY(pcdY1);
		SAFE_DELETE_ARRAY(pcdCoeffs);
		SAFE_DELETE_ARRAY(pcdYSim);

		throw;
	}

	SAFE_DELETE(pSolverBaseClass);
	SAFE_DELETE_ARRAY(pcdXin);
	SAFE_DELETE_ARRAY(pcdYin);
	SAFE_DELETE_ARRAY(pcdAMatrix);
	SAFE_DELETE_ARRAY(pcdX1);
	SAFE_DELETE_ARRAY(pcdY1);
	SAFE_DELETE_ARRAY(pcdCoeffs);
	SAFE_DELETE_ARRAY(pcdYSim);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Fits the data using a dual FIR architecture
///
/// \param pcdDataIn input data
/// \param pcdDataOut output data
/// \param iLength length of data vectors
/// \param iMM training length
/// \param iOrder order (should be 0 for TDL)
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/trainX2_FIRfunc.m"> trainX2_FIRfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::TrainX2FIR(doublecomplex* pcdDataIn, doublecomplex* pcdDataOut, int iLength, int iMM, int iOrder)
{
	CString csFilterType;
	CString csFilename1;
	CString csFilename2;
	CString csTxtFilename1;
	CString csTxtFilename2;
	doublecomplex* pcdXin = NULL;
	doublecomplex* pcdYin = NULL;
	int iO;
	int iK;
	int iIndex;
	doublecomplex* pcdX1 = NULL;
	doublecomplex* pcdY1 = NULL;
	doublecomplex* pcdAMatrix = NULL;
	int iNumRows;
	int iNumCols;

	ConvertToMatrix cConvertMatrix;
	SolverBaseClass* pSolverBaseClass = NULL;

	doublecomplex* pcdCoeffs = NULL;

	CString csLUTFilename;
	CString csModelParametersFilename;
	CString csPhaseOffsetFilename;
	doublecomplex* pcdYSim = NULL;

	double dNMSE;
	double dNMSEdB;
	double dVar;
	double dVardB;
	double dPAR;
	double dPARdB;

	PlotUtility cPlot;
	MODEL_PARAMS sModelParams;

	CStdioFile cfOutput;
	CString csWriteLine;

	try
	{
		if(m_bAppType)
		{
			if(m_eModelType == MODEL_AUGMENTED_HAMMERSTEIN)
			{
				csFilterType.Format(_T("%s_AugHammFilter_%s"), APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType);
			}
			else
			{
				csFilterType.Format(_T("%s_AugWienerFilter_%s"), APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType);
			}
		}
		else
		{
			if(m_eModelType == MODEL_AUGMENTED_HAMMERSTEIN)
			{
				csFilterType.Format(_T("%s_AugHammFilter_%s"), APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType);
			}
			else
			{
				csFilterType.Format(_T("%s_AugWienerFilter_%s"), APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType);
			}
		}

		csFilename1.Format(_T("%s%s_%sX2_FIR1_Coeff%dtaps%dorder%sdata%dx.mdf"), m_csFilepath, csFilterType, m_csMethodType, m_iTaps, iOrder, m_csSignalType, iMM);
		csFilename2.Format(_T("%s%s_%sX2_FIR2_Coeff%dtaps%dorder%sdata%dx.mdf"), m_csFilepath, csFilterType, m_csMethodType, m_iTaps, iOrder, m_csSignalType, iMM);
		csTxtFilename1.Format(_T("%s%sX2_%s_FIR1_Coeff%dtaps%dorder%sdata%dx.txt"), m_csFilepath, csFilterType, m_csMethodType, m_iTaps, iOrder, m_csSignalType, iMM);
		csTxtFilename2.Format(_T("%s%sX2_%s_FIR2_Coeff%dtaps%dorder%sdata%dx.txt"), m_csFilepath, csFilterType, m_csMethodType, m_iTaps, iOrder, m_csSignalType, iMM);

		// length already passed in.
		iK = iMM * 128;
		iO = 0;

		pcdXin = new doublecomplex[iK];
		pcdYin = new doublecomplex[iK];

		for(iIndex = iO; iIndex < iK + iO; iIndex++)
		{
			pcdXin[iIndex - iO].r = pcdDataIn[iIndex].r;
			pcdXin[iIndex - iO].i = pcdDataIn[iIndex].i;
			pcdYin[iIndex - iO].r = pcdDataOut[iIndex].r;
			pcdYin[iIndex - iO].i = pcdDataOut[iIndex].i;
		}

		// Initialization of A matrix
		cConvertMatrix.SetInputX(pcdXin, iK);
		cConvertMatrix.SetOutputY(pcdYin, iK);
		cConvertMatrix.SetParameters(m_iTaps, iOrder, CONVERSION_X2_FIRA1);
		cConvertMatrix.Run();
		pcdAMatrix = cConvertMatrix.GetResultAMatrix(&iNumRows, &iNumCols);
		pcdX1 = cConvertMatrix.GetResultX();
		pcdY1 = cConvertMatrix.GetResultY();


		// Case Statement for switching.
		switch(m_eMethodType)
		{
			case METHOD_SVD:
				pSolverBaseClass = new SolverSVD;
				break;
			case METHOD_QRRLS:
				pSolverBaseClass = new SolverQRRLS;
				break;
			case METHOD_RLS:
				pSolverBaseClass = new SolverRLS;
				break;
			case METHOD_LMS:
				pSolverBaseClass = new SolverLMS;
				break;
			default:
				AfxMessageBox(_T("Invalid Method Type, exiting..."));
				AfxThrowUserException();
		}

		pcdCoeffs = new doublecomplex[iNumCols];

		pSolverBaseClass->SetAMatrixParameters((double*) pcdAMatrix, iNumRows, iNumCols, true);
		pSolverBaseClass->SetOtherMatrixParameters((double*) pcdY1, (double*) pcdCoeffs);
		pSolverBaseClass->SetAdditionalParameters(m_dDelta, m_dLambda, m_dMu);
		pSolverBaseClass->SolveMatrix();

		if(m_bAppType)
		{
			csLUTFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
			csModelParametersFilename.Format(_T("%s%s_%s_%s_%s_%s_modelParameters.nsm"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csModelType, m_csMethodType, m_csSystemType, m_csSignalType);
		}
		else
		{
			csLUTFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
			csModelParametersFilename.Format(_T("%s%s_%s_%s_%s_%s_modelParameters.nsm"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csModelType, m_csMethodType, m_csSystemType, m_csSignalType);
		}
		csPhaseOffsetFilename.Format(_T("%s%s_%s_LinearGain.txt"), m_csFilepath, m_csSystemType, m_csSignalType);


		SaveParameters(pcdCoeffs, iNumCols, csLUTFilename, csPhaseOffsetFilename, csModelParametersFilename);

		// Recreate Outputs
		pcdYSim = new doublecomplex[iNumRows];
		MatrixMultiply(pcdAMatrix, iNumRows, iNumCols, pcdCoeffs, 1, pcdYSim);
		// Ignore Condition Number

		// Calculate NMSE of training Results
		NMSEdBVarFunc(pcdYSim, pcdY1, iNumRows, &dNMSE, &dNMSEdB, &dVar, &dVardB, &dPAR, &dPARdB);

		// Ignore nmsedbfunc, including making FFTS, etc. Does not seem to be used later.
		// Also ignore the coefficients, calculating min/max, dynamic range

		// Save Coefficients (need to split between FIR1 and FIR2, FIR1 is first half, FIR2 is second half)
		SavePolynomialCoefficients(&pcdCoeffs[0], iNumCols/2, csFilename1, csTxtFilename1);
		SavePolynomialCoefficients(&pcdCoeffs[iNumCols/2], iNumCols/2, csFilename2, csTxtFilename2);

		/// Verify with display filter training results....
		cPlot.SetInputs(pcdX1, pcdY1, pcdYSim, iNumRows);
		
		////////////////////////////////////
		sModelParams.m_csAppType = m_csAppType;
		sModelParams.m_csLUTFilename = csLUTFilename;
		sModelParams.m_csPhaseOffsetFilename = csPhaseOffsetFilename;
		sModelParams.m_csPAType = m_csSystemType;
		sModelParams.m_csSignalType = m_csSignalType;
		sModelParams.m_dInputAttenuation = m_dInputAttenuation;
		sModelParams.m_dOutputAttenuation = m_dOutputAttenuation;
		sModelParams.m_eMethod = m_eMethodType;
		sModelParams.m_iTaps = m_iTaps;
		sModelParams.m_iOrder = iOrder;
		sModelParams.m_eModel = m_eModelType;
		sModelParams.m_iCoeffLength = iNumCols;

		sModelParams.m_pcdCoeff = new doublecomplex[iNumCols];

		for(iIndex = 0; iIndex < iNumCols; iIndex++)
		{
			sModelParams.m_pcdCoeff[iIndex].r = pcdCoeffs[iIndex].r;
			sModelParams.m_pcdCoeff[iIndex].i = pcdCoeffs[iIndex].i;
		}

		/////////////////////////////////////
		cPlot.SetModelParameters(sModelParams);
		cPlot.SetSpectrumParameters(m_sSpectrumParams);
		cPlot.DisplayFilterTrainingResults();


		delete [] sModelParams.m_pcdCoeff;
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE(pSolverBaseClass);
		SAFE_DELETE_ARRAY(pcdXin);
		SAFE_DELETE_ARRAY(pcdYin);
		SAFE_DELETE_ARRAY(pcdAMatrix);
		SAFE_DELETE_ARRAY(pcdX1);
		SAFE_DELETE_ARRAY(pcdY1);
		SAFE_DELETE_ARRAY(pcdCoeffs);
		SAFE_DELETE_ARRAY(pcdYSim);

		throw;
	}

	SAFE_DELETE(pSolverBaseClass);
	SAFE_DELETE_ARRAY(pcdXin);
	SAFE_DELETE_ARRAY(pcdYin);
	SAFE_DELETE_ARRAY(pcdAMatrix);
	SAFE_DELETE_ARRAY(pcdX1);
	SAFE_DELETE_ARRAY(pcdY1);
	SAFE_DELETE_ARRAY(pcdCoeffs);
	SAFE_DELETE_ARRAY(pcdYSim);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// De-embed the nonlinearity with the LSE approach
///
/// \param iTaps number of taps (should be 1)
/// \param iOrder polynomial order
/// \param pcdXTrained input trained data
/// \param pcdYTrained output trained data
/// \param iTrainedLength length of input arrays
/// \param dPinThreshdB minimum pin threshold
/// \param [out] psOutputLUT generated output LUT
/// \param [out] pdPhaseOffset generated phase offset
/// \param [out] pcdCoeffs polynomial coefficients
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/DeEmbedingNonlinearityLSEfunc.m"> DeEmbedingNonlinearityLSEfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::DeembedNonlinearityLSE(int iTaps, int iOrder, doublecomplex* pcdXTrained, doublecomplex* pcdYTrained, int iTrainedLength, double dPinThreshdB, MAGGAINPHASE* psOutputLUT, double* pdPhaseOffset, doublecomplex* pcdCoeffs)
{
	doublecomplex* pcdDataInPoly = NULL;
	doublecomplex* pcdDataOutPoly = NULL;
	int iPolyLength;
	double* pdMagInPoly = NULL;
	double* pdMagOutPoly = NULL;
	double* pdPhaseTemp = NULL;
	double* pdPhasePoly = NULL;
	double* pdGainPoly = NULL;
	int iIndex;

	/// \bug should this be here?
	// Mar 27/08
	// Changed to actual bit length
	int iDataBits = (int) (log10(double(m_iLUTSize)) / log10(2.0));
	double dPinCutTh = -40;

	try
	{
		// Know the length of output vectors
		iPolyLength = iTrainedLength;

		pcdDataInPoly = new doublecomplex[iPolyLength];
		pcdDataOutPoly = new doublecomplex[iPolyLength];

		PolyLSESolver(iTaps, iOrder, pcdXTrained, pcdYTrained, iTrainedLength, pcdDataInPoly, pcdDataOutPoly, pcdCoeffs);

		pdMagInPoly = new double[iPolyLength];
		pdMagOutPoly = new double[iPolyLength];
		pdPhaseTemp = new double[iPolyLength];
		pdPhasePoly = new double[iPolyLength];
		pdGainPoly = new double[iPolyLength];

		MatlabAbs(pcdDataInPoly, pdMagInPoly, iPolyLength);
		MatlabAbs(pcdDataOutPoly, pdMagOutPoly, iPolyLength);
		for(iIndex = 0; iIndex < iPolyLength; iIndex++)
		{
			pdPhaseTemp[iIndex] = atan2(pcdDataInPoly[iIndex].r * pcdDataOutPoly[iIndex].i - pcdDataOutPoly[iIndex].r * pcdDataInPoly[iIndex].i,
										pcdDataInPoly[iIndex].r * pcdDataOutPoly[iIndex].r + pcdDataInPoly[iIndex].i * pcdDataOutPoly[iIndex].i);
		}

		MatlabUnwrap(pdPhaseTemp, pdPhasePoly, iPolyLength);

		VectorDivide(pdMagOutPoly, pdMagInPoly, iPolyLength, pdGainPoly);

		// Call Make LUT
		// MakeLUTWithPoly(pdMagIn, pdGain, pdPhase, iRows, pdMagInLUT, pdGainLUT, pdPhaseLUT, pdOffsetLUT);
		MakeLUTWithPoly(pdMagInPoly, pdGainPoly, pdPhasePoly, iPolyLength, psOutputLUT, pdPhaseOffset, iDataBits);
		

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pcdDataInPoly);
		SAFE_DELETE_ARRAY(pcdDataOutPoly);
		SAFE_DELETE_ARRAY(pdMagInPoly);
		SAFE_DELETE_ARRAY(pdMagOutPoly);
		SAFE_DELETE_ARRAY(pdPhaseTemp);
		SAFE_DELETE_ARRAY(pdPhasePoly);
		SAFE_DELETE_ARRAY(pdGainPoly);

		throw;
	}

	SAFE_DELETE_ARRAY(pcdDataInPoly);
	SAFE_DELETE_ARRAY(pcdDataOutPoly);
	SAFE_DELETE_ARRAY(pdMagInPoly);
	SAFE_DELETE_ARRAY(pdMagOutPoly);
	SAFE_DELETE_ARRAY(pdPhaseTemp);
	SAFE_DELETE_ARRAY(pdPhasePoly);
	SAFE_DELETE_ARRAY(pdGainPoly);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Solves using a polynomial model
///
/// \param iTaps number of taps
/// \param iOrder order
/// \param pcdXin input data X
/// \param pcdYin input data Y
/// \param iInputLength length of input vectors
/// \param [out] pcdXout resulting vector x
/// \param [out] pcdYout resulting vector y (multiplying x with coefficients)
/// \param [out] pcdCoeffs coefficients
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/polyLSEsloverfunc.m"> polyLSEsloverfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::PolyLSESolver(int iTaps, int iOrder, doublecomplex* pcdXin, doublecomplex* pcdYin, int iInputLength, doublecomplex* pcdXout, doublecomplex* pcdYout, doublecomplex* pcdCoeffs)
{
	ConvertToMatrix cMatrix;
	doublecomplex* pcdA = NULL;
	doublecomplex* pcdResultX = NULL;
	doublecomplex* pcdResultY = NULL;
	int iRowsA, iColsA;

	SolverSVD cSVD;


	try
	{
		// Reuse code
		cMatrix.SetInputX(pcdXin, iInputLength);
		cMatrix.SetOutputY(pcdYin, iInputLength);
		cMatrix.SetParameters(iTaps, iOrder, CONVERSION_POLYSEA1);
		cMatrix.Run();

		pcdResultX = cMatrix.GetResultX();
		pcdResultY = cMatrix.GetResultY();
		pcdA = cMatrix.GetResultAMatrix(&iRowsA, &iColsA);

		cSVD.SetAMatrixParameters((double*) pcdA, iRowsA, iColsA, true);
		cSVD.SetOtherMatrixParameters((double*) pcdResultY, (double*) pcdCoeffs);
		cSVD.SolveMatrix();

		// Multiply coefficients with A
		MatrixMultiply(pcdA, iRowsA, iColsA, pcdCoeffs, 1, pcdYout);
		
		// Copy X
		for(int iIndex = 0; iIndex < iRowsA; iIndex++)
		{
			pcdXout[iIndex].r = pcdResultX[iIndex].r;
			pcdXout[iIndex].i = pcdResultX[iIndex].i;
		}
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pcdA);
		SAFE_DELETE_ARRAY(pcdResultX);
		SAFE_DELETE_ARRAY(pcdResultY);

		throw;
	}

	SAFE_DELETE_ARRAY(pcdA);
	SAFE_DELETE_ARRAY(pcdResultX);
	SAFE_DELETE_ARRAY(pcdResultY);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Saves Neural Network Data into files (factored from GeneratePolyLUT)
///
/// \param psPALUT the PALUT
/// \param psDPDLUT the DPDLUT
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::SaveNNFiles(MAGGAINPHASE* psPALUT, MAGGAINPHASE* psDPDLUT)
{
	CStdioFile cfOutput;
	CString csWriteLine;
	CString csFilename;
	int iIndex;
	double dI, dQ;

	try
	{
		// Saving PA Model Data
		csFilename.Format(_T("%s%s_%s_%s_Magin_LUT_NN.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		cfOutput.WriteString(_T("MagIn \n"));
		for(iIndex = 0; iIndex < psPALUT->m_iLength; iIndex++)
		{
			csWriteLine.Format(_T("%8.10f \n"), psPALUT->m_pdMagIn[iIndex]);
			cfOutput.WriteString(csWriteLine);
		}
		cfOutput.Close();

		csFilename.Format(_T("%s%s_%s_%s_GainPhi_LUT_NN.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		cfOutput.WriteString(_T("Gain         Phi \n"));
		for(iIndex = 0; iIndex < psPALUT->m_iLength; iIndex++)
		{
			csWriteLine.Format(_T("%8.10f      %8.10f\n"), psPALUT->m_pdGain[iIndex], psPALUT->m_pdPhase[iIndex]);
			cfOutput.WriteString(csWriteLine);
		}
		cfOutput.Close();

		// Saving DPD Model Data
		csFilename.Format(_T("%s%s_%s_%s_Magin_LUT_NN.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		cfOutput.WriteString(_T("MagIn \n"));
		for(iIndex = 0; iIndex < psDPDLUT->m_iLength; iIndex++)
		{
			csWriteLine.Format(_T("%8.10f\n"), psDPDLUT->m_pdMagIn[iIndex]);
			cfOutput.WriteString(csWriteLine);
		}
		cfOutput.Close();

		csFilename.Format(_T("%s%s_%s_%s_GainPhi_LUT_NN.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		cfOutput.WriteString(_T("Gain         Phi \n"));
		for(iIndex = 0; iIndex < psDPDLUT->m_iLength; iIndex++)
		{
			csWriteLine.Format(_T("%8.10f          %8.10f\n"), psDPDLUT->m_pdGain[iIndex], psDPDLUT->m_pdPhase[iIndex]);
			cfOutput.WriteString(csWriteLine);
		}
		cfOutput.Close();

		csFilename.Format(_T("%s%s_%s_%s_IQ_LUT_NN.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		cfOutput.Open(csFilename, CFile::modeWrite | CFile::modeCreate);
		cfOutput.WriteString(_T("I        Q \n"));
		for(iIndex = 0; iIndex < psDPDLUT->m_iLength; iIndex++)
		{
			dI = psDPDLUT->m_pdGain[iIndex] * cos(psDPDLUT->m_pdPhase[iIndex]);
			dQ = psDPDLUT->m_pdGain[iIndex] * sin(psDPDLUT->m_pdPhase[iIndex]);
			csWriteLine.Format(_T("%8.10f          %8.10f\n"), dI, dQ);
			cfOutput.WriteString(csWriteLine);
		}
		cfOutput.Close();

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs gain/phase interpolation
/// \note why is in global.
///
/// \param psInitialLUT the LUT parameters
/// \param [out] psOutput initially, contains only the desired magnitude, at output, contains gain and phase after LUT
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/Global/tjInterpolationGainPhaseFunc.m"> tjInterpolationGainPhaseFunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::InterpolationGainPhase(MAGGAINPHASE* psInitialLUT, MAGGAINPHASE* psOutput)
{
	int iIndex;
	int iIndexJ;
	int iIndexK;
	int iN1;
	int iN2;
	int iM;

	try
	{
		for(iIndex = 0; iIndex < psOutput->m_iLength; iIndex++)
		{
			iN1 = 0;
			iN2 = psInitialLUT->m_iLength - 1;

			// Check for minimum of LUT
			if(psOutput->m_pdMagIn[iIndex] <= psInitialLUT->m_pdMagIn[0])
			{
				psOutput->m_pdGain[iIndex] = psInitialLUT->m_pdGain[0];
				psOutput->m_pdPhase[iIndex] = psInitialLUT->m_pdPhase[0];
			}
			// Check for maximum of LUT
			else if(psOutput->m_pdMagIn[iIndex] >= psInitialLUT->m_pdMagIn[psInitialLUT->m_iLength - 1])
			{
				/// \bug in MATLAB code, always picks 1. I think it should pick the maximum of the LUT
				psOutput->m_pdGain[iIndex] = psInitialLUT->m_pdGain[psInitialLUT->m_iLength - 1];
				psOutput->m_pdPhase[iIndex] = psInitialLUT->m_pdPhase[psInitialLUT->m_iLength - 1];
			}
			// Anywhere between minimum and maximum, interpolate to find correct value
			else
			{
				iM = int(ceil(double(psInitialLUT->m_iLength) / 2.0));
				for(iIndexJ = 0; iIndexJ < iM; iIndexJ++)
				{
					iIndexK = iN1 + int(floor(double(iN2 - iN1) / 2.0));
					if(psOutput->m_pdMagIn[iIndex] > psInitialLUT->m_pdMagIn[iIndexK])
					{
						iN1 = iIndexK;
					}
					else if(psOutput->m_pdMagIn[iIndex] < psInitialLUT->m_pdMagIn[iIndexK])
					{
						iN2 = iIndexK;
					}
					// MagIn[iIndex] == LUTMagIn[ceil(N2/2)]
					else
					{
						psOutput->m_pdGain[iIndex] = psInitialLUT->m_pdGain[iIndexK];
						psOutput->m_pdPhase[iIndex] = psInitialLUT->m_pdPhase[iIndexK];
						iN1 = iIndexK;
						iN2 = iIndexK;
						break;
					}
				}

				// If an exact value was not found, perform interpolation between 2 points
				// Linear Intepolation
				if((iN2 - iN1) == 1)
				{
					psOutput->m_pdGain[iIndex] = psInitialLUT->m_pdGain[iN1] +
						(psInitialLUT->m_pdGain[iN2] - psInitialLUT->m_pdGain[iN1]) *
						(psOutput->m_pdMagIn[iIndex] - psInitialLUT->m_pdMagIn[iN1]) /
						(psInitialLUT->m_pdMagIn[iN2] - psInitialLUT->m_pdMagIn[iN1]);
					psOutput->m_pdPhase[iIndex] = psInitialLUT->m_pdPhase[iN1] +
						(psInitialLUT->m_pdPhase[iN2] - psInitialLUT->m_pdPhase[iN1]) *
						(psOutput->m_pdMagIn[iIndex] - psInitialLUT->m_pdMagIn[iN1]) /
						(psInitialLUT->m_pdMagIn[iN2] - psInitialLUT->m_pdMagIn[iN1]);
				}
			} // else
		}
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}


void ModelFilterBaseClass::GenerateDPD(MAGGAINPHASE& rsPALUT, MAGGAINPHASE& rsDPDLUT, double dLUTTruncate, double dSmallSignalGain, double dSmallSignalPhase, int iLUTSize)
{
	MAGGAINPHASE sTempLUT = MAGGAINPHASE_INIT;
	double* pdInterpPin = NULL;
	double dLUTTruncateMag;
	int iIndex;

	try
	{
		// Create Pin vector based on PA lengths
		sTempLUT.m_iLength = rsPALUT.m_iLength;
		sTempLUT.m_pdMagIn = new double[rsPALUT.m_iLength + 1];
		sTempLUT.m_pdGain = new double[rsPALUT.m_iLength + 1];
		sTempLUT.m_pdPhase = new double[rsPALUT.m_iLength + 1];

		for(iIndex = 0; iIndex < rsPALUT.m_iLength; iIndex++)
		{
			double dMag = 10 * log10((0.5 * pow(rsPALUT.m_pdMagIn[iIndex], 2.0))/50) + 30;
			double dGain = 20 * log10(rsPALUT.m_pdGain[iIndex]);
			sTempLUT.m_pdMagIn[iIndex] = dMag + (dGain - dSmallSignalGain);
			sTempLUT.m_pdGain[iIndex] = -(dGain - dSmallSignalGain);
			sTempLUT.m_pdPhase[iIndex] = -(rsPALUT.m_pdPhase[iIndex] - dSmallSignalPhase);
		}

		// Now interpolate to correct LUT Length
		// Check if input power in the range of dLUTTruncate; if not, then create a 'imaginary number' with copy of first element
/*		if(dLUTTruncate < sTempLUT.m_pdMagIn[0])
		{
			// Rotate up
			for(iIndex = sTempLUT.m_iLength - 1; iIndex >= 0; iIndex--)
			{
				sTempLUT.m_pdMagIn[iIndex + 1] = sTempLUT.m_pdMagIn[iIndex];
				sTempLUT.m_pdGain[iIndex + 1] = sTempLUT.m_pdGain[iIndex];
				sTempLUT.m_pdPhase[iIndex + 1] = sTempLUT.m_pdPhase[iIndex];
			}

			// Add last value
			sTempLUT.m_pdMagIn[0] = dLUTTruncate;
			// This is already done, but make sure anyways
			sTempLUT.m_pdGain[0] = sTempLUT.m_pdGain[1];
			sTempLUT.m_pdPhase[0] = sTempLUT.m_pdPhase[1];
			sTempLUT.m_iLength = sTempLUT.m_iLength + 1;
		}
*/
		// Convert Back to magnitude (squared)
		for(iIndex = 0; iIndex < sTempLUT.m_iLength; iIndex++)
		{
			sTempLUT.m_pdMagIn[iIndex] = sqrt(2 * 50 * pow(10.0, (sTempLUT.m_pdMagIn[iIndex] - 30) / 10.0));
			sTempLUT.m_pdGain[iIndex] = pow(10.0, sTempLUT.m_pdGain[iIndex] / 20.0);
		}

		// Interp
		// Allocate Memory
		rsDPDLUT.m_iLength = iLUTSize;
		rsDPDLUT.m_pdMagIn = new double[iLUTSize];
		rsDPDLUT.m_pdGain = new double[iLUTSize];
		rsDPDLUT.m_pdPhase = new double[iLUTSize];

		dLUTTruncateMag = sqrt(2 * 50 * pow(10.0, (dLUTTruncate - 30) / 10.0));
		for(iIndex = 0; iIndex < iLUTSize; iIndex++)
		{
			rsDPDLUT.m_pdMagIn[iIndex] = dLUTTruncateMag + ((sTempLUT.m_pdMagIn[sTempLUT.m_iLength - 1] - dLUTTruncateMag) * double(iIndex) / double(iLUTSize - 1));
		}

		// Do Not Interp
		for(iIndex = 0; iIndex < iLUTSize; iIndex++)
		{
			rsDPDLUT.m_pdMagIn[iIndex] = sTempLUT.m_pdMagIn[iIndex];
			rsDPDLUT.m_pdGain[iIndex] = sTempLUT.m_pdGain[iIndex];
			rsDPDLUT.m_pdPhase[iIndex] = sTempLUT.m_pdPhase[iIndex];

		}
		//MatlabInterp1(sTempLUT.m_pdMagIn, sTempLUT.m_pdGain, sTempLUT.m_iLength, rsDPDLUT.m_pdMagIn, rsDPDLUT.m_iLength, rsDPDLUT.m_pdGain);
		//MatlabInterp1(sTempLUT.m_pdMagIn, sTempLUT.m_pdPhase, sTempLUT.m_iLength, rsDPDLUT.m_pdMagIn, rsDPDLUT.m_iLength, rsDPDLUT.m_pdPhase);

		

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pdInterpPin);
		SAFE_DELETE_MAGGAINPHASE(sTempLUT);

		throw;
	}
	
	SAFE_DELETE_ARRAY(pdInterpPin);
	SAFE_DELETE_MAGGAINPHASE(sTempLUT);

	return;
}

////////////////////////////////////////////////////////////////////////////////////
///
/// Function to plot figures for memoryless algorithm
///
/// \param pcdInput original input
/// \param pcdOutput original output
/// \param iLength length of original vectors
/// \param rsPALUT PA LUT
/// \param rsDPDLUT DPD LUT
/// \param rsPostDPDLUT Post DPD LUT
/// \param dSmallSignalGain Small Signal Gain applied for DPD
/// \param dPhaseOffsetPA Phase offset for PA
/// \param dPhaseOffsetDPD Phase offset for DPD
/// \param dPhaseOffsetPostDPD Phase offset for Post DPD
///
////////////////////////////////////////////////////////////////////////////////////
void ModelFilterBaseClass::PlotMemoryless(doublecomplex* pcdInput, doublecomplex* pcdOutput, int iLength, MAGGAINPHASE& rsPALUT, MAGGAINPHASE& rsDPDLUT, MAGGAINPHASE& rsPostDPDLUT, double dSmallSignalGain, double dPhaseOffsetPA, double dPhaseOffsetDPD, double dPhaseOffsetPostDPD)
{
	CNtGraphDialog* pPA_AMAM;
	CNtGraphDialog* pPA_AMPM;
	CNtGraphDialog* pDPD_AMAM;
	CNtGraphDialog* pDPD_AMPM;
	CNtGraphDialog* pPostDPD_AMAM;
	CNtGraphDialog* pPostDPD_AMPM;

	double* pdMagIn = NULL;
	double* pdGain = NULL;
	double* pdPhase = NULL;
	doublecomplex* pcdOutputOverInput = NULL;
	int iIndex;

	try
	{
		CREATE_NTDIALOG_MODELESS(pPA_AMAM);
		CREATE_NTDIALOG_MODELESS(pPA_AMPM);
		pdMagIn = (iLength > rsPALUT.m_iLength) ? new double[iLength] : new double[rsPALUT.m_iLength];
		pdGain = (iLength > rsPALUT.m_iLength) ? new double[iLength] : new double[rsPALUT.m_iLength];
		pdPhase = (iLength > rsPALUT.m_iLength) ? new double[iLength] : new double[rsPALUT.m_iLength];
		pcdOutputOverInput = new doublecomplex[iLength];

		// Divide to get magnitude gain
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			ComplexDivide(&pcdOutput[iIndex], &pcdInput[iIndex], &pcdOutputOverInput[iIndex]);
		}

		MatlabAbs(pcdOutputOverInput, pdGain, iLength);
		MatlabPhase(pcdOutputOverInput, pdPhase, iLength);

		// Convert to gain db/phase deg
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pdMagIn[iIndex] = 10 * log10((0.5 * pow(MatlabAbs(pcdInput[iIndex]), 2.0)) / 50) + 30;
			pdGain[iIndex] = 20 * log10(pdGain[iIndex]);
			pdPhase[iIndex] = (pdPhase[iIndex] - dPhaseOffsetPA) * 180 / M_PI;
		}

		// Add Rotation of phase
		RotatePhase(pdPhase, iLength);

		pPA_AMAM->AddData(pdMagIn, pdGain, iLength, _T("Measurement Data"));
		pPA_AMAM->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
		pPA_AMPM->AddData(pdMagIn, pdPhase, iLength, _T("Measurement Data"));
		pPA_AMPM->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		for(iIndex = 0; iIndex < rsPALUT.m_iLength; iIndex++)
		{
			pdMagIn[iIndex] = 10 * log10((0.5 * pow(rsPALUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdGain[iIndex] = 20 * log10(rsPALUT.m_pdGain[iIndex]);
			pdPhase[iIndex] = rsPALUT.m_pdPhase[iIndex] * 180 / M_PI;
		}

		// Add Rotation of phase
		RotatePhase(pdPhase, rsPALUT.m_iLength);

		pPA_AMAM->AddData(pdMagIn, pdGain, rsPALUT.m_iLength, CString(APP_TYPE_FORWARD_MODEL_NAME) + _T(" LUT"));
		pPA_AMAM->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
		pPA_AMPM->AddData(pdMagIn, pdPhase, rsPALUT.m_iLength, CString(APP_TYPE_FORWARD_MODEL_NAME) + _T(" LUT"));
		pPA_AMPM->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		pPA_AMAM->SetTitle(CString(APP_TYPE_FORWARD_MODEL_NAME) + _T(" - AM-AM"));
		pPA_AMAM->SetXLabel(_T("Pin (dBm)"));
		pPA_AMAM->SetYLabel(_T("Gain (dB)"));
		pPA_AMAM->MyAutoFixAxis();
		pPA_AMAM->ShowLegend(0);
		pPA_AMPM->SetTitle(CString(APP_TYPE_FORWARD_MODEL_NAME) + _T(" - AM-PM"));
		pPA_AMPM->SetXLabel(_T("Pin (dBm)"));
		pPA_AMPM->SetYLabel(_T("Phase (deg)"));
		pPA_AMPM->MyAutoFixAxis();
		pPA_AMPM->ShowLegend(0);

		SAFE_DELETE_ARRAY(pdMagIn);
		SAFE_DELETE_ARRAY(pdGain);
		SAFE_DELETE_ARRAY(pdPhase);

		// DPD Plots

		CREATE_NTDIALOG_MODELESS(pDPD_AMAM);
		CREATE_NTDIALOG_MODELESS(pDPD_AMPM);
		pdMagIn = (iLength > rsDPDLUT.m_iLength) ? new double[iLength] : new double[rsDPDLUT.m_iLength];
		pdGain = (iLength > rsDPDLUT.m_iLength) ? new double[iLength] : new double[rsDPDLUT.m_iLength];
		pdPhase = (iLength > rsDPDLUT.m_iLength) ? new double[iLength] : new double[rsDPDLUT.m_iLength];

		MatlabAbs(pcdOutputOverInput, pdGain, iLength);
		MatlabPhase(pcdOutputOverInput, pdPhase, iLength);

		// Convert to gain db/phase deg
		dSmallSignalGain = 20 * log10(dSmallSignalGain);
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pdMagIn[iIndex] = 10 * log10((0.5 * pow(MatlabAbs(pcdInput[iIndex]), 2.0)) / 50) + 30;
			pdGain[iIndex] = 20 * log10(pdGain[iIndex]);
			pdPhase[iIndex] = (pdPhase[iIndex] + dPhaseOffsetDPD) * 180 / M_PI;
			pdMagIn[iIndex] = pdMagIn[iIndex] + (pdGain[iIndex] - dSmallSignalGain);
			pdGain[iIndex] = -(pdGain[iIndex] - dSmallSignalGain);
			pdPhase[iIndex] = -pdPhase[iIndex];
		}

		// Add Rotation of phase
		RotatePhase(pdPhase, iLength);

		pDPD_AMAM->AddData(pdMagIn, pdGain, iLength, _T("Measurement Data"));
		pDPD_AMAM->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
		pDPD_AMPM->AddData(pdMagIn, pdPhase, iLength, _T("Measurement Data"));
		pDPD_AMPM->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		for(iIndex = 0; iIndex < rsDPDLUT.m_iLength; iIndex++)
		{
			pdMagIn[iIndex] = 10 * log10((0.5 * pow(rsDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdGain[iIndex] = 20 * log10(rsDPDLUT.m_pdGain[iIndex]);
			pdPhase[iIndex] = rsDPDLUT.m_pdPhase[iIndex] * 180 / M_PI;
		}

		// Add Rotation of phase
		RotatePhase(pdPhase, rsDPDLUT.m_iLength);

		pDPD_AMAM->AddData(pdMagIn, pdGain, rsDPDLUT.m_iLength, CString(APP_TYPE_REVERSE_MODEL_NAME) + _T(" LUT"));
		pDPD_AMAM->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
		pDPD_AMPM->AddData(pdMagIn, pdPhase, rsDPDLUT.m_iLength, CString(APP_TYPE_REVERSE_MODEL_NAME) + _T(" LUT"));
		pDPD_AMPM->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		pDPD_AMAM->SetTitle(CString(APP_TYPE_REVERSE_MODEL_NAME) + _T(" - AM-AM"));
		pDPD_AMAM->SetXLabel(_T("Pin (dBm)"));
		pDPD_AMAM->SetYLabel(_T("Gain (dB)"));
		pDPD_AMAM->MyAutoFixAxis();
		pDPD_AMAM->ShowLegend(0);
		pDPD_AMPM->SetTitle(CString(APP_TYPE_REVERSE_MODEL_NAME) + _T(" - AM-PM"));
		pDPD_AMPM->SetXLabel(_T("Pin (dBm)"));
		pDPD_AMPM->SetYLabel(_T("Phase (deg)"));
		pDPD_AMPM->MyAutoFixAxis();
		pDPD_AMPM->ShowLegend(0);


		SAFE_DELETE_ARRAY(pdMagIn);
		SAFE_DELETE_ARRAY(pdGain);
		SAFE_DELETE_ARRAY(pdPhase);

		// Post DPD Plots

		CREATE_NTDIALOG_MODELESS(pPostDPD_AMAM);
		CREATE_NTDIALOG_MODELESS(pPostDPD_AMPM);
		pdMagIn = (iLength > rsPostDPDLUT.m_iLength) ? new double[iLength] : new double[rsPostDPDLUT.m_iLength];
		pdGain = (iLength > rsPostDPDLUT.m_iLength) ? new double[iLength] : new double[rsPostDPDLUT.m_iLength];
		pdPhase = (iLength > rsPostDPDLUT.m_iLength) ? new double[iLength] : new double[rsPostDPDLUT.m_iLength];

		MatlabAbs(pcdOutputOverInput, pdGain, iLength);
		MatlabPhase(pcdOutputOverInput, pdPhase, iLength);

		// Convert to gain db/phase deg
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pdMagIn[iIndex] = 10 * log10((0.5 * pow(MatlabAbs(pcdInput[iIndex]), 2.0)) / 50) + 30;
			pdGain[iIndex] = 20 * log10(pdGain[iIndex]);
			pdPhase[iIndex] = (pdPhase[iIndex] + dPhaseOffsetPostDPD) * 180 / M_PI;
			pdMagIn[iIndex] = pdMagIn[iIndex] + (pdGain[iIndex]);
			pdGain[iIndex] = -(pdGain[iIndex]);
			pdPhase[iIndex] = -pdPhase[iIndex];
		}

		// Add Rotation of phase
		RotatePhase(pdPhase, iLength);

		pPostDPD_AMAM->AddData(pdMagIn, pdGain, iLength, _T("Measurement Data"));
		pPostDPD_AMAM->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
		pPostDPD_AMPM->AddData(pdMagIn, pdPhase, iLength, _T("Measurement Data"));
		pPostDPD_AMPM->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		for(iIndex = 0; iIndex < rsPostDPDLUT.m_iLength; iIndex++)
		{
			pdMagIn[iIndex] = 10 * log10((0.5 * pow(rsPostDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdGain[iIndex] = 20 * log10(rsPostDPDLUT.m_pdGain[iIndex]);
			pdPhase[iIndex] = rsPostDPDLUT.m_pdPhase[iIndex] * 180 / M_PI;
		}

		// Add Rotation of phase
		RotatePhase(pdPhase, rsPostDPDLUT.m_iLength);

		pPostDPD_AMAM->AddData(pdMagIn, pdGain, rsPostDPDLUT.m_iLength, CString(APP_TYPE_POST_COMPENSATION_NAME) + _T(" LUT"));
		pPostDPD_AMAM->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);
		pPostDPD_AMPM->AddData(pdMagIn, pdPhase, rsPostDPDLUT.m_iLength, CString(APP_TYPE_POST_COMPENSATION_NAME) + _T(" LUT"));
		pPostDPD_AMPM->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		pPostDPD_AMAM->SetTitle(CString(APP_TYPE_POST_COMPENSATION_NAME) + _T(" Model - AM-AM"));
		pPostDPD_AMAM->SetXLabel(_T("Pin (dBm)"));
		pPostDPD_AMAM->SetYLabel(_T("Gain (dB)"));
		pPostDPD_AMAM->MyAutoFixAxis();
		pPostDPD_AMAM->ShowLegend(0);
		pPostDPD_AMPM->SetTitle(CString(APP_TYPE_POST_COMPENSATION_NAME) + _T(" Model - AM-PM"));
		pPostDPD_AMPM->SetXLabel(_T("Pin (dBm)"));
		pPostDPD_AMPM->SetYLabel(_T("Phase (deg)"));
		pPostDPD_AMPM->MyAutoFixAxis();
		pPostDPD_AMPM->ShowLegend(0);
/*		CREATE_NTDIALOG_MODELESS(pAMAMPost);
		// Mar 27/08
		// Adjusted Input Power to reflect change
		for(iIndex = 0; iIndex < iNumActualTrainedData; iIndex++)
		{
			pdXTemp[iIndex] = 10 * log10((0.5 * pow(MatlabAbs(pcdOutputTrained[iIndex]), 2.0)) / 50) + 30;
			pdYTemp[iIndex] = 20 * log10(MatlabAbs(pcdInputTrainedWithGain[iIndex]) / MatlabAbs(pcdOutputTrained[iIndex]));
		}
		pAMAMPost->AddData(pdXTemp, pdYTemp, iNumActualTrainedData, _T("Measurement Data"));
		pAMAMPost->SetDataProperties(0, 'r', 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		for(iIndex = 0; iIndex < sPostDPDLUT.m_iLength; iIndex++)
		{
			// Abs does nothing here
			pdXTemp[iIndex] = 10 * log10((0.5 * pow(sPostDPDLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdYTemp[iIndex] = 20 * log10(sPostDPDLUT.m_pdGain[iIndex]);
		}
		pAMAMPost->AddData(pdXTemp, pdYTemp, sPostDPDLUT.m_iLength, _T("LUT"));
		pAMAMPost->SetDataProperties(1, 'b', 2, CNtgraphctrl1::Solid, CNtgraphctrl1::Dots);
		pAMAMPost->SetTitle(_T("AM-AM Post"));
		pAMAMPost->SetYLabel(_T("Gain (dB)"));
		pAMAMPost->SetXLabel(_T("Pin (dBm)"));
		pAMAMPost->MyAutoFixAxis();
		pAMAMPost->ShowLegend(0);
*/

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pdMagIn);
		SAFE_DELETE_ARRAY(pdGain);
		SAFE_DELETE_ARRAY(pdPhase);
		SAFE_DELETE_ARRAY(pcdOutputOverInput);

		throw;
	}

	SAFE_DELETE_ARRAY(pdMagIn);
	SAFE_DELETE_ARRAY(pdGain);
	SAFE_DELETE_ARRAY(pdPhase);
	SAFE_DELETE_ARRAY(pcdOutputOverInput);

	return;
}
