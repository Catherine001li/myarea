/// \file ModelMemoryless.cpp
/// Implementation file for class ModelMemoryless

#include "stdafx.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "ModelMemoryless.h"
#include "..\nsmfunctions.h"
#include "..\MATLAB\MatlabFunctions.h"
#include "..\MyExceptionTrace.h"


////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for ModelMemoryless.
/// Calls base class constructor ModelFilterBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
ModelMemoryless::ModelMemoryless(void) : ModelFilterBaseClass()
{
	// Set Model Type
	m_eModelType = MODEL_LUT;
	m_csModelType = TypeNameToString(m_eModelType);
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for ModelMemoryless.
/// Implicitly calls ModelFilterBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
ModelMemoryless::~ModelMemoryless(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the Memoryless model
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/solveFilter.m"> solveFilter.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelMemoryless::RunModel()
{
	CString csLUTFilename;
	CString csPhaseOffsetFilename;
	CString csModelParamtersFilename;

	try
	{
		// Open Files
		OpenFiles();

		// Call Generate LUT
		GenerateLUT();

		// Save Parameters
		// Forcing Order to be 0
		m_iOrder = 0;
		if(m_bAppType)
		{
			csLUTFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
			csModelParamtersFilename.Format(_T("%s%s_%s_%s_%s_%s_modelParameters.nsm"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csModelType, m_csMethodType, m_csSystemType, m_csSignalType);
		}
		else
		{
			csLUTFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
			csModelParamtersFilename.Format(_T("%s%s_%s_%s_%s_%s_modelParameters.nsm"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csModelType, m_csMethodType, m_csSystemType, m_csSignalType);
		}
		csPhaseOffsetFilename.Format(_T("%s%s_%s_LinearGain.txt"), m_csFilepath, m_csSystemType, m_csSignalType);

		SaveParameters(NULL, 0, csLUTFilename, csPhaseOffsetFilename, csModelParamtersFilename);

		// Then Exit
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Runs Small Signal Gain
/// just sets variable to true so that plots don't show up
///
////////////////////////////////////////////////////////////////////////////////////
void ModelMemoryless::RunGenerateSSG()
{
	m_bSmallSignalGain = true;

	try
	{
		RunModel();
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}

#if 0

////////////////////////////////////////////////////////////////////////////////////
///
/// Sets up the output names for files
///
////////////////////////////////////////////////////////////////////////////////////
void ModelMemoryless::SetupOutputNames()
{
	CString csUS = _T("_");
//	CString csCoeff = _T("Coeff");
//	CString csTaps = _T("taps");
//	CString csOrder = _T("order");
	CString csData = _T("data");
	
	CString csMDFSuffix = _T("x.mdf");
	CString csTXTSuffix = _T("x.txt");
	CString csFilter = _T("Filter_");

	CString csLUTSuffix = m_csAppType + _T("MaginGainPhi_LUT.txt");
	CString csPhaseOffsetSuffix = _T("PA_LinearGain.txt");
	CString csModelParamSuffix = _T("modelParameters.nsm");

	//CString csIntTaps;
	//CString csIntOrder;
	//CString csTraining;
	//csIntTaps.Format(_T("%d"), m_iTaps);
	//csIntOrder.Format(_T("%d"), m_iOrder);
	//csTraining.Format(_T("%d"), m_iTraining);

	// If the end of the Filepath does not have a '\', add a '\'
	/*m_csMDFOutputFilename = m_csFilepath + m_csAppType + csFilter + m_csSystemType + csUS + _T("LSE_POLY_Model") + 
							csUS + csCoeff + csIntTaps + csTaps + csIntOrder + csOrder + 
							m_csSignalType + csData + csTraining + csMDFSuffix;

	m_csTXTOutputFilename = m_csFilepath + m_csAppType + csFilter + m_csSystemType + csUS + _T("LSE_POLY_Model") + 
							csUS + csCoeff + csIntTaps + csTaps + csIntOrder + csOrder + 
							m_csSignalType + csData + csTraining + csTXTSuffix;

*/
	m_csLUTOutputFilename = m_csFilepath + m_csSystemType + csUS + m_csSignalType + csUS + m_csAppType + csUS + csLUTSuffix;

	m_csPhaseOffsetOutputFilename = m_csFilepath + m_csSystemType + csUS + m_csSignalType + csUS + csPhaseOffsetSuffix;

	m_csModelParamOutputFilename = m_csFilepath + m_csAppType + csUS + m_csModelType + csUS + 
								   m_csMethodType + csUS + m_csSystemType + csUS + m_csSignalType + csUS +
								   csModelParamSuffix;

	/// \note calling derived class function
	ModelFilterBaseClass::SetupOutputNames();

	return;
}
#endif