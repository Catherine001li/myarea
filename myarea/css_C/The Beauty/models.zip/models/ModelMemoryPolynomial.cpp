/// \file ModelMemoryPolynomial.cpp
/// Implementation file for class ModelMemoryPolynomial

#include "stdafx.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "ModelMemoryPolynomial.h"
#include "SolverSVD.h"
#include "SolverRLS.h"
#include "SolverQRRLS.h"
#include "SolverLMS.h"
#include "ConvertToMatrix.h"
#include "..\nsmfunctions.h"
#include "..\MATLAB\MatlabFunctions.h"
#include "..\MyExceptionTrace.h"
#include "..\PlotUtility.h"


////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for ModelMemoryPolynomial.
/// Calls base class constructor ModelBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
ModelMemoryPolynomial::ModelMemoryPolynomial(void) : ModelBaseClass()
{
	// Set Model Type
	m_eModelType = MODEL_MEMORY_POLYNOMIAL;
	m_csModelType = TypeNameToString(m_eModelType);

	//?
	m_iTraining = 64;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for ModelMemoryPolynomial.
/// Implicitly calls ModelBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
ModelMemoryPolynomial::~ModelMemoryPolynomial(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the Memory Polynomial model
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/MemoryPolyLSEfunc.m"> MemoryPolyLSEfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelMemoryPolynomial::RunModel(void)
{
	int iIndex, iStartIndex;
	double dOffsetIn;
	double dOffsetOut;
	double dSmallSignalGain;
	double dPhaseOffset;
	int iMaxIndex;
	double dMaxValue, dMaxValueTemp;
	int iLengthAfterOffset;
	int iProposedLength;
	int iProposedOffset;
	
	double* pdXinI = NULL;
	double* pdXinQ = NULL;
	double* pdYinI = NULL;
	double* pdYinQ = NULL;

	doublecomplex* pcdXin = NULL;
	doublecomplex* pcdYin = NULL;

	doublecomplex* pcdAMatrix = NULL;
	doublecomplex* pcdX1 = NULL;
	doublecomplex* pcdY1 = NULL;
	doublecomplex* pcdYSim = NULL;

	SolverBaseClass* pSolverBaseClass = NULL;
	int iNumRows;
	int iNumCols;
	doublecomplex* pcdCoeffs = NULL;

	double dNMSE;
	double dNMSEdB;
	double dVar;
	double dVardB;
	double dPAR;
	double dPARdB;

	PlotUtility cPlot;
	MODEL_PARAMS sModelParams;
	ConvertToMatrix cConvertMatrix;


	CString csCoeffFilenameADS;
	CString csCoeffFilenameTXT;
	CString csFilterType;
	CString csLUTFilename;
	CString csPhaseOffsetFilename;
	CString csModelParametersFilename;

	// Setup Output Names
	if(m_bAppType)	// DPD
		csFilterType.Format(_T("%s_%s"), APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType);
	else
		csFilterType.Format(_T("%s_%s"), APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType);

	csCoeffFilenameADS.Format(_T("%s%s_%s_Coeff%dtaps%dorder%sdata%dx.mdf"),
								m_csFilepath, csFilterType, m_csModelType, 
								m_iTaps, m_iOrder, m_csSignalType,
								m_iTraining);
	csCoeffFilenameTXT.Format(_T("%s%s_%s_Coeff%dtaps%dorder%sdata%dx.txt"),
								m_csFilepath, csFilterType, m_csModelType, 
								m_iTaps, m_iOrder, m_csSignalType,
								m_iTraining);


	// Open the Files. If failed, exit.
	try
	{
		OpenFiles();

		// Remove the first 1000 data points (instead of removing right away, compute later)
		iStartIndex = 1000;

		// Compute magnitude of offset in/out
		dOffsetIn = pow(10.0, m_dInputAttenuation / 20.0);
		dOffsetOut = pow(10.0, m_dOutputAttenuation / 20.0);

		
		// Read in small signal gain parameters if DPD is selected
		if(m_bAppType)
		{
			GetSmallSignalParameters(&dSmallSignalGain, &dPhaseOffset);
		}
		else
		{
			dSmallSignalGain = 1.0;
			dPhaseOffset = 0.0;
		}
		
		// Compute number of measurement points?
		// Taking the maximum value into account...
		iLengthAfterOffset = m_iLength - iStartIndex;

		iMaxIndex = iStartIndex;
		dMaxValue = sqrt(pow(m_pdOutputI[iMaxIndex], 2.0) + pow(m_pdOutputQ[iMaxIndex], 2.0));
		for(iIndex = iStartIndex + 1; iIndex < m_iLength; iIndex++)
		{
			dMaxValueTemp = sqrt(pow(m_pdOutputI[iIndex], 2.0) + pow(m_pdOutputQ[iIndex], 2.0));
			if(dMaxValueTemp > dMaxValue)
			{
				dMaxValue = dMaxValueTemp;
				iMaxIndex = iIndex;
			}
		}
		
		iProposedLength = m_iTraining * 128;
		if((iMaxIndex - iStartIndex) > (iProposedLength / 2))
		{
			iProposedOffset = (iMaxIndex - iStartIndex) - (iProposedLength / 2);
			if((iLengthAfterOffset - iProposedOffset) < iProposedLength)
			{
				iProposedOffset = iLengthAfterOffset - iProposedLength;
			}
		}
		else
		{
			iProposedOffset = 0;
		}

		iProposedOffset = iProposedOffset + iStartIndex;

		// Now, Create new vectors for solving matrix.
		pdXinI = new double[iProposedLength];
		pdXinQ = new double[iProposedLength];
		pdYinI = new double[iProposedLength];
		pdYinQ = new double[iProposedLength];



		// This should not fail, unless initally our vectors are less than m_iTraining * 128
		for(iIndex = iProposedOffset; iIndex < iProposedOffset + iProposedLength; iIndex++)
		{
			// Offset In
			pdXinI[iIndex - iProposedOffset] = m_pdInputI[iIndex] / dOffsetIn;
			pdXinQ[iIndex - iProposedOffset] = m_pdInputQ[iIndex] / dOffsetIn;


			// Offset Out (with small signal gain)
			pdYinI[iIndex - iProposedOffset] = m_pdOutputI[iIndex] * dOffsetOut / dSmallSignalGain;
			pdYinQ[iIndex - iProposedOffset] = m_pdOutputQ[iIndex] * dOffsetOut / dSmallSignalGain;
		}

		
		// in matlab, prints out maximum of x_in and y_in...
		

		// For reverse models, swap x and y...
		if(m_bAppType == true)
		{
			double* pdTempI = pdXinI;
			double* pdTempQ = pdXinQ;
			pdXinI = pdYinI;
			pdXinQ = pdYinQ;
			pdYinI = pdTempI;
			pdYinQ = pdTempQ;
		}

		// Convert to matrix
		//iNumRows = (iProposedLength - (m_iTaps - 1));
		//iNumCols = m_iTaps * (m_iOrder+1);
		
		pcdXin = new doublecomplex[iProposedLength];
		pcdYin = new doublecomplex[iProposedLength];
		for(iIndex = 0; iIndex < iProposedLength; iIndex++)
		{
			pcdXin[iIndex].r = pdXinI[iIndex];
			pcdXin[iIndex].i = pdXinQ[iIndex];
			pcdYin[iIndex].r = pdYinI[iIndex];
			pcdYin[iIndex].i = pdYinQ[iIndex];
		}

		cConvertMatrix.SetInputX(pcdXin, iProposedLength);
		cConvertMatrix.SetOutputY(pcdYin, iProposedLength);
		cConvertMatrix.SetParameters(m_iTaps, m_iOrder, CONVERSION_POLYSEA1);
		cConvertMatrix.Run();
		pcdAMatrix = cConvertMatrix.GetResultAMatrix(&iNumRows, &iNumCols);
		pcdX1 = cConvertMatrix.GetResultX();
		pcdY1 = cConvertMatrix.GetResultY();
		//pcdAMatrix = new doublecomplex[iNumCols * iNumRows];
		//pcdX1 = new doublecomplex[iNumRows];
		//pcdY1 = new doublecomplex[iNumRows];

		//GenerateMatrix(pdXinI, pdXinQ, pdYinI, pdYinQ, iProposedLength, pcdAMatrix, pcdX1, pcdY1);


		// Case Statement for switching.
		switch(m_eMethodType)
		{
			case METHOD_SVD:
				pSolverBaseClass = new SolverSVD;
				break;
			case METHOD_QRRLS:
				pSolverBaseClass = new SolverQRRLS;
				break;
			case METHOD_RLS:
				pSolverBaseClass = new SolverRLS;
				break;
			case METHOD_LMS:
				pSolverBaseClass = new SolverLMS;
				break;
			default:
				AfxMessageBox(_T("Invalid Method Type, exiting..."));
				AfxThrowUserException();
		}

		pcdCoeffs = new doublecomplex[iNumCols];

		pSolverBaseClass->SetAMatrixParameters((double*) pcdAMatrix, iNumRows, iNumCols, true);
		pSolverBaseClass->SetOtherMatrixParameters((double*) pcdY1, (double*) pcdCoeffs);
		pSolverBaseClass->SetAdditionalParameters(m_dDelta, m_dLambda, m_dMu);
		pSolverBaseClass->SolveMatrix();

		// Save the model parameters to a '.mat' file
		if(m_bAppType)
			csLUTFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		else
			csLUTFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
		csPhaseOffsetFilename.Format(_T("%s%s_%s_LinearGain.txt"), m_csFilepath, m_csSystemType, m_csSignalType);
		csModelParametersFilename.Format(_T("%s%s_%s_%s_%s_%s_%dtap%dordermodelParameters.nsm"), m_csFilepath, m_csAppType, _T("Multi-branch Polynomial"), m_csMethodType, m_csSystemType, m_csSignalType, m_iTaps, m_iOrder);
		SaveParameters(pcdCoeffs, iNumCols, csLUTFilename, csPhaseOffsetFilename, csModelParametersFilename);


		// Recreate output by multiplying the 'A' matrix with the coefficients.
		pcdYSim = new doublecomplex[iNumRows];
		MatrixMultiply(pcdAMatrix, iNumRows, iNumCols, pcdCoeffs, 1, pcdYSim);
		NMSEdBVarFunc(pcdYSim, pcdY1, iNumRows, &dNMSE, &dNMSEdB, &dVar, &dVardB, &dPAR, &dPARdB);
		
		// Mar 27/08
		// Commented out LUT
		//CreateLUTMemoryPolynomial(pcdX1, iNumRows, pcdCoeffs, iNumCols);

		// Save Polynomial Coefficients
		SavePolynomialCoefficients(pcdCoeffs, iNumCols, csCoeffFilenameADS, csCoeffFilenameTXT);

		/// \note verify with display filter training results....
		cPlot.SetInputs(pcdX1, pcdY1, pcdYSim, iNumRows);
		
		////////////////////////////////////
		sModelParams.m_csAppType = m_csAppType;
		sModelParams.m_csLUTFilename = csLUTFilename;
		sModelParams.m_csPhaseOffsetFilename = csPhaseOffsetFilename;
		sModelParams.m_csPAType = m_csSystemType;
		sModelParams.m_csSignalType = m_csSignalType;
		sModelParams.m_dInputAttenuation = m_dInputAttenuation;
		sModelParams.m_dOutputAttenuation = m_dOutputAttenuation;
		sModelParams.m_eMethod = m_eMethodType;
		sModelParams.m_iTaps = m_iTaps;
		sModelParams.m_iOrder = m_iOrder;
		sModelParams.m_eModel = m_eModelType;
		sModelParams.m_iCoeffLength = iNumCols;

		sModelParams.m_pcdCoeff = new doublecomplex[iNumCols];

		for(iIndex = 0; iIndex < iNumCols; iIndex++)
		{
			sModelParams.m_pcdCoeff[iIndex].r = pcdCoeffs[iIndex].r;
			sModelParams.m_pcdCoeff[iIndex].i = pcdCoeffs[iIndex].i;
		}

		/////////////////////////////////////
		cPlot.SetModelParameters(sModelParams);
		cPlot.SetSpectrumParameters(m_sSpectrumParams);
		cPlot.DisplayFilterTrainingResults();


		delete [] sModelParams.m_pcdCoeff;
	}
/*	catch(CFileException* pEx)
	{
		bError = true;
	}
	catch(CMemoryException* pEx)
	{
		MESSAGEBOX_MEMORYEXCEPTION;
		bError = true;
	}
*/
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE(pSolverBaseClass);
		SAFE_DELETE_ARRAY(pcdYSim);
		SAFE_DELETE_ARRAY(pcdAMatrix);
		SAFE_DELETE_ARRAY(pcdCoeffs);
		SAFE_DELETE_ARRAY(pcdX1);
		SAFE_DELETE_ARRAY(pcdY1);
		SAFE_DELETE_ARRAY(pdXinI);
		SAFE_DELETE_ARRAY(pdXinQ);
		SAFE_DELETE_ARRAY(pdYinI);
		SAFE_DELETE_ARRAY(pdYinQ);
		SAFE_DELETE_ARRAY(pcdXin);
		SAFE_DELETE_ARRAY(pcdYin);

		throw;
	}
	
	// Free Allocated Variables
	SAFE_DELETE(pSolverBaseClass);
	SAFE_DELETE_ARRAY(pcdYSim);
	SAFE_DELETE_ARRAY(pcdAMatrix);
	SAFE_DELETE_ARRAY(pcdCoeffs);
	SAFE_DELETE_ARRAY(pcdX1);
	SAFE_DELETE_ARRAY(pcdY1);
	SAFE_DELETE_ARRAY(pdXinI);
	SAFE_DELETE_ARRAY(pdXinQ);
	SAFE_DELETE_ARRAY(pdYinI);
	SAFE_DELETE_ARRAY(pdYinQ);
	SAFE_DELETE_ARRAY(pcdXin);
	SAFE_DELETE_ARRAY(pcdYin);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets up the Output Filenames (unfinished), may move to X if consistent with all other files
///
////////////////////////////////////////////////////////////////////////////////////
/*void ModelMemoryPolynomial::SetupOutputNames(void)
{
	CString csUS = _T("_");
	CString csCoeff = _T("Coeff");
	CString csTaps = _T("taps");
	CString csOrder = _T("order");
	CString csData = _T("data");
	
	CString csMDFSuffix = _T("x.mdf");
	CString csTXTSuffix = _T("x.txt");
	CString csFilter = _T("Filter_");

	CString csLUTSuffix = m_csAppType + _T("MaginGainPhi_LUT.txt");
	CString csPhaseOffsetSuffix = _T("PA_LinearGain.txt");
	CString csModelParamSuffix = _T("modelParameters.nsm");

	CString csIntTaps;
	CString csIntOrder;
	CString csTraining;
	csIntTaps.Format(_T("%d"), m_iTaps);
	csIntOrder.Format(_T("%d"), m_iOrder);
	csTraining.Format(_T("%d"), m_iTraining);

	// If the end of the Filepath does not have a '\', add a '\'
	m_csMDFOutputFilename = m_csFilepath + m_csAppType + csFilter + m_csSystemType + csUS + _T("LSE_POLY_Model") + 
							csUS + csCoeff + csIntTaps + csTaps + csIntOrder + csOrder + 
							m_csSignalType + csData + csTraining + csMDFSuffix;

	m_csTXTOutputFilename = m_csFilepath + m_csAppType + csFilter + m_csSystemType + csUS + _T("LSE_POLY_Model") + 
							csUS + csCoeff + csIntTaps + csTaps + csIntOrder + csOrder + 
							m_csSignalType + csData + csTraining + csTXTSuffix;


	m_csLUTOutputFilename = m_csFilepath + m_csSystemType + csUS + m_csSignalType + csUS + csLUTSuffix;

	m_csPhaseOffsetOutputFilename = m_csFilepath + m_csSystemType + csUS + m_csSignalType + csUS + csPhaseOffsetSuffix;

	m_csModelParamOutputFilename = m_csFilepath + m_csAppType + csUS + _T("Multi-branch Polynomial") + csUS + 
								   m_csMethodType + csUS + m_csSystemType + csUS + m_csSignalType + csUS +
								   csIntTaps + csTaps + csIntOrder + csOrder + csModelParamSuffix;
							 

	return;
}
*/
#if 0
////////////////////////////////////////////////////////////////////////////////////
///
/// Converts the matrix to Multi-branch Polynomial format
///
/// \param pdXinI input inphase component
/// \param pdXinQ input quadraturephase component
/// \param pdYinI output inphase component
/// \param pdYinQ output quadraturephase component
/// \param iLength length of signals
/// \param [out] pcdA preallocated matrix \f$A\f$
/// \param [out] pcdX1 preallocated vector, inputs used for generating \f$A\f$
/// \param [out] pcdY1 preallocated vector, desired output \f$b\f$
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/Global/convert2_POLYLSEA1_Matrix.m"> convert2_POLYLSEA1_Matrix.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelMemoryPolynomial::GenerateMatrix(double* pdXinI, double* pdXinQ, double* pdYinI, double* pdYinQ, int iLength, doublecomplex* pcdA, doublecomplex* pcdX1, doublecomplex* pcdY1)
{
	int iWIndex;
	int iInIndex;

	// Generate 'A' matrix
	GenerateMatrixA(pdXinI, pdXinQ, iLength, m_iTaps, m_iOrder, false, pcdA);
/*	for(iTimeIndex = 0; iTimeIndex < (iLength - m_iTaps + 1); iTimeIndex++)
	{
		for(iTapIndex = 0; iTapIndex < m_iTaps; iTapIndex++)
		{
			// Current value to compute
			iInIndex = (iLength - 1) - iTapIndex - iTimeIndex;

			for(iOrderIndex = 0; iOrderIndex <= m_iOrder; iOrderIndex++)
			{
				// Compute Matrix Offset
				iAMatrixIndex = iTimeIndex * (m_iTaps * (m_iOrder + 1)) + iTapIndex * (m_iOrder + 1) + iOrderIndex;

				// Compute Order
				dTemp = sqrt(pow(pdXinI[iInIndex], 2) + pow(pdXinQ[iInIndex], 2));
				dTemp = pow(dTemp, iOrderIndex);

				pcdA[iAMatrixIndex].r = pdXinI[iInIndex] * dTemp;
				pcdA[iAMatrixIndex].i = pdXinQ[iInIndex] * dTemp;
			}
		}
	}
*/
	// Generate y1/x1
	for(iWIndex = 0; iWIndex < (iLength - m_iTaps + 1); iWIndex++)
	{
		iInIndex = (iLength - 1) - iWIndex;
		pcdX1[iWIndex].r = pdXinI[iInIndex];
		pcdX1[iWIndex].i = pdXinQ[iInIndex];
		pcdY1[iWIndex].r = pdYinI[iInIndex];
		pcdY1[iWIndex].i = pdYinQ[iInIndex];
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Generates the 'A' Matrix, specified by Taps, Order, etc.
///
/// \param pdXinI input inphase component
/// \param pdXinQ input quadraturephase component
/// \param iLength length of signals
/// \param iTaps number of taps
/// \param iOrder order number
/// \param bDoubleComplex true if the I/Q are interleaved from pdXinI point of view (used if doublecomplex is used). false if pdXinI/pdXinQ contains sequential data.
/// \param [out] pcdA preallocated matrix \f$A\f$
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/Global/convert2_POLYLSEA1_Matrix.m"> convert2_POLYLSEA1_Matrix.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelMemoryPolynomial::GenerateMatrixA(double* pdXinI, double* pdXinQ, int iLength, int iTaps, int iOrder, bool bDoubleComplex, doublecomplex* pcdA)
{
	int iIndexI, iIndexQ;
	int iAdjustOffset = 1;
	int iTapIndex, iOrderIndex, iTimeIndex;
	int iAMatrixIndex;
	int iInIndex;
	double dTemp;

	// Account for a 'doublecomplex' variable
	if(bDoubleComplex)
	{
		iAdjustOffset = 2;
	}

	// Start Iteration
	for(iTimeIndex = 0; iTimeIndex < (iLength - (iTaps - 1)); iTimeIndex++)
	{
		for(iTapIndex = 0; iTapIndex < iTaps; iTapIndex++)
		{
			// Current value to compute
			// If the pointers are pointing to doublecomplex, must adjust offsets by 2.
			iInIndex = ((iLength - 1) - iTapIndex - iTimeIndex) * iAdjustOffset;

			for(iOrderIndex = 0; iOrderIndex < (iOrder + 1); iOrderIndex++)
			{
				// Compute Matrix Offset
				iAMatrixIndex = iTimeIndex * (iTaps * (iOrder + 1)) + iTapIndex * (iOrder + 1) + iOrderIndex;

				// Compute Order
				dTemp = sqrt(pow(pdXinI[iInIndex], 2) + pow(pdXinQ[iInIndex], 2));
				dTemp = pow(dTemp, iOrderIndex);

				pcdA[iAMatrixIndex].r = pdXinI[iInIndex] * dTemp;
				pcdA[iAMatrixIndex].i = pdXinQ[iInIndex] * dTemp;
			}
		}
	}

	return;
}
#endif

////////////////////////////////////////////////////////////////////////////////////
///
/// Creates the LUT and writes to a file
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/createMultiLUT4MemoryPolynomial.m"> createMultiLUT4MemoryPolynomial.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelMemoryPolynomial::CreateLUTMemoryPolynomial(doublecomplex* pcdXin, int iRows, doublecomplex* pcdCoeffs, int iCols)
{
	CString csFilename;
	CString csLUTFileHeader;
	int iIndex, iTapIndex;

	double* pdMagIn = NULL;
	doublecomplex* pcdA = NULL;
	doublecomplex* pcdOut = NULL;
	doublecomplex* pcdGainTmp = NULL;
	double* pdGain = NULL;
	double* pdPhaseTmp = NULL;
	double* pdPhase = NULL;
	double* pdMagInLUT = NULL;
	double* pdGainLUT = NULL;
	double* pdPhaseLUT = NULL;
	double* pdOffsetLUT = NULL;
	ConvertToMatrix cConvertMatrix;

	// Create Filename (move somewhere else), just a prefix.
	csFilename = m_csFilepath + m_csSystemType + _T("_") + m_csSignalType + _T("_MPoly");

	// Create 'A' Matrix with tap size of '1'
	//pcdA = new doublecomplex[iRows * (m_iOrder + 1)];
	//GenerateMatrixA((double*) &pcdXin[0].r, (double*) &pcdXin[0].i, iRows, 1, m_iOrder, true, pcdA);
	cConvertMatrix.SetInputX(pcdXin, iRows);
	cConvertMatrix.SetParameters(1, m_iOrder, CONVERSION_POLYSEA1);
	cConvertMatrix.Run();
	pcdA = cConvertMatrix.GetResultAMatrix();

	// Compute magnitude
	// (should this be squared or not...), BBDPD is.
	pdMagIn = new double[iRows];
	MatlabAbs(pcdXin, pdMagIn, iRows);

	// Preallocate Temporary Vectors
	pcdOut = new doublecomplex[iRows];
	pcdGainTmp = new doublecomplex[iRows];
	pdGain = new double[iRows];
	pdPhaseTmp = new double[iRows];
	pdPhase = new double[iRows];

	pdMagInLUT = new double[m_iLUTSize];
	pdGainLUT = new double[m_iLUTSize];
	pdPhaseLUT = new double[m_iLUTSize];
	
	pdOffsetLUT = new double[1];

	// In the MATLAB file, there are many variables being created and not used (mostly saving
	// all TapIndex gain, phase, etc.). Did not do this to save space and computation time.

	// For length of taps...
	for(iTapIndex = 0; iTapIndex < m_iTaps; iTapIndex++)
	{
		// Extract the current tap coefficients
		int iK = (iTapIndex) * (m_iOrder + 1);

		// Output of the ith branch.
		// Get the ith branch coefficients, and multiply with the 'A'
		MatrixMultiply(pcdA, iRows, m_iOrder + 1, &pcdCoeffs[iK], 1, pcdOut);

		// Compute gain
		// GainTmp = pcdOut ./ pcdXin
		VectorDivide(pcdOut, pcdXin, iRows, pcdGainTmp);

		MatlabAbs(pcdGainTmp, pdGain, iRows);

		// Compute Phase
		MatlabPhase(pcdGainTmp, pdPhaseTmp, iRows);
		MatlabUnwrap(pdPhaseTmp, pdPhase, iRows);

		// Create LUT with single branch
		MakeLUTWithPoly(pdMagIn, pdGain, pdPhase, iRows, pdMagInLUT, pdGainLUT, pdPhaseLUT, pdOffsetLUT);
	
		// Save LUT Results.
		// Format LUT File Header
		csLUTFileHeader.Format(_T("%s_multiLUT_%d"), csFilename, (iTapIndex + 1));
		
		SaveLUTResults(pdMagInLUT, pdGainLUT, pdPhaseLUT, m_iLUTSize, csLUTFileHeader, m_dLUTTruncate);

		// Plot the LUT curves (not needed).
	}

	SAFE_DELETE_ARRAY(pdOffsetLUT);
	SAFE_DELETE_ARRAY(pdMagInLUT);
	SAFE_DELETE_ARRAY(pdGainLUT);
	SAFE_DELETE_ARRAY(pdPhaseLUT);
	SAFE_DELETE_ARRAY(pdPhase);
	SAFE_DELETE_ARRAY(pdPhaseTmp);
	SAFE_DELETE_ARRAY(pdMagIn);
	SAFE_DELETE_ARRAY(pcdA);
	SAFE_DELETE_ARRAY(pcdOut);
	SAFE_DELETE_ARRAY(pcdGainTmp);
	SAFE_DELETE_ARRAY(pdGain);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Saves the current LUT branch to three files.
/// - csFileHeader + _MaginGainPhi_LUTNew.txt
///   - contains the original pdMagIn, pdGain, and pdPhase data
/// - csFileHeader + _LUT_GainOffsetNew.mdf
///   - contains the reference gain and phase offsets for the following file
/// - csFileHeader + _MaginGainPhi_LUT_adsNew.txt
///   - contains the relative pdMagIn, pdGain, and pdPhase data (with information in the .mdf file)
///
/// \param pdMagIn input magnitude (x-axis)
/// \param pdGain gain (y-axis 1)
/// \param pdPhase phase (y-axis 2)
/// \param iLength length of the LUT (suppose to be base 2)
/// \param csFileHeader the file prefix
/// \param dPinCutTh the input power cutoff threshold (in dBm)
///
////////////////////////////////////////////////////////////////////////////////////
void ModelMemoryPolynomial::SaveLUTResults(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, CString csFileHeader, double dPinCutTh)
{
	CStdioFile cfOutput;
	CString csFilename;
	CString csLine;
	int iIndex;
	int iCutIndex;

	double* pdMagIndB = NULL;
	double* pdGaindB = NULL;
	double* pdPhi = NULL;

	double dGainOffset;
	double dPhaseOffset;

	// Append file suffix
	csFilename = csFileHeader + _T("_MaginGainPhi_LUTNew.txt");

	// Open file
	cfOutput.Open(csFilename, CFile::modeCreate | CFile::modeWrite);

	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		csLine.Format(_T("%8.10f    %8.10f    %8.10f"), pdMagIn[iIndex], pdGain[iIndex], pdPhase[iIndex]);
		cfOutput.WriteString(csLine + _T("\n"));
	}
	cfOutput.Close();

	// Convert to dB values...
	pdMagIndB = new double[iLength];
	pdGaindB = new double[iLength];
	pdPhi = new double[iLength];
	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		pdMagIndB[iIndex] = 10 * log10((0.5 * pow(pdMagIn[iIndex], 2)) / 50) + 30;
		pdGaindB[iIndex] = 20 * log10(pdGain[iIndex]);
		pdPhi[iIndex] = pdPhase[iIndex];
	}

	// Figure out cut index...
	// This should be == 0, since we already used the cut index in a previous function
	iCutIndex = 0;
	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		if(pdMagIndB[iIndex] >= dPinCutTh)
		{
			iCutIndex = iIndex;
			break;
		}
	}

	dGainOffset = pdGaindB[iCutIndex];
	dPhaseOffset = pdPhase[iCutIndex];

	// Truncate values.  ADS uses relative values.
	for(iIndex = iCutIndex; iIndex < iLength; iIndex++)
	{
		pdMagIndB[iIndex - iCutIndex] = pdMagIndB[iIndex];
		pdGaindB[iIndex - iCutIndex] = pdGaindB[iIndex] - dGainOffset;
		pdPhi[iIndex - iCutIndex] = pdPhase[iIndex] - dPhaseOffset;
	}

	// Save the gain and phase start point values in a .mdf file
	csFilename = csFileHeader + _T("_LUT_GainOffsetNew.mdf");
	cfOutput.Open(csFilename, CFile::modeCreate | CFile::modeWrite);

	cfOutput.WriteString(_T("BEGIN DSCRDATA\n"));
	cfOutput.WriteString(_T("%%INDEX     GainOffset      PhaseOffset\n0"));
	csLine.Format(_T("        %2.14f        %2.14f"), dGainOffset, dPhaseOffset * 180 / M_PI);
	cfOutput.WriteString(csLine);
	cfOutput.WriteString(_T("\nEND"));
	
	cfOutput.Close();

	/*for(iIndex = 0; iIndex < (iLength - iCutIndex); iIndex++)
	{
		csLine.Format(_T("        %2.14f        %2.14f"), pdGaindB

	}*/

	// Save the LUT in ADS GainRF file format.
	csFilename = csFileHeader + _T("_MaginGainPhi_LUT_adsNew.txt");
	cfOutput.Open(csFilename, CFile::modeCreate | CFile::modeWrite);

	cfOutput.WriteString(_T("-100.0    0.0    0.0\n"));

	for(iIndex = 1; iIndex < (iLength - iCutIndex); iIndex++)
	{
		csLine.Format(_T("%8.10f    %8.10f    %8.10f \n"), pdMagIndB[iIndex], pdGaindB[iIndex], pdPhi[iIndex] * 180 / M_PI);
		cfOutput.WriteString(csLine);
	}

	cfOutput.Close();

	SAFE_DELETE_ARRAY(pdPhi);
	SAFE_DELETE_ARRAY(pdMagIndB);
	SAFE_DELETE_ARRAY(pdGaindB);

	return;
}


