/// \file ModelBaseClass.cpp
/// Implementation file for base class for models

#include "stdafx.h"
#include <math.h>
#include "ModelBaseClass.h"
#include <stdio.h>
#include <stdlib.h>
#include "..\global.h"
#include "..\nsmfunctions.h"
#include "..\ModelParametersArchive.h"
#include "..\MATLAB\MatlabFunctions.h"
#include "..\MyExceptionTrace.h"

////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for ModelBaseClass.
/// Only initializes primitive variables
///
////////////////////////////////////////////////////////////////////////////////////
ModelBaseClass::ModelBaseClass(void)
{
	m_bInputIQ = false;
	m_bOutputIQ = false;
	m_eMethodType = METHOD_SVD;
	m_dInputAttenuation = 0.0;
	m_dOutputAttenuation = 0.0;
	
	m_iTaps = 0;
	m_iOrder = 0;

	m_dDelta = 0.0;
	m_dLambda = 0.0;
	m_dMu = 0.0;

	m_dLUTTruncate = 0.0;
	m_iLUTSize = 0;

	m_bAppType = false;

	m_pdInputI = NULL;
	m_pdInputQ = NULL;
	m_pdOutputI = NULL;
	m_pdOutputQ = NULL;
	m_iLength = 0;

	m_iExtractLUT = 0;
	m_iExtractFilter = 0;
	m_iFilterIdentification = 0;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for ModelBaseClass.
/// Frees preallocated memory
///
////////////////////////////////////////////////////////////////////////////////////
ModelBaseClass::~ModelBaseClass(void)
{
	if(m_pdInputI != NULL)
	{
		delete [] m_pdInputI;
		m_pdInputI = NULL;
	}
	if(m_pdInputQ != NULL)
	{
		delete [] m_pdInputQ;
		m_pdInputQ = NULL;
	}
	if(m_pdOutputI != NULL)
	{
		delete [] m_pdOutputI;
		m_pdOutputI = NULL;
	}
	if(m_pdOutputQ != NULL)
	{
		delete [] m_pdOutputQ;
		m_pdOutputQ = NULL;
	}

}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the class member variables to the input filenames
///
/// \param csFilenameInI input filename string for input I vector (or input I/Q vector)
/// \param csFilenameInQ input filename string for input Q vector (optional)
/// \param bInputIQ flag to tell if input I/Q vectors are in the same file
/// \param csFilenameOutI output filename string for output I vector (or output I/Q vector)
/// \param csFilenameOutQ output filename string for output Q vector (optional)
/// \param bOutputIQ flag to tell if output I/Q vectors are in the same file
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetInputFiles(CString csFilenameInI, CString csFilenameInQ, BOOL bInputIQ, CString csFilenameOutI, CString csFilenameOutQ, BOOL bOutputIQ)
{
	// Inputs
	m_csFilenameInI = csFilenameInI;
	m_bInputIQ = bInputIQ;
	if(bInputIQ)
	{
		m_csFilenameInQ = "";
	}
	else
	{
		m_csFilenameInQ = csFilenameInQ;
	}
	
	// Outputs
	m_csFilenameOutI = csFilenameOutI;
	m_bOutputIQ = bOutputIQ;
	if(bOutputIQ)
	{
		m_csFilenameOutQ = "";
	}
	else
	{
		m_csFilenameOutQ = csFilenameOutQ;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the class member variable to the input filepath
///
/// \param csFilepath output path for data storage
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetFilepath(CString csFilepath)
{
	m_csFilepath = csFilepath;

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the solver variables (method type, and DPD
///
/// \param eMethodType method type (svd, rls,...)
/// \param bAppType false to compute forward model, true to compute reverse model
/// \param iTaps number of taps
/// \param iOrder order of algorithm
/// \param eFilterType filter type (fir, iir)
/// \param dDelta regularization parameter for QR-RLS/RLS
/// \param dLambda regression parameter for QR-RLS/RLS
/// \param dMu training parameter for LMS
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetSolverSettings(METHOD_TYPE eMethodType, bool bAppType, int iTaps, int iOrder, FILTER_TYPE eFilterType, double dDelta, double dLambda, double dMu)
{
	m_eMethodType = eMethodType;
	m_bAppType = bAppType;
	m_iTaps = iTaps;
	m_iOrder = iOrder;
	m_eFilterType = eFilterType;
	m_dDelta = dDelta;
	m_dLambda = dLambda;
	m_dMu = dMu;

	m_csMethodType = TypeNameToString(m_eMethodType);
	m_csFilterType = TypeNameToString(m_eFilterType);
	m_csAppType = TypeNameToString(m_bAppType);
	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the Power Amplifier attenuation settings
///
/// \param dInputAttenuation input attenuation
/// \param dOutputAttenuation output attenuation
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetAttenuationSettings(double dInputAttenuation, double dOutputAttenuation)
{
	m_dInputAttenuation = dInputAttenuation;
	m_dOutputAttenuation = dOutputAttenuation;

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the type names (system type, and signal type)
///
/// \param csSystemType name of the system
/// \param csSignalType name of the signal
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetTypeNames(CString csSystemType, CString csSignalType)
{
	m_csSystemType = csSystemType;
	m_csSignalType = csSignalType;

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the type names (system type, and signal type)
///
/// \param eLUTAlgorithm type of LUT algorithm
/// \param dLUTTruncate level to truncate LUT
/// \param iLUTSize size of LUT
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetLUTSettings(LUT_ALGORITHM eLUTAlgorithm, double dLUTTruncate, int iLUTSize)
{
	m_eLUTAlgorithm = eLUTAlgorithm;
	m_dLUTTruncate = dLUTTruncate;
	m_iLUTSize = iLUTSize;

	m_csLUTAlgorithm = TypeNameToString(m_eLUTAlgorithm);
	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Opens the files, and allocates memory for them.
///
/// \return true if successful in opening all files, false otherwise
///
////////////////////////////////////////////////////////////////////////////////////
bool ModelBaseClass::OpenFiles()
{
	CFile cfTest;
	int iNumValuesInI, iNumValuesInQ;
	int iNumValuesOutI, iNumValuesOutQ;
	double* pdInputI;
	double* pdInputQ;
	double* pdOutputI;
	double* pdOutputQ;
	CFileException ex;
	TCHAR error[1024];
	
	// Try opening files
	try
	{
		// Validate Files
		// Input I
		if(!cfTest.Open(m_csFilenameInI, CFile::readOnly, &ex))
		{
			//ex.GetErrorMessage(error, 1024);
			EXCEPTION_ADDUSERMESSAGE(_T("Error Reading Input I File\n"));
			//AfxMessageBox(CString(_T("Error Reading Input I File: ")) + CString(error));
			AfxThrowFileException(ex.m_cause);
		}
		cfTest.Close();


		// If I/Q are in separate files, check Q
		if(m_bInputIQ == BST_UNCHECKED)
		{
			// Input Q
			if(!cfTest.Open(m_csFilenameInQ, CFile::readOnly, &ex))
			{
				//ex.GetErrorMessage(error, 1024);
				EXCEPTION_ADDUSERMESSAGE(_T("Error Reading Input Q File\n"));
				//AfxMessageBox(CString(_T("Error Reading Input I File: ")) + CString(error));
				AfxThrowFileException(ex.m_cause);
			}
			cfTest.Close();
		}

		// Output I
		if(!cfTest.Open(m_csFilenameOutI, CFile::readOnly, &ex))
		{
			//ex.GetErrorMessage(error, 1024);
			EXCEPTION_ADDUSERMESSAGE(_T("Error Reading Output I File\n"));
			//AfxMessageBox(CString(_T("Error Reading Input I File: ")) + CString(error));
			AfxThrowFileException(ex.m_cause);
		}
		cfTest.Close();

		// If I/Q are in separate files, check Q
		if(m_bOutputIQ == BST_UNCHECKED)
		{
			// Output Q
			if(!cfTest.Open(m_csFilenameOutQ, CFile::readOnly))
			{
				//ex.GetErrorMessage(error, 1024);
				EXCEPTION_ADDUSERMESSAGE(_T("Error Reading Output Q File\n"));
				//AfxMessageBox(CString(_T("Error Reading Input I File: ")) + CString(error));
				AfxThrowFileException(ex.m_cause);
			}
			cfTest.Close();
		}	


		// Read in the data using the prebuilt function
		// Read Input Values
		if(m_bInputIQ  == BST_UNCHECKED)
		{
			iNumValuesInI = GetNumDataInTxtFile(FALSE, m_csFilenameInI);
			iNumValuesInQ = GetNumDataInTxtFile(FALSE, m_csFilenameInQ);

			if(iNumValuesInI != iNumValuesInQ)
			{
				AfxMessageBox(_T("Warning: Input I/Q Files do not have same values, taking smallest of two"));
				if(iNumValuesInI < iNumValuesInQ)
					iNumValuesInQ = iNumValuesInI;
				else
					iNumValuesInI = iNumValuesInQ;
			}

			// Cap values, running out of memory
			if(iNumValuesInI > EXTRACT_MODEL_MAX_MEMORY_LENGTH)
			{
				iNumValuesInI = EXTRACT_MODEL_MAX_MEMORY_LENGTH;
				iNumValuesInQ = EXTRACT_MODEL_MAX_MEMORY_LENGTH;
			}


			pdInputI = new double[iNumValuesInI];
			pdInputQ = new double[iNumValuesInQ];

			ReadDataFromTxtFile(pdInputI, iNumValuesInI, m_csFilenameInI);
			ReadDataFromTxtFile(pdInputQ, iNumValuesInQ, m_csFilenameInQ);
		}
		else
		{
			iNumValuesInI = GetNumDataInTxtFile(TRUE, m_csFilenameInI);

			// Cap values, running out of memory
			if(iNumValuesInI > EXTRACT_MODEL_MAX_MEMORY_LENGTH)
			{
				iNumValuesInI = EXTRACT_MODEL_MAX_MEMORY_LENGTH;
				iNumValuesInQ = EXTRACT_MODEL_MAX_MEMORY_LENGTH;
			}

			pdInputI = new double[iNumValuesInI];
			pdInputQ = new double[iNumValuesInI];

			ReadDataFromTxtFile(pdInputI, pdInputQ, iNumValuesInI, m_csFilenameInI);
		}
		
		// Read Output Values
		if(m_bOutputIQ  == BST_UNCHECKED)
		{
			iNumValuesOutI = GetNumDataInTxtFile(FALSE, m_csFilenameOutI);
			iNumValuesOutQ = GetNumDataInTxtFile(FALSE, m_csFilenameOutQ);

			if(iNumValuesOutI != iNumValuesOutQ)
			{
				AfxMessageBox(_T("Warning: Output I/Q Files do not have same values, taking smallest of two"));
				if(iNumValuesOutI < iNumValuesOutQ)
					iNumValuesOutQ = iNumValuesOutI;
				else
					iNumValuesOutI = iNumValuesOutQ;
			}

			// Cap values, running out of memory
			if(iNumValuesOutI > EXTRACT_MODEL_MAX_MEMORY_LENGTH)
			{
				iNumValuesOutI = EXTRACT_MODEL_MAX_MEMORY_LENGTH;
				iNumValuesOutQ = EXTRACT_MODEL_MAX_MEMORY_LENGTH;
			}

			pdOutputI = new double[iNumValuesOutI];
			pdOutputQ = new double[iNumValuesOutQ];

			ReadDataFromTxtFile(pdOutputI, iNumValuesOutI, m_csFilenameOutI);
			ReadDataFromTxtFile(pdOutputQ, iNumValuesOutQ, m_csFilenameOutQ);
		}
		else
		{
			iNumValuesOutI = GetNumDataInTxtFile(TRUE, m_csFilenameOutI);

			// Cap values, running out of memory
			if(iNumValuesOutI > EXTRACT_MODEL_MAX_MEMORY_LENGTH)
			{
				iNumValuesOutI = EXTRACT_MODEL_MAX_MEMORY_LENGTH;
				iNumValuesOutQ = EXTRACT_MODEL_MAX_MEMORY_LENGTH;
			}

			pdOutputI = new double[iNumValuesOutI];
			pdOutputQ = new double[iNumValuesOutI];

			ReadDataFromTxtFile(pdOutputI, pdOutputQ, iNumValuesOutI, m_csFilenameOutI);
		}
		
		// If Lengths of Input and Output do not match, take the lowest length and display a warning.
		if(iNumValuesInI != iNumValuesOutI)
		{
			AfxMessageBox(_T("Warning: Input and Output Data do not match length"));
			if(iNumValuesInI > iNumValuesOutI)
				iNumValuesInI = iNumValuesOutI;
		}
	}
	catch(CFileException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}
	catch(CMemoryException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	// Assign to internal member variables
	m_pdInputI = pdInputI;
	m_pdInputQ = pdInputQ;
	m_pdOutputI = pdOutputI;
	m_pdOutputQ = pdOutputQ;
	m_iLength = iNumValuesInI;

	return true;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Computes NMSE, variance, and PAR of the estimated/desired signal.
///
/// \param pdSim simulated output vector (complex)
/// \param pdDes desired output vector (complex)
/// \param iLength length of the vectors
/// \param [out] pdNMSE normalized mean squared error of the signal
/// \param [out] pdNMSEdB normalized mean squared error of the signal (in dB)
/// \param [out] pdVar variance of the difference between the two signals
/// \param [out] pdVardB variance of the difference between the two signals (in dB)
/// \param [out] pdPAR peak power to average ratio
/// \param [out] pdPARdB peak power to average ratio (in dB)
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::NMSEdBVarFunc(double* pdSim, double* pdDes, int iLength, double* pdNMSE, double* pdNMSEdB, double* pdVar, double* pdVardB, double* pdPAR, double* pdPARdB)
{


	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Computes NMSE, variance, and PAR of the estimated/desired signal.
///
/// \param pcdSim simulated output vector (complex)
/// \param pcdDes desired output vector (complex)
/// \param iLength length of the vectors
/// \param [out] pdNMSE normalized mean squared error of the signal
/// \param [out] pdNMSEdB normalized mean squared error of the signal (in dB)
/// \param [out] pdVar variance of the difference between the two signals
/// \param [out] pdVardB variance of the difference between the two signals (in dB)
/// \param [out] pdPAR peak power to average ratio
/// \param [out] pdPARdB peak power to average ratio (in dB)
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::NMSEdBVarFunc(doublecomplex* pcdSim, doublecomplex* pcdDes, int iLength, double* pdNMSE, double* pdNMSEdB, double* pdVar, double* pdVardB, double* pdPAR, double* pdPARdB)
{
	int iIndex;
	double dNum, dDen;
	doublecomplex cdTemp;
	doublecomplex* pcdSub = NULL;
	double* pdAbs = NULL;
	double dMean, dMax;

	// validate length
	if(iLength < 1)
	{
		*pdNMSE = 0.0;
		*pdNMSEdB = 0.0;
		*pdVar = 0.0;
		*pdVardB = 0.0;
		*pdPAR = 0.0;
		*pdPARdB = 0.0;

		return;
	}

	// NMSE calculation
	// Compute sum(ydes - ysim) / sum(ydes)
	dNum = 0.0;
	dDen = 0.0;
	pcdSub = new doublecomplex[iLength];
	pdAbs = new double[iLength];

	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		cdTemp.r = pcdDes[iIndex].r - pcdSim[iIndex].r;
		cdTemp.i = pcdDes[iIndex].i - pcdSim[iIndex].i;

		dNum += (cdTemp.r * cdTemp.r) + (cdTemp.i * cdTemp.i);
		dDen += (pcdDes[iIndex].r * pcdDes[iIndex].r) + (pcdDes[iIndex].i * pcdDes[iIndex].i);

		pcdSub[iIndex].r = pcdSim[iIndex].r - pcdDes[iIndex].r;
		pcdSub[iIndex].i = pcdSim[iIndex].i - pcdDes[iIndex].i;

		pdAbs[iIndex] = sqrt((pcdSub[iIndex].r * pcdSub[iIndex].r) + (pcdSub[iIndex].i * pcdSub[iIndex].i));
	}

	*pdNMSE = dNum / dDen;
	*pdNMSEdB = 10 * log10(*pdNMSE);

	// Variance calculation
	*pdVar = MatlabVar(pcdSub, iLength);
	*pdVardB = 20 * log10(*pdVar);

	// PAR calculation
	dMean = MatlabMean(pdAbs, iLength);

	// Find Max
	dMax = pdAbs[0];
	for(iIndex = 1; iIndex < iLength; iIndex++)
	{
		if(dMax < pdAbs[iIndex])
			dMax = pdAbs[iIndex];
	}

	*pdPAR = dMax / dMean;
	*pdPARdB = 20 * log10(*pdPAR);

	SAFE_DELETE_ARRAY(pcdSub);
	SAFE_DELETE_ARRAY(pdAbs);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the running setting
///
/// \param iExtractLUT extracts the LUT
/// \param iExtractFilter extracts the filter
/// \param iFilterIdentification filter identification
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetRunningSetting(int iExtractLUT, int iExtractFilter, int iFilterIdentification)
{
	m_iExtractLUT = iExtractLUT;
	m_iExtractFilter = iExtractFilter;
	m_iFilterIdentification = iFilterIdentification;

	return;
}

////////////////////////////////////////////////////////////////////////////////////
///
/// Saves the parameters to an archived file.
///
/// \param pcdCoeff pointer to coefficients
/// \param iLength number of coefficients
/// \param csLUTFilename the target LUT filename
/// \param csPhaseOffsetFilename the target Phase Offset filename
/// \param csModelParametersFilename filename to save to
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SaveParameters(doublecomplex* pcdCoeff, int iLength, CString csLUTFilename, CString csPhaseOffsetFilename, CString csModelParametersFilename)
{
	//CStdioFile cfOutput;
	//CString csInputAttenuation;
	//CString csOutputAttenuation;
	//CString csTaps;
	//CString csOrder;
	//CString csCoeff;
	int iIndex;

	MODEL_PARAMS sParams;
	CModelParametersArchive cMPA;

	// Copy the params to struct
	sParams.m_pcdCoeff = NULL;

	sParams.m_csAppType = m_csAppType;
	sParams.m_csLUTFilename = csLUTFilename;
	sParams.m_csPhaseOffsetFilename = csPhaseOffsetFilename;
	sParams.m_csPAType = m_csSystemType;
	sParams.m_csSignalType = m_csSignalType;
	sParams.m_dInputAttenuation = m_dInputAttenuation;
	sParams.m_dOutputAttenuation = m_dOutputAttenuation;
	sParams.m_eMethod = m_eMethodType;
	sParams.m_iTaps = m_iTaps;
	sParams.m_iOrder = m_iOrder;
	sParams.m_eModel = m_eModelType;
	sParams.m_iCoeffLength = iLength;

	sParams.m_pcdCoeff = new doublecomplex[iLength];

	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		sParams.m_pcdCoeff[iIndex].r = pcdCoeff[iIndex].r;
		sParams.m_pcdCoeff[iIndex].i = pcdCoeff[iIndex].i;
	}

	try
	{
		CFile cfOutput(csModelParametersFilename, CFile::modeCreate | CFile::modeWrite);
		CArchive caOutput(&cfOutput, CArchive::store);
		
		// Set the struct inside the class
		cMPA.SetData(sParams);
		cMPA.Serialize(caOutput);

		caOutput.Close();
		cfOutput.Close();
	}
	catch(CArchiveException* pEx)
	{
		//MESSAGEBOX_ARCHIVEEXCEPTION(pEx);
		EXCEPTION_ADDUSERMESSAGE(_T("Archiving Exception"));
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(sParams.m_pcdCoeff);

		throw;
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(sParams.m_pcdCoeff);

		throw;	
	}

	SAFE_DELETE_ARRAY(sParams.m_pcdCoeff);

	//// Open File
	//cfOutput.Open(m_csModelParamOutputFilename, CFile::modeCreate | CFile::modeWrite);

	//csInputAttenuation.Format(_T("%.6f"), m_dInputAttenuation);
	//csOutputAttenuation.Format(_T("%.6f"), m_dOutputAttenuation);
	//csTaps.Format(_T("%d"), m_iTaps);
	//csOrder.Format(_T("%d"), m_iOrder);

	//// Write Parameters (test for now...)
	//cfOutput.WriteString(_T("LUTfileName: ") + m_csLUTOutputFilename + _T("\n"));
	//cfOutput.WriteString(_T("AppType: ") + m_csAppType + _T("\n"));
	//cfOutput.WriteString(_T("phaseoffsetfileName: ") + m_csPhaseOffsetOutputFilename + _T("\n"));
	//cfOutput.WriteString(_T("PAtype: ") + m_csSystemType + _T("\n"));
	//cfOutput.WriteString(_T("signalType: ") + m_csSignalType + _T("\n"));
	//cfOutput.WriteString(_T("inputAtt: ") + csInputAttenuation + _T("\n"));
	//cfOutput.WriteString(_T("outputAtt: ") + csOutputAttenuation + _T("\n"));
	//cfOutput.WriteString(_T("Algorithm: ") + m_csMethodType + _T("\n"));
	//cfOutput.WriteString(_T("taps: ") + csTaps + _T("\n"));
	//cfOutput.WriteString(_T("polyorder: ") + csOrder + _T("\n"));
	//cfOutput.WriteString(_T("type: ") + CString(_T("Multi-branch Polynomial")) + _T("\n"));
	//cfOutput.WriteString(_T("coeff:  \n"));

	//if(bComplex)
	//	iInc = 2;

	//for(iIndex = 0; iIndex < iLength * iInc; iIndex+=iInc)
	//{
	//	if(bComplex)
	//		csCoeff.Format(_T("%.8f + j%0.8f"), pdCoeffs[iIndex], pdCoeffs[iIndex+1]);
	//	else
	//		csCoeff.Format(_T("%.8f"), pdCoeffs[iIndex]);

	//	cfOutput.WriteString(csCoeff + _T("\n"));
	//}

	//// Close file
	//cfOutput.Close();

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the linear gain filename (small signal parameters) for DPD computation
///
/// \param csFilename the linear gain filename
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetLinearGainFilename(CString csFilename)
{
	m_csLinearGainFilename = csFilename;

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Sets the spectrum parameters
///
/// \param rsSpectrumParams the spectrum parameters
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SetSpectrumParameters(SPECTRUM_PARAMS& rsSpectrumParams)
{
	CopySpectrumParameters(rsSpectrumParams, m_sSpectrumParams);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Gets the small signal parameters from the LinearGain text file
///
/// \param [out] pdSmallSignal small signal gain
/// \param [out] pdPhaseOffset phase offset
/// \param [out] pdPhaseOffsetDPD phase offset for dpd
/// \param [out] pdPhaseOffsetPostDPD phase offset for post dpd
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::GetSmallSignalParameters(double* pdSmallSignal, double* pdPhaseOffset, double* pdPhaseOffsetDPD, double* pdPhaseOffsetPostDPD)
{
	CStdioFile cfInput;
	CString csLine;
	CString csParse;
	int iCurPos = 0;

	// Set default parameters
	*pdSmallSignal = 1.0;
	*pdPhaseOffset = 0.0;
	if(pdPhaseOffsetDPD)
		*pdPhaseOffsetDPD = 0.0;
	if(pdPhaseOffsetPostDPD)
		*pdPhaseOffsetPostDPD = 0.0;

	// if m_csLinearGain is empty, just return
	if(m_csLinearGainFilename.IsEmpty())
		return;

	// Try reading from linear gain file
	try
	{
		cfInput.Open(m_csLinearGainFilename, CFile::modeRead);
		cfInput.ReadString(csLine);

		// Parse contents
		csParse = csLine.Tokenize(" ", iCurPos);
		*pdSmallSignal = _tstof(csParse);
		csParse = csLine.Tokenize(" ", iCurPos);
		*pdPhaseOffset = _tstof(csParse);
		
		csParse = csLine.Tokenize(" ", iCurPos);
		if(pdPhaseOffsetDPD)		
			*pdPhaseOffsetDPD = _tstof(csParse);
		
		csParse = csLine.Tokenize(" ", iCurPos);
		if(pdPhaseOffsetPostDPD)
			*pdPhaseOffsetPostDPD = _tstof(csParse);

		cfInput.Close();
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Saves the Polynomial Coefficients to files *.mdf, *.txt
///
/// \param pcdCoeffs pointer to the complex data coefficients
/// \param iLength length of the input data
/// \param csADSFilename the ADS filename (.mdf file)
/// \param csTXTFilename the TXT filename (.txt file)
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::SavePolynomialCoefficients(doublecomplex* pcdCoeffs, int iLength, CString csADSFilename, CString csTXTFilename)
{
	CStdioFile cfOutput;
	CString csLine;
	int iNNLength;
	int iCoeffIndex, iIndex;
	int iOffset;

	cfOutput.Open(csADSFilename, CFile::modeCreate | CFile::modeWrite);

	iNNLength = round(double(iLength) / double(m_iTaps));

	cfOutput.WriteString(_T("BEGIN DSCRDATA\n"));
	cfOutput.WriteString(_T("%%INDEX "));

	for(iIndex = 0; iIndex < iNNLength; iIndex++)
	{
		csLine.Format(_T("    a%d_r   a%d_i"), iIndex, iIndex);
		cfOutput.WriteString(csLine);
	}

	for(iIndex = 0; iIndex < m_iTaps; iIndex++)
	{
		csLine.Format(_T("\n%d"), iIndex);
		cfOutput.WriteString(csLine);
		for(iCoeffIndex = 0; iCoeffIndex < iNNLength; iCoeffIndex++)
		{
			iOffset = iCoeffIndex + (iNNLength * iIndex);
			csLine.Format(_T("    %2.14f  %2.14f"), pcdCoeffs[iOffset].r, pcdCoeffs[iOffset].i);
			cfOutput.WriteString(csLine);
		}
	}
	cfOutput.WriteString(_T("\nEND"));

	cfOutput.Close();


	// Write to text file

	/// \bug in MATLAB @ 346, iterator is k, not i
	cfOutput.Open(csTXTFilename, CFile::modeCreate | CFile::modeWrite);

	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		csLine.Format(_T("%2.14f  %2.14f  \n"), pcdCoeffs[iIndex].r, pcdCoeffs[iIndex].i);
		cfOutput.WriteString(csLine);
	}

	cfOutput.Close();

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Creates the single branch LUT for Memory Polynomial function.
/// Performs downsampling, and upsampling using lagrange interpolation.
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/makeLUTwithPOLYnewfunc.m"> makeLUTwithPOLYnewfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::MakeLUTWithPoly(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double* pdMagInLUT, double* pdGainLUT, double* pdPhaseLUT, double* pdOffsetLUT)
{
	int iBits;
	int iLUTValidSize = m_iLUTSize;
	double* pdMagInDown = NULL;
	double* pdGainDown = NULL;
	double* pdPhaseDown = NULL;

	double dPhaseTh;
	double dV_phaseth_dB;
	double dV_phaseth;
	double dPhaseOffset = 0;

	int iIndex;

	int iGranularity;
	int iLast;
	int iOrder;

	int iLagrangeLength;

	double* pdMagInDownReverse = NULL;
	double* pdGainDownReverse = NULL;
	double* pdPhaseDownReverse = NULL;

	double* pdMagInDIInterp = NULL;
	double* pdGainDIInterp = NULL;
	double* pdPhaseDIInterp = NULL;
	double* pdTime = NULL;
	
	int iIndexMinInterp;
	double dMinInterp;

	double* pdMagInPD = NULL;
	double* pdGainPD = NULL;
	double* pdPhasePD = NULL;
	
	int iPDLength;

	// Num2Bits function
	iBits = Num2Bits(m_iLUTSize);

	pdMagInDown = new double[m_iLUTSize];
	pdGainDown = new double[m_iLUTSize];
	pdPhaseDown = new double[m_iLUTSize];

	TimeToPowerDomain(pdMagIn, pdGain, pdPhase, iLength, iBits, m_dLUTTruncate, pdMagInDown, pdGainDown, pdPhaseDown, &iLUTValidSize);

	// Find the phase offset
	dPhaseTh = 10;
	dV_phaseth_dB = (10 * log10(pow(MatlabMax(pdMagInDown, iLUTValidSize), 2) / 50) + 30) - dPhaseTh;
	dV_phaseth = sqrt(pow(10, 0.1 * (dV_phaseth_dB - 30) + 2));

	// \bug In MATLAB, this shouldn't go all the way to 1.
	dPhaseOffset = 0;
	for(iIndex = (iLUTValidSize - 1); iIndex >= 20; iIndex--)
	{
		if(pdMagInDown[iIndex] <= dV_phaseth)
		{
			// in MATLAB, takes the current and last 20 elements.
			dPhaseOffset = MatlabMean(&pdPhaseDown[iIndex - 20], 21);
			break;
		}
	}
	*pdOffsetLUT = dPhaseOffset;

	// Subtract whole vector by the phase offset (shift phase)
	for(iIndex = 0; iIndex < iLUTValidSize; iIndex++)
	{
		pdPhaseDown[iIndex] = pdPhaseDown[iIndex] - dPhaseOffset;
	}

	// Not being used in the MATLAB code, remove.
	// Convert to dB values
	//for(iIndex = 0; iIndex < iLUTValidSize; iIndex++)
	//{
	//	pdMagInDown[iIndex] = 10 * log10((0.5 * pow(pdMagInDown[iIndex], 2)) / 50) + 30;
	//	pdGainDown[iIndex] = 20 * log10(pdGainDown[iIndex]);
	//	pdPhaseDown[iIndex] = pdPhaseDown[iIndex] * 180 / M_PI;

	//}

	// Make the lagrange interpolation for the large signal
	iGranularity = 10;
	iLast = 50;
	iOrder = 3;

	// take the last data in reverse order...
	pdMagInDownReverse = new double[iLast];
	pdGainDownReverse = new double[iLast];
	pdPhaseDownReverse = new double[iLast];

	for(iIndex = 0; iIndex < iLast; iIndex++)
	{
		pdMagInDownReverse[iIndex] = pdMagInDown[(iLUTValidSize - 1) - iIndex];
		pdGainDownReverse[iIndex] = pdGainDown[(iLUTValidSize - 1) - iIndex];
		pdPhaseDownReverse[iIndex] = pdPhaseDown[(iLUTValidSize - 1) - iIndex];
	}

	// Compute the number needed for lagrange
	iLagrangeLength = LagrangeInterpolation(pdMagInDownReverse, iLast, iGranularity, iOrder, pdTime, pdMagInDIInterp, 1);

	// Now create arrays
	pdTime = new double[iLagrangeLength];
	pdMagInDIInterp = new double[iLagrangeLength];
	pdGainDIInterp = new double[iLagrangeLength];
	pdPhaseDIInterp = new double[iLagrangeLength];

	// Perform Lagrange on Magnitude in, Gain, and Phase
	LagrangeInterpolation(pdMagInDownReverse, iLast, iGranularity, iOrder, pdTime, pdMagInDIInterp);
	LagrangeInterpolation(pdGainDownReverse, iLast, iGranularity, iOrder, pdTime, pdGainDIInterp);
	LagrangeInterpolation(pdPhaseDownReverse, iLast, iGranularity, iOrder, pdTime, pdPhaseDIInterp);


	iIndexMinInterp = 0;
	dMinInterp = pdMagInDIInterp[iLagrangeLength - 1];

	for(iIndex = 0; iIndex < iLUTValidSize; iIndex++)
	{
		if(pdMagInDown[iIndex] >= dMinInterp)
		{
			iIndexMinInterp = iIndex;
			break;
		}
	}

	// Remove the items after iIndexMinInterp...
	// Created a new array, since it may overflow.
	iPDLength = iIndexMinInterp + iLagrangeLength;
	pdMagInPD = new double[iPDLength];
	pdGainPD = new double[iPDLength];
	pdPhasePD = new double[iPDLength];

	// insert data
	for(iIndex = 0; iIndex < iIndexMinInterp; iIndex++)
	{
		pdMagInPD[iIndex] = pdMagInDown[iIndex];
		pdGainPD[iIndex] = pdGainDown[iIndex];
		pdPhasePD[iIndex] = pdPhaseDown[iIndex];
	}

	// Insert reverse interpolated data in normal order...
	for(iIndex = iIndexMinInterp; iIndex < iPDLength; iIndex++)
	{
		pdMagInPD[iIndex] = pdMagInDIInterp[(iLagrangeLength - 1) - (iIndex - iIndexMinInterp)];
		pdGainPD[iIndex] = pdGainDIInterp[(iLagrangeLength - 1) - (iIndex - iIndexMinInterp)];
		pdPhasePD[iIndex] = pdPhaseDIInterp[(iLagrangeLength - 1) - (iIndex - iIndexMinInterp)];
	}

	// Call makePA_LUTfunc
	MakePALUT(pdMagInPD, pdGainPD, pdPhasePD, iPDLength, pdMagInLUT, pdGainLUT, pdPhaseLUT, m_iLUTSize);

	// Free Memory
	SAFE_DELETE_ARRAY(pdMagInPD);
	SAFE_DELETE_ARRAY(pdGainPD);
	SAFE_DELETE_ARRAY(pdPhasePD);

	SAFE_DELETE_ARRAY(pdTime);

	SAFE_DELETE_ARRAY(pdMagInDIInterp);
	SAFE_DELETE_ARRAY(pdGainDIInterp);
	SAFE_DELETE_ARRAY(pdPhaseDIInterp);

	SAFE_DELETE_ARRAY(pdMagInDownReverse);
	SAFE_DELETE_ARRAY(pdGainDownReverse);
	SAFE_DELETE_ARRAY(pdPhaseDownReverse);

	SAFE_DELETE_ARRAY(pdMagInDown);
	SAFE_DELETE_ARRAY(pdGainDown);
	SAFE_DELETE_ARRAY(pdPhaseDown);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Creates the single branch LUT for Memory Polynomial function.
/// Performs downsampling, and upsampling using lagrange interpolation.
/// \note This function overloads the other one, since the only difference is using a databits input, and polyfit/polyval at the end.
/// \note This version uses psOutputLUT, since there is a need for a return value
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/makeLUTwithPOLYfunc.m"> makeLUTwithPOLYfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::MakeLUTWithPoly(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, MAGGAINPHASE* psOutputLUT, double* pdOffsetLUT, int iDataBits)
{
	int iBits;
	int iLUTValidSize = m_iLUTSize;
	double* pdMagInDown = NULL;
	double* pdGainDown = NULL;
	double* pdPhaseDown = NULL;

	double dPhaseTh;
	double dV_phaseth_dB;
	double dV_phaseth;
	double dPhaseOffset = 0;

	int iIndex;

	int iGranularity;
	int iLast;
	int iOrder;

	int iLagrangeLength;

	double* pdMagInDownReverse = NULL;
	double* pdGainDownReverse = NULL;
	double* pdPhaseDownReverse = NULL;

	double* pdMagInDIInterp = NULL;
	double* pdGainDIInterp = NULL;
	double* pdPhaseDIInterp = NULL;
	double* pdTime = NULL;
	
	int iIndexMinInterp;
	double dMinInterp;

	double* pdMagInPD = NULL;
	double* pdGainPD = NULL;
	double* pdPhasePD = NULL;
	
	int iPDLength;
	int iLUTPoint;

	int iPolyOrder;
	double* pdGainPoly = NULL;
	double* pdPhasePoly = NULL;
	double* pdGainTmp = NULL;
	double* pdPhaseTmp = NULL;

	// Num2Bits function
	iBits = iDataBits;
	int iLUTSize = (int) pow(2.0, (double) iBits);

	pdMagInDown = new double[iLUTSize];
	pdGainDown = new double[iLUTSize];
	pdPhaseDown = new double[iLUTSize];

	TimeToPowerDomain(pdMagIn, pdGain, pdPhase, iLength, iBits, m_dLUTTruncate, pdMagInDown, pdGainDown, pdPhaseDown, &iLUTValidSize);

	// Find the phase offset
	dPhaseTh = 10;
	dV_phaseth_dB = (10 * log10(pow(MatlabMax(pdMagInDown, iLUTValidSize), 2) / 50) + 30) - dPhaseTh;
	dV_phaseth = sqrt(pow(10, 0.1 * (dV_phaseth_dB - 30) + 2));

	// \bug In MATLAB, this shouldn't go all the way to 1.
	dPhaseOffset = 0;
	for(iIndex = (iLUTValidSize - 1); iIndex >= 20; iIndex--)
	{
		if(pdMagInDown[iIndex] <= dV_phaseth)
		{
			// in MATLAB, takes the current and last 20 elements.
			dPhaseOffset = MatlabMean(&pdPhaseDown[iIndex - 20], 21);
			break;
		}
	}
	*pdOffsetLUT = dPhaseOffset;

	// Subtract whole vector by the phase offset (shift phase)
	for(iIndex = 0; iIndex < iLUTValidSize; iIndex++)
	{
		pdPhaseDown[iIndex] = pdPhaseDown[iIndex] - dPhaseOffset;
	}

	// Not being used in the MATLAB code, remove.
	// Convert to dB values
	//for(iIndex = 0; iIndex < iLUTValidSize; iIndex++)
	//{
	//	pdMagInDown[iIndex] = 10 * log10((0.5 * pow(pdMagInDown[iIndex], 2)) / 50) + 30;
	//	pdGainDown[iIndex] = 20 * log10(pdGainDown[iIndex]);
	//	pdPhaseDown[iIndex] = pdPhaseDown[iIndex] * 180 / M_PI;

	//}

	// Make the lagrange interpolation for the large signal
	iGranularity = 10;
	iLast = 50;
	iOrder = 3;

	// take the last data in reverse order...
	pdMagInDownReverse = new double[iLast];
	pdGainDownReverse = new double[iLast];
	pdPhaseDownReverse = new double[iLast];

	for(iIndex = 0; iIndex < iLast; iIndex++)
	{
		pdMagInDownReverse[iIndex] = pdMagInDown[(iLUTValidSize - 1) - iIndex];
		pdGainDownReverse[iIndex] = pdGainDown[(iLUTValidSize - 1) - iIndex];
		pdPhaseDownReverse[iIndex] = pdPhaseDown[(iLUTValidSize - 1) - iIndex];
	}

	// Compute the number needed for lagrange
	iLagrangeLength = LagrangeInterpolation(pdMagInDownReverse, iLast, iGranularity, iOrder, pdTime, pdMagInDIInterp, 1);

	// Now create arrays
	pdTime = new double[iLagrangeLength];
	pdMagInDIInterp = new double[iLagrangeLength];
	pdGainDIInterp = new double[iLagrangeLength];
	pdPhaseDIInterp = new double[iLagrangeLength];

	// Perform Lagrange on Magnitude in, Gain, and Phase
	LagrangeInterpolation(pdMagInDownReverse, iLast, iGranularity, iOrder, pdTime, pdMagInDIInterp);
	LagrangeInterpolation(pdGainDownReverse, iLast, iGranularity, iOrder, pdTime, pdGainDIInterp);
	LagrangeInterpolation(pdPhaseDownReverse, iLast, iGranularity, iOrder, pdTime, pdPhaseDIInterp);


	iIndexMinInterp = 0;
	dMinInterp = pdMagInDIInterp[iLagrangeLength - 1];

	for(iIndex = 0; iIndex < iLUTValidSize; iIndex++)
	{
		if(pdMagInDown[iIndex] >= dMinInterp)
		{
			iIndexMinInterp = iIndex;
			break;
		}
	}

	// Remove the items after iIndexMinInterp...
	// Created a new array, since it may overflow.
	iPDLength = iIndexMinInterp + iLagrangeLength;
	pdMagInPD = new double[iPDLength];
	pdGainPD = new double[iPDLength];
	pdPhasePD = new double[iPDLength];

	// insert data
	for(iIndex = 0; iIndex < iIndexMinInterp; iIndex++)
	{
		pdMagInPD[iIndex] = pdMagInDown[iIndex];
		pdGainPD[iIndex] = pdGainDown[iIndex];
		pdPhasePD[iIndex] = pdPhaseDown[iIndex];
	}

	// Insert reverse interpolated data in normal order...
	for(iIndex = iIndexMinInterp; iIndex < iPDLength; iIndex++)
	{
		pdMagInPD[iIndex] = pdMagInDIInterp[(iLagrangeLength - 1) - (iIndex - iIndexMinInterp)];
		pdGainPD[iIndex] = pdGainDIInterp[(iLagrangeLength - 1) - (iIndex - iIndexMinInterp)];
		pdPhasePD[iIndex] = pdPhaseDIInterp[(iLagrangeLength - 1) - (iIndex - iIndexMinInterp)];
	}

	/// \bug should this always be 1024?
	// Mar 27/08
	// Changed this to actual LUT points.
	//iLUTPoint = 1024;
	iLUTPoint = (int) pow(2.0, (double) iBits);
	psOutputLUT->m_pdMagIn = new double[iLUTPoint];
	psOutputLUT->m_pdGain = new double[iLUTPoint];
	psOutputLUT->m_pdPhase = new double[iLUTPoint];
	psOutputLUT->m_iLength = iLUTPoint;

	// Call makePA_LUTfunc
	MakePALUT(pdMagInPD, pdGainPD, pdPhasePD, iPDLength, psOutputLUT->m_pdMagIn, psOutputLUT->m_pdGain, psOutputLUT->m_pdPhase, iLUTPoint);

	// Fitting the DPD LUT with curve fitting
	/// \bug should this be 9 always?
	iPolyOrder = 9;
	pdGainPoly = new double[iPolyOrder + 1];
	pdPhasePoly = new double[iPolyOrder + 1];
	pdGainTmp = new double[iLUTPoint];
	pdPhaseTmp = new double[iLUTPoint];
	MatlabPolyfit(psOutputLUT->m_pdMagIn, psOutputLUT->m_pdGain, iLUTPoint, iPolyOrder, pdGainPoly);
	MatlabPolyfit(psOutputLUT->m_pdMagIn, psOutputLUT->m_pdPhase, iLUTPoint, iPolyOrder, pdPhasePoly);
	
	MatlabPolyval(psOutputLUT->m_pdMagIn, iLUTPoint, pdGainPoly, iPolyOrder, pdGainTmp);
	MatlabPolyval(psOutputLUT->m_pdMagIn, iLUTPoint, pdPhasePoly, iPolyOrder, pdPhaseTmp);

	// Copy
	for(iIndex = 0; iIndex < iLUTPoint; iIndex++)
	{
		psOutputLUT->m_pdGain[iIndex] = pdGainTmp[iIndex];
		psOutputLUT->m_pdPhase[iIndex] = pdPhaseTmp[iIndex];
	}

	SAFE_DELETE_ARRAY(pdGainPoly);
	SAFE_DELETE_ARRAY(pdPhasePoly);
	SAFE_DELETE_ARRAY(pdGainTmp);
	SAFE_DELETE_ARRAY(pdPhaseTmp);

	// Free Memory
	SAFE_DELETE_ARRAY(pdMagInPD);
	SAFE_DELETE_ARRAY(pdGainPD);
	SAFE_DELETE_ARRAY(pdPhasePD);

	SAFE_DELETE_ARRAY(pdTime);

	SAFE_DELETE_ARRAY(pdMagInDIInterp);
	SAFE_DELETE_ARRAY(pdGainDIInterp);
	SAFE_DELETE_ARRAY(pdPhaseDIInterp);

	SAFE_DELETE_ARRAY(pdMagInDownReverse);
	SAFE_DELETE_ARRAY(pdGainDownReverse);
	SAFE_DELETE_ARRAY(pdPhaseDownReverse);

	SAFE_DELETE_ARRAY(pdMagInDown);
	SAFE_DELETE_ARRAY(pdGainDown);
	SAFE_DELETE_ARRAY(pdPhaseDown);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Downconverts the incoming signal using averaging interpolation.
/// Possible mislabelled function in MATLAB.
///
/// \param pdMagIn input magnitude (x-axis)
/// \param pdGain gain (y-axis 1)
/// \param pdPhase phase (y-axis 2)
/// \param iLength length of input vectors
/// \param iDataBits address width of the LUT
/// \param dPinCutTh input power cutoff threshold
/// \param [out] pdMagInLUT downsampled input magnitude
/// \param [out] pdGainLUT downsampled gain
/// \param [out] pdPhaseLUT downsampled phase
/// \param [out] piLUTSize actual size of downsampling
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/Time2PowerDomainDataConvertFun.m"> Time2PowerDomainDataConvertFun.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::TimeToPowerDomain(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, int iDataBits, double dPinCutTh, double* pdMagInLUT, double* pdGainLUT, double* pdPhaseLUT, int* piLUTSize)
{
	int iIndex;
	int iIndexI;
	int iCounter;
	int iRepeatCounter;

	int* piMagIndices = NULL;
	double* pdMagInSorted = NULL;
	double* pdMagInPd = NULL;
	double* pdGainPd = NULL;
	double* pdPhasePd = NULL;
	
	double dGainPdSum;
	double dPhasePdSum;
	double dMagTh;
	int iCutIndex;
	int iDSPoints;
	int iLUTPoints;

	// Sort Function (need to keep the index)...
	piMagIndices = new int[iLength];
	pdMagInSorted = new double[iLength];
	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		piMagIndices[iIndex] = iIndex;
		pdMagInSorted[iIndex] = pdMagIn[iIndex];
	}

	// Do NOT destroy pdMagIn
	// If the array is sorted and this function is called again, the stack will overflow with multiple
	// recursive calls to MatlabSort....
	MatlabSort(pdMagInSorted, 0, (iLength - 1), piMagIndices);

	pdMagInPd = new double[iLength];
	pdGainPd = new double[iLength];
	pdPhasePd = new double[iLength];

	// Delete repeat data from MagInSorted
	// Direct copy from the MATLAB file...
	iCounter = -1;
	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		if(iIndex > 0)
		{
			if(pdMagInSorted[iIndex] == pdMagInSorted[iCounter])
			{
				// Do Nothing??
			}
		}

		iCounter = iCounter + 1;

		pdMagInPd[iCounter] = pdMagInSorted[iIndex];
		dGainPdSum = pdGain[piMagIndices[iIndex]];
		dPhasePdSum = pdPhase[piMagIndices[iIndex]];

		iRepeatCounter = 0;

		// Questionable loop content?...
		for(iIndexI = 0; iIndexI < (iLength - iIndex); iIndexI++)
		{
			if((iIndex + iIndexI) < iLength)
			{
				if(pdMagInSorted[iIndex] == pdMagInSorted[iIndex + iIndexI])
				{
					iRepeatCounter = iRepeatCounter + 1;
					dGainPdSum = dGainPdSum + pdGain[piMagIndices[iIndex]];
					dPhasePdSum = dPhasePdSum + pdPhase[piMagIndices[iIndex]];
				}
				if(pdMagInSorted[iIndex + iIndexI] > pdMagInSorted[iIndex])
				{
					break;
				}
			}
		}

		pdGainPd[iCounter] = dGainPdSum / (iRepeatCounter + 1);
		pdPhasePd[iCounter] = dPhasePdSum / (iRepeatCounter + 1);
	}

	// last
	iCounter++;

	dMagTh = sqrt(pow(10.0, (0.1 * (dPinCutTh - 30) + 2)));

	// iCounter contains the length sans repeats.
	iCutIndex = 0;
	for(iIndex = 0; iIndex < iCounter; iIndex++)
	{
		if(pdMagInPd[iIndex] >= dMagTh)
		{
			iCutIndex = iIndex;
			break;
		}
	}

	// Instead of making a new variable, cut the index manually, and set iCounter as the length.
	for(iIndex = iCutIndex; iIndex < iCounter; iIndex++)
	{
		pdMagInPd[iIndex - iCutIndex] = pdMagInPd[iIndex];
		pdGainPd[iIndex - iCutIndex] = pdGainPd[iIndex];
		pdPhasePd[iIndex - iCutIndex] = pdPhasePd[iIndex];
	}

	iCounter = iCounter - iCutIndex;
	
	// Make the data down sampling to the 2^databits points...
	switch(iDataBits)
	{
		case 16:
			iDSPoints = 65536;
			break;
		case 14:
			iDSPoints = 16384;
			break;
		case 12:
			iDSPoints = 4096;
			break;
		case 10:
			iDSPoints = 1024;
			break;
		case 8:
			iDSPoints = 256;
			break;
		default:
			iDSPoints = 256;
			AfxMessageBox(_T("Data Bits Error"));
			break;
	}

	// Reserve 20 large signal point...
	iLUTPoints = DownsamplingAveragewithoutInterpolationKeepLargeSignal(iDSPoints, 20, pdMagInPd, pdGainPd, pdPhasePd, iCounter, pdMagInLUT, pdGainLUT, pdPhaseLUT);

	// Pass back the actual number of points.
	*piLUTSize = iLUTPoints;

	// There is code to convert to dB. It is not placed here since it would be inefficient use of resources.
	// (not being used).

	SAFE_DELETE_ARRAY(pdPhasePd);
	SAFE_DELETE_ARRAY(pdGainPd);
	SAFE_DELETE_ARRAY(pdMagInPd);
	SAFE_DELETE_ARRAY(pdMagInSorted);
	SAFE_DELETE_ARRAY(piMagIndices);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Downsamples the signal (with averaging between points), and performs lagrange on the last vectors.
///
/// \param iMaxDSPoints the maximum number of points to downsample
/// \param iLargeSignalPoints number of large signal poitns to keep
/// \param pdMagIn input magnitude (x-axis)
/// \param pdGain gain (y-axis 1)
/// \param pdPhase phase (y-axis 2)
/// \param iLength length of the input vectors (pdMagIn, pdGain, pdPhase)
/// \param [out] pdMagInDown downsampled/interpolated input magnitude
/// \param [out] pdGainDown downsampled/interpolated gain
/// \param [out] pdPhaseDown downsampled/interpolated phase
///
/// \return the number of valid values for the downsampled vectors (<= iMaxPoints)
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/DownSamplingAveragewithoutInterpolationKeepLargeSignalFunc.m"> DownSamplingAveragewithoutInterpolationKeepLargeSignalFunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
int ModelBaseClass::DownsamplingAveragewithoutInterpolationKeepLargeSignal(int iMaxDSPoints, int iLargeSignalPoints, double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double* pdMagInDown, double* pdGainDown, double* pdPhaseDown)
{
	int iIndex;
	int iSmallSignalPoints;
	int iLargeIndex;

	double* pdMagInSmallSigDown = NULL;
	double* pdGainSmallSigDown = NULL;
	double* pdPhaseSmallSigDown = NULL;

	if((iLargeSignalPoints >= iMaxDSPoints) || (iLength < iMaxDSPoints))
	{
		// Deep copy and return.
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pdMagInDown[iIndex] = pdMagIn[iIndex];
			pdGainDown[iIndex] = pdGain[iIndex];
			pdPhaseDown[iIndex] = pdPhase[iIndex];
		}

		return iLength;
	}

	// Separate Small Signal/Large Signals
	// Use An Indexing Pointer...

	// Call Downsampling Average...
	// Interpolate all but the last couple of points
	pdGainSmallSigDown = new double[iLength];
	pdPhaseSmallSigDown = new double[iLength];
	pdMagInSmallSigDown = new double[iLength];
	iSmallSignalPoints = DownsamplingAveragewithoutInterpolation((iMaxDSPoints - iLargeSignalPoints), 
																 &pdMagIn[0], &pdGain[0], &pdPhase[0], 
																 (iLength - iLargeSignalPoints),
																 pdMagInSmallSigDown, pdGainSmallSigDown, pdPhaseSmallSigDown);

	// Copy back to output.
	// pdMagInPdDs1:pdMagInPd(end-iN:end)
	for(iIndex = 0; iIndex < iSmallSignalPoints; iIndex++)
	{
		pdMagInDown[iIndex] = pdMagInSmallSigDown[iIndex];
		pdGainDown[iIndex] = pdGainSmallSigDown[iIndex];
		pdPhaseDown[iIndex] = pdPhaseSmallSigDown[iIndex];
	}

	// Possiblity that iSmallSignalPoints + iLargeSignalPoints != iMaxDSPoints, copy to end of index, and
	// and return actual value
	for(iIndex = iSmallSignalPoints, iLargeIndex = (iLength - iLargeSignalPoints); iLargeIndex < iLength; iIndex++, iLargeIndex++)
	{
		pdMagInDown[iIndex] = pdMagIn[iLargeIndex];
		pdGainDown[iIndex] = pdGain[iLargeIndex];
		pdPhaseDown[iIndex] = pdPhase[iLargeIndex];
	}

	SAFE_DELETE_ARRAY(pdMagInSmallSigDown);
	SAFE_DELETE_ARRAY(pdPhaseSmallSigDown);
	SAFE_DELETE_ARRAY(pdGainSmallSigDown);

	return (iSmallSignalPoints + iLargeSignalPoints);
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Downsamples the signal (with averaging between points).
///
/// \param iMaxDSPoints the maximum number of points to downsample
/// \param pdMagIn input magnitude (x-axis)
/// \param pdGain gain (y-axis 1)
/// \param pdPhase phase (y-axis 2)
/// \param iLength length of the input vectors (pdMagIn, pdGain, pdPhase)
/// \param [out] pdMagInDown downsampled/interpolated input magnitude
/// \param [out] pdGainDown downsampled/interpolated gain
/// \param [out] pdPhaseDown downsampled/interpolated phase
///
/// \return the number of valid values for the downsampled vectors (<= iMaxPoints)
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/DownSamplingAveragewithoutInterpolationFunc.m"> DownSamplingAveragewithoutInterpolationFunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
int ModelBaseClass::DownsamplingAveragewithoutInterpolation(int iMaxDSPoints, double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double* pdMagInDown, double* pdGainDown, double* pdPhaseDown)
{
	int iIndex;
	int iProcessedIndex;
	int iIndexScan;
	int iIndexAvg;
	int iNumData = 0;
	double dGainSum;
	double dPhaseSum;
	int iCounter;

	double dInitValue;
	double dFullScale;
	double dResolution;

	double* pdMagInPdTemp = NULL;
	double* pdGainPdTemp = NULL;
	double* pdPhasePdTemp = NULL;

	// Initialize the LUT
	dInitValue = 1.0e6;
	pdMagInPdTemp = new double[iMaxDSPoints];
	pdGainPdTemp = new double[iMaxDSPoints];
	pdPhasePdTemp = new double[iMaxDSPoints];
	for(iIndex = 0; iIndex < iMaxDSPoints; iIndex++)
	{
		pdMagInPdTemp[iIndex] = dInitValue;
		pdGainPdTemp[iIndex] = 0.0;
		pdPhasePdTemp[iIndex] = 0.0;
	}

	// Compute the step factor (difference between interpolation points on the x-axis)
	dFullScale = pdMagIn[iLength - 1] - pdMagIn[0];
	dResolution = dFullScale / double(iMaxDSPoints - 1);


	// Main Loop
	iProcessedIndex = 0;
	for(iIndex = 0; iIndex < iMaxDSPoints; iIndex++)
	{
		// Endpoint Case
		if(iIndex == (iMaxDSPoints - 1))
		{
			pdMagInPdTemp[iIndex] = pdMagIn[iLength - 1];
			iNumData = iLength - iProcessedIndex;

			if(iNumData == 0)
			{
				// I did not copy this part because it is not being used later in the function...
				break;
			}

			// Average the data points that are after the boundary
			dGainSum = 0.0;
			dPhaseSum = 0.0;

			for(iIndexAvg = 0; iIndexAvg < iNumData; iIndexAvg++)
			{
				dGainSum = dGainSum + pdGain[iProcessedIndex];
				dPhaseSum = dPhaseSum + pdPhase[iProcessedIndex];
			}

			pdGainPdTemp[iIndex] = dGainSum / iNumData;
			pdPhasePdTemp[iIndex] = dPhaseSum / iNumData;
			break;
		}

		// We know the interpolation rate of the x-axis, so just store directly (with resolution offset)
		/// \note Taijun: Did you mean to subtract -1 in MATLAB? (line 48)
		pdMagInPdTemp[iIndex] = pdMagIn[0] + (dResolution * (iIndex + 1));

		// Perform Averaging...
		for(iIndexScan = 0; iIndexScan < iLength; iIndexScan++)
		{
			if(pdMagInPdTemp[iIndex] <= pdMagIn[iIndexScan])
			{
				iNumData = iIndexScan - iProcessedIndex + 1;

				if(iNumData == 0)
				{
					// I did not copy this part because it is not being used later in the function...
					break;
				}

				dGainSum = 0.0;
				dPhaseSum = 0.0;

				for(iIndexAvg = 0; iIndexAvg < iNumData; iIndexAvg++)
				{
					dGainSum = dGainSum + pdGain[iProcessedIndex + iIndexAvg];
					dPhaseSum = dPhaseSum + pdPhase[iProcessedIndex + iIndexAvg];
				}

				pdGainPdTemp[iIndex] = dGainSum / iNumData;
				pdPhasePdTemp[iIndex] = dPhaseSum / iNumData;
				break;
			}
		}

		iProcessedIndex = iProcessedIndex + iNumData;
	}


	// Scan and remove values that would have been skipped...
	iCounter = 0;
	for(iIndex = 0; iIndex < iMaxDSPoints; iIndex++)
	{
		if((pdMagInPdTemp[iIndex] == dInitValue) || (pdGainPdTemp[iIndex] == 0))
		{
			// Continue, do nothing..., maybe should check the phase...
		}
		else
		{
			// Rearranged the iCounter (MATLAB indexing)
			pdMagInDown[iCounter] = pdMagInPdTemp[iIndex];
			pdGainDown[iCounter] = pdGainPdTemp[iIndex];
			pdPhaseDown[iCounter] = pdPhasePdTemp[iIndex];
			iCounter = iCounter + 1;
		}
	}


	SAFE_DELETE_ARRAY(pdMagInPdTemp);
	SAFE_DELETE_ARRAY(pdGainPdTemp);
	SAFE_DELETE_ARRAY(pdPhasePdTemp);

	return iCounter;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Does a lagrange interpolation on the input data, pdInput
///
/// \param pdYin pointer to the input data
/// \param iLength length of the input data
/// \param iGranul granularity (larger than 1)
/// \param iOrder order
/// \param [out] pdXout linear array output (preallocated pointer)
/// \param [out] pdYout interpolated array output (preallocated pointer)
/// \param iComputeLength if != 0, returns the number of elements to allocate for Lagrange
///
/// \return the number of elements to allocate for Lagrange Interpolation if iComputeLength != 0
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/tjLagrangeInterpolation.m"> tjLagrangeInterpolation.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
int ModelBaseClass::LagrangeInterpolation(double* pdYin, int iLength, int iGranul, int iOrder, double* pdXout, double* pdYout, int iComputeLength)
{
	int iIndex;
	int iTotalLength;
	double dXoutStep;
	int* piXin = NULL;
	int iXinStep;
	int* piDenominator = NULL;
	double* pdNominator = NULL;
	int iCounter;
	int iXTemp;

	// Points after interpolation
	iTotalLength = iGranul * (iLength - iOrder);

	if(iComputeLength)
	{
		return iTotalLength;
	}

	piXin = new int[iLength];
	for(iIndex = 0; iIndex < iLength; iIndex++)
	{
		piXin[iIndex] = iIndex + 1;
	}

	iXinStep = piXin[1] - piXin[0];
	dXoutStep = double(iXinStep) / double(iGranul);

	piDenominator = new int[iOrder + 1];
	pdNominator = new double[iOrder + 1];
	// Compute denominator
	for(iIndex = 0; iIndex < iOrder + 1; iIndex++)
	{
		piDenominator[iIndex] = CrossDifferenceMultiplier(iIndex, &piXin[0], iOrder + 1);
	}


	// Make Lagrange Interpolation
	iCounter = 0;
	for(iIndex = 0; iIndex < (iTotalLength - 1); iIndex += iGranul)
	{
		for(int iGranulIndex = 0; iGranulIndex < iGranul; iGranulIndex++)
		{
			pdXout[iIndex + iGranulIndex] = piXin[iCounter] + (iGranulIndex * dXoutStep);
			pdYout[iIndex + iGranulIndex] = 0.0;

			for(int iOrderIndex = 0; iOrderIndex < (iOrder + 1); iOrderIndex++)
			{
				iXTemp = piXin[iCounter] + iOrderIndex;
				pdNominator[iOrderIndex] = 0.0;

				pdNominator[iOrderIndex] = CoCrossDifferenceMultiplier(iXTemp, pdXout[iIndex + iGranulIndex], &piXin[iCounter], (iOrder + 1));

				if(piDenominator[iOrderIndex] != 0)
				{
					pdYout[iIndex + iGranulIndex] = pdYout[iIndex + iGranulIndex] + (pdNominator[iOrderIndex] * pdYin[iCounter + iOrderIndex] / double(piDenominator[iOrderIndex]));
				}
			}	
		}
		iCounter = iCounter + 1;
	}

	SAFE_DELETE_ARRAY(piXin);
	SAFE_DELETE_ARRAY(piDenominator);
	SAFE_DELETE_ARRAY(pdNominator);

	return iTotalLength;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Uses average interpolation on the input data (of length iLength) to upsample/downsample to the
/// LUT length (iLUTLength)
///
/// \param pdMagIn input magnitude (x-axis)
/// \param pdGain gain (y-axis 1)
/// \param pdPhase phase (y-axis 2)
/// \param iLength length of the input vectors
/// \param [out] pdMagInLUT the LUT input magnitude
/// \param [out] pdGainLUT the LUT gain
/// \param [out] pdPhaseLUT the LUT phase
/// \param iLUTLength the length of the LUT
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/makePA_LUTfunc.m"> makePA_LUTfunc.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::MakePALUT(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double* pdMagInLUT, double* pdGainLUT, double* pdPhaseLUT, int iLUTLength)
{
	int iIndex;
	double dMagStep;
	int iAvgIndex;

	if(iLength < 1 || iLUTLength < 1)
		return;

	// if input length and LUT length are equal, copy and return
	if(iLength == iLUTLength)
	{
		for(iIndex = 0; iIndex < iLUTLength; iIndex++)
		{
			pdMagInLUT[iIndex] = pdMagIn[iIndex];
			pdGainLUT[iIndex] = pdGain[iIndex];
			pdPhaseLUT[iIndex] = pdPhase[iIndex];
		}
	}
	else
	{
		dMagStep = (pdMagIn[iLength - 1] - pdMagIn[0]) / (iLUTLength - 1);

		// Initialize first and last points
		pdMagInLUT[0] = pdMagIn[0];
		pdMagInLUT[iLUTLength - 1] = pdMagIn[iLength - 1];
		pdGainLUT[0] = pdGain[0];
		pdGainLUT[iLUTLength - 1] = pdGain[iLength - 1];
		pdPhaseLUT[0] = pdPhase[0];
		pdPhaseLUT[iLUTLength - 1] = pdPhase[iLength - 1];


		for(iIndex = 1; iIndex < (iLUTLength - 1); iIndex++)
		{
			pdMagInLUT[iIndex] = pdMagInLUT[0] + (iIndex * dMagStep);

			// Perform averaging on the points between bins.
			for(iAvgIndex = 1; iAvgIndex < iLength; iAvgIndex++)
			{
				if((pdMagInLUT[iIndex] <= pdMagIn[iAvgIndex]) && (pdMagInLUT[iIndex] >= pdMagIn[iAvgIndex - 1]))
				{	
					if(pdMagInLUT[iIndex] == pdMagIn[iAvgIndex])
					{
						pdGainLUT[iIndex] = pdGain[iAvgIndex];
						pdPhaseLUT[iIndex] = pdPhaseLUT[iAvgIndex];
					}
					else if(pdMagInLUT[iIndex] == pdMagIn[iAvgIndex - 1])
					{
						pdGainLUT[iIndex] = pdGain[iAvgIndex];
						pdPhaseLUT[iIndex] = pdPhase[iAvgIndex];
					}
					else
					{
						pdGainLUT[iIndex] = pdGain[iAvgIndex - 1] + (pdGain[iAvgIndex] - pdGain[iAvgIndex - 1]) * (pdMagInLUT[iIndex] - pdMagIn[iAvgIndex - 1]) / (pdMagIn[iAvgIndex] - pdMagIn[iAvgIndex - 1]);
						pdPhaseLUT[iIndex] = pdPhase[iAvgIndex - 1] + (pdPhase[iAvgIndex] - pdPhase[iAvgIndex - 1]) * (pdMagInLUT[iIndex] - pdMagIn[iAvgIndex - 1]) / (pdMagIn[iAvgIndex] - pdMagIn[iAvgIndex - 1]);
						break;
					}
				}
			}
		}
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Displays input max, and small signal gain parameters
///
////////////////////////////////////////////////////////////////////////////////////
void ModelBaseClass::DisplayInputMaxSSG()
{
	double dMaxInput;
	int iIndex;
	double dSmallSignalGain;
	double dPhaseOffset;
	CString csMessage;
	CString csFilename;
	MAGGAINPHASE sPALUT = MAGGAINPHASE_INIT;
	MAGGAINPHASE sDPDLUT = MAGGAINPHASE_INIT;
	try
	{
		// Read In Small Signal gain
		GetSmallSignalParameters(&dSmallSignalGain, &dPhaseOffset);
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
		LoadLUT(csFilename, &sPALUT);
		csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT_ads.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
		LoadLUT(csFilename, &sDPDLUT);

		// Convert to dB
		dSmallSignalGain = 20 * log10(dSmallSignalGain);

		// If Reverse Model
		if(m_bAppType)
		{
			dMaxInput = sDPDLUT.m_pdMagIn[sDPDLUT.m_iLength - 1];
		}
		else
		{
			dMaxInput = sPALUT.m_pdMagIn[sPALUT.m_iLength - 1];
		}

		csMessage.Format(_T("Maximum Input Power for %s %s is %lf.\nSmall Signal Gain used is %lf."), TypeNameToString(m_bAppType), TypeNameToString(m_eModelType), dMaxInput, dSmallSignalGain);
		AfxMessageBox(csMessage);

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_MAGGAINPHASE(sPALUT);
		SAFE_DELETE_MAGGAINPHASE(sDPDLUT);

		throw;
	}
	
	SAFE_DELETE_MAGGAINPHASE(sPALUT);
	SAFE_DELETE_MAGGAINPHASE(sDPDLUT);

	return;
}
