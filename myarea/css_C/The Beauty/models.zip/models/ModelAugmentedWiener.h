/// \file ModelAugmentedWiener.h
/// Header file for class ModelAugmentedWiener

#pragma once

#include "ModelWiener.h"

/// \class ModelAugmentedWiener
/// class for AugmentedWiener model
class ModelAugmentedWiener : public ModelWiener
{
public:
	ModelAugmentedWiener(void);
	~ModelAugmentedWiener(void);
	void RunModel(void);

private:

};
