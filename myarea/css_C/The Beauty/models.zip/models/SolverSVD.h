/// \file SolverSVD.h
/// Header file for solving models using SVD


#pragma once
#include "SolverBaseClass.h"
#include "f2c.h"

/// \class SolverSVD
/// Solves models using SVD method (pinv in MATLAB)
class SolverSVD : public SolverBaseClass
{
public:
	SolverSVD(void);
	~SolverSVD(void);
	void SolveMatrix();
private:
	doublecomplex* RowColumnSwap(doublecomplex* prgdcMatrix, int iRowLength, int iColumnLength);
	//void SolveMatrixSVD();
};
