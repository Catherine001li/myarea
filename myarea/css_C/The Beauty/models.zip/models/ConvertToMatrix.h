/// \file ConvertToMatrix.h
/// Header file for converting data to matrix format using various methods


#pragma once

#include "ModelBaseClass.h"


/// Model type enumeration.
/// Type of Conversion to Perform
typedef enum eConversionType
{
	CONVERSION_UNKNOWN = -1,		///< Unknown conversion / conversion not supported
	CONVERSION_POLYSEA1 = 0,		///< Polynomial conversion
	CONVERSION_X2_FIRA1,			///< Augmented conversion (2 FIRs)
	CONVERSION_POLYA1,				///< Polynomial conversion
	CONVERSION_NONREV_POLYLSE_FULL,	///< Nonreversed polynomial conversion
	CONVERSION_COUNT				///< Number of Conversion Types
} CONVERSION_TYPE;


/// \class ConvertToMatrix
/// applies matrix conversions to the input data
class ConvertToMatrix
{
public:
	ConvertToMatrix(void);
	~ConvertToMatrix(void);

	void Run(void);

	void SetInputX(doublecomplex* pcdInputX, int iLength);
	void SetInputX1(doublecomplex* pcdInputX1, int iLength);
	void SetOutputY(doublecomplex* pcdOutputY, int iLength);
	void SetParameters(int iTaps, int iOrder, CONVERSION_TYPE eConvert);
	int GetResultLength();
	doublecomplex* GetResultX(int* piLength = NULL);
	doublecomplex* GetResultY(int* piLength = NULL);
	doublecomplex* GetResultAMatrix(int* piRows = NULL, int* piCols = NULL);

private:
	doublecomplex* m_pcdInputX1;	///< Input X1
	int m_iLengthInputX1;			///< Length of Input X1
	doublecomplex* m_pcdInputX;		///< Input X
	int m_iLengthInputX;			///< Length of Input X
	doublecomplex* m_pcdOutputY;	///< Output Y
	int m_iLengthOutputY;			///< Length of Output Y

	doublecomplex* m_pcdAMatrix;	///< The A Matrix
	int m_iRowsA;					///< Number of rows for A
	int m_iColsA;					///< Number of cols for A

	doublecomplex* m_pcdResultX;	///< The result X
	doublecomplex* m_pcdResultY;	///< The result Y

	int m_iResultLength;			///< Length of result vectors

	int m_iTaps;					///< Number of Taps
	int m_iOrder;					///< Orders
	CONVERSION_TYPE m_eConvert;		///< The conversion type

	void ConvertToPolyLSE();
	void ConvertToX2FIR();
	void ConvertToPolyLSERecreate();

};
