/// \file SolverQRRLS.cpp
/// Implementation file for solving models using QRRLS


#include "stdafx.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include "SolverQRRLS.h"
#include "SolverBaseClass.h"
#include "f2c.h"
#include "clapack.h"
#include "..\nsmfunctions.h"
#include "..\MATLAB\MatlabFunctions.h"
#include "..\MyExceptionTrace.h"

////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for SolverQRRLS.
/// Calls base class constructor SolverBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
SolverQRRLS::SolverQRRLS(void) : SolverBaseClass()
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for SolverQRRLS
/// Implicitly calls SolverBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
SolverQRRLS::~SolverQRRLS(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Solves according to input parameters specified...
///
////////////////////////////////////////////////////////////////////////////////////
void SolverQRRLS::SolveMatrix()
{
	if(m_bComplex)
	{
		QRRLSAlgComplex();
	}
	else
	{
		EXCEPTION_ADDUSERMESSAGE(_T("Non Complex not supported yet"));
		AfxThrowUserException();
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the QRRLS algorithm (with input parameters being complex valued)
///
////////////////////////////////////////////////////////////////////////////////////
void SolverQRRLS::QRRLSAlgComplex(void)
{
	int iNumCoefficients;
	doublecomplex* pcdQRMatrix = NULL;
	int iRowIndex, iColIndex, iIndex;
	doublecomplex cdDesired;
	doublecomplex* pcdA;
	doublecomplex* pcdX;
	doublecomplex* pcdB;
	int iOffset;

	try
	{
		pcdA = (doublecomplex*) m_pdA;
		pcdB = (doublecomplex*) m_pdB;
		pcdX = (doublecomplex*) m_pdX;

		iNumCoefficients = m_iCols;

		// Initialize the QR matrix (Always iNumCoefficients + 1)
		pcdQRMatrix = new doublecomplex[(iNumCoefficients + 1) * (iNumCoefficients + 1)];
		for(iRowIndex = 0; iRowIndex < iNumCoefficients + 1; iRowIndex++)
		{
			for(iColIndex = 0; iColIndex < (iNumCoefficients + 1); iColIndex++)
			{
				iIndex = iRowIndex * (iNumCoefficients + 1) + iColIndex;
				if(iRowIndex == iColIndex)
				{
					pcdQRMatrix[iIndex].r = m_dDelta;
				}
				else
				{
					pcdQRMatrix[iIndex].r = 0.0;	
				}
				pcdQRMatrix[iIndex].i = 0.0;
			}
		}

		// Execute for whole length of y
		// Keep passing in the row of A, and the desired 'y'
		iOffset = 0;
		for(iIndex = 0; iIndex < m_iRows; iIndex++)
		{
			cdDesired.r = pcdB[iIndex].r;
			cdDesired.i = pcdB[iIndex].i;

			QRDRLSGivens(pcdQRMatrix, &pcdA[iOffset], cdDesired, m_dLambda);
			iOffset = iOffset + iNumCoefficients;
		}

		// Perform Back Substitution on the matrix
		BackSubstitution(pcdQRMatrix, pcdX);
	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pcdQRMatrix);

		throw;
	}

	SAFE_DELETE_ARRAY(pcdQRMatrix);

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the QR-RLS Algorithm using Givens Rotation
///
/// \param pcdQRMatrix the matrix to apply given's rotation
/// \param pcdInputX Tap-Input Vector
/// \param cdDesired the desired signal
/// \param dLambda the forgetting factor
///
////////////////////////////////////////////////////////////////////////////////////
void SolverQRRLS::QRDRLSGivens(doublecomplex* pcdQRMatrix, doublecomplex* pcdInputX, doublecomplex cdDesired, double dLambda)
{
	int iIndex;
	int iQRMatIndex;
	int iQRMatPos;
	int iQRMatCosPos;
	int iQRMatSinPos;
	int iQRMatLength;			// M + 1, need to store for lapack routine
		
	doublecomplex cdGivensF;
	doublecomplex cdGivensG;
	double dGivensCos;
	doublecomplex cdGivensCos;
	doublecomplex cdGivensSin;
	
	
	iQRMatLength = m_iCols + 1;	// Length of one side of square matrix QR
	
	// Update previous matrix by Lambda
	// Remember the QRMatrix is a M+1, M+1 Matrix
	// Don't update last row (not needed)
	for(iQRMatIndex = 0; iQRMatIndex < m_iCols * iQRMatLength; iQRMatIndex++)
	{
		pcdQRMatrix[iQRMatIndex].r = pcdQRMatrix[iQRMatIndex].r * dLambda;
		pcdQRMatrix[iQRMatIndex].i = pcdQRMatrix[iQRMatIndex].i * dLambda;
	}
	
	// Stuff X into bottom vector
	for(iIndex = 0; iIndex < m_iCols; iIndex++)
	{
		pcdQRMatrix[iQRMatIndex].r = pcdInputX[iIndex].r;
		pcdQRMatrix[iQRMatIndex].i = pcdInputX[iIndex].i;
		iQRMatIndex++;
	}
	
	// Put desired into last element QR(M+1, M+1)
	pcdQRMatrix[iQRMatIndex].r = cdDesired.r;
	pcdQRMatrix[iQRMatIndex].i = cdDesired.i;
	
	
	// Perform Series of Givens Rotations on the last vector (X).
	for(iIndex = 0; iIndex < m_iCols; iIndex++)
	{
		// F is the part in the diagonal
		iQRMatCosPos = iIndex * iQRMatLength;
		iQRMatPos = iQRMatCosPos + iIndex;
		cdGivensF.r = pcdQRMatrix[iQRMatPos].r;
		cdGivensF.i = pcdQRMatrix[iQRMatPos].i;
		
		// G is at the bottom (X Vector), value to nullify
		iQRMatSinPos = m_iCols * iQRMatLength;
		iQRMatPos = iQRMatSinPos + iIndex;
		cdGivensG.r = pcdQRMatrix[iQRMatPos].r;
		cdGivensG.i = pcdQRMatrix[iQRMatPos].i;
		
		// Only for debugging, set to 0 before calling
		cdGivensCos.r = 0;
		cdGivensCos.i = 0;
		cdGivensSin.r = 0;
		cdGivensSin.i = 0;
		
		// Perform Givens
		GivensRotation(&cdGivensF, &cdGivensG, &cdGivensCos, &cdGivensSin);
		
		ApplyGivens(&pcdQRMatrix[iQRMatCosPos], &pcdQRMatrix[iQRMatSinPos], iQRMatLength, cdGivensCos, cdGivensSin);
		
		// Force current element to 0
		// Sometimes, the multiplication of the two complex numbers will not equal 0.
		pcdQRMatrix[iQRMatSinPos + iIndex].r = 0.0;
		pcdQRMatrix[iQRMatSinPos + iIndex].i = 0.0;
	}
	
	
	return;	
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Applies the Given's rotation on the two required vectors
///
/// \param pcdX address of the first vector
/// \param pcdY address of the second vector
/// \param iLength length of the row vectors
/// \param cdCos Given's rotation parameter 1
/// \param cdSin Given's rotation parameter 2
///
////////////////////////////////////////////////////////////////////////////////////
void SolverQRRLS::ApplyGivens(doublecomplex* pcdX, doublecomplex* pcdY, int iLength, doublecomplex cdCos, doublecomplex cdSin)
{
	int iIndex;
	doublecomplex cdTempX, cdTempY;
	doublecomplex cdUpdateX, cdUpdateY;
	
	for(iIndex = 0;	iIndex < iLength; iIndex++)
	{
		cdTempX.r = pcdX[iIndex].r;
		cdTempX.i = pcdX[iIndex].i;
		cdTempY.r = pcdY[iIndex].r;
		cdTempY.i = pcdY[iIndex].i;
		
		// Calculate Update X
		// X = Cos * X + Sin * Y
		cdUpdateX.r = ((cdCos.r * cdTempX.r) - (cdCos.i * cdTempX.i)) +
					  ((cdSin.r * cdTempY.r) - (cdSin.i * cdTempY.i));
		
		cdUpdateX.i = ((cdCos.r * cdTempX.i) + (cdCos.i * cdTempX.r)) +
					  ((cdSin.r * cdTempY.i) + (cdSin.i * cdTempY.r));
		
		// Calculate Temp Y
		// Y = -conj(Sin) * X + conj(Cos) * Y
		cdUpdateY.r = (-(cdSin.r * cdTempX.r) - (cdSin.i * cdTempX.i)) +
					  ((cdCos.r * cdTempY.r) + (cdCos.i * cdTempY.i));		
		
		cdUpdateY.i = (-(cdSin.r * cdTempX.i) + (cdSin.i * cdTempX.r)) +
					  ((cdCos.r * cdTempY.i) - (cdCos.i * cdTempY.r));
		// Store Back
		pcdX[iIndex].r = cdUpdateX.r;
		pcdX[iIndex].i = cdUpdateX.i;
		
		pcdY[iIndex].r = cdUpdateY.r;
		pcdY[iIndex].i = cdUpdateY.i;
		
	}
	
	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Performs a complex divide by
/// cdA / cdB = (cdA * conj(cdB)) / (cdB * conj(cdB))
/// 
/// \param cdA numerator
/// \param cdB denominator
/// \returns divided output
///
////////////////////////////////////////////////////////////////////////////////////
doublecomplex SolverQRRLS::ComplexDivide(doublecomplex cdA, doublecomplex cdB)
{	
	double dDivide;
	doublecomplex cdC;

	// multiply by conjugates on both to divide
	cdC.r = (cdA.r * cdB.r) + (cdA.i * cdB.i);
	cdC.i = (cdA.i * cdB.r) - (cdA.r * cdB.i);
	
	dDivide = (cdB.r * cdB.r) + (cdB.i * cdB.i);
	
	// Store back
	cdC.r = cdC.r / dDivide;
	cdC.i = cdC.i / dDivide;

	return cdC;	
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Compute proper Given's rotation parameters.
///	Computes equivalent of planerot([pcdF; pcdG]) in matlab, essentially.
/// pcdCos = pcdF / abs(pcdF.^2 + pcdG.^2).
/// pcdSin = pcdG / abs(pcdF.^2 + pcdG.^2).
/// 
/// \param pcdF value on the diagonal
/// \param pcdG value to nullify
/// \param pcdCos output cosine parameter
/// \param pcdSin output sine parameter
///
////////////////////////////////////////////////////////////////////////////////////
void SolverQRRLS::GivensRotation(doublecomplex* pcdF, doublecomplex* pcdG, doublecomplex* pcdCos, doublecomplex* pcdSin)
{
	double dDivide;
	double dMagF;
	double dMagG;
	
	// Find absolute
	dMagF = pcdF->r * pcdF->r + pcdF->i * pcdF->i;
	dMagG = pcdG->r * pcdG->r + pcdG->i * pcdG->i;
	
	dDivide = sqrt(dMagF + dMagG);
	
	// Matlab is a conjugate!
	// Output cosines
	pcdCos->r = pcdF->r / dDivide;
	pcdCos->i = (-1.0) * pcdF->i / dDivide;
	
	// Output sines
	pcdSin->r = pcdG->r / dDivide;
	pcdSin->i = (-1.0) * pcdG->i / dDivide;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Coefficient Generation for QR Algorithm (Back Substitution)
///
/// \param pcdQRMatrix matrix for utilizing QR
/// \param pcdCoeffs output vector for coefficients 
///
////////////////////////////////////////////////////////////////////////////////////
void SolverQRRLS::BackSubstitution(doublecomplex* pcdQRMatrix, doublecomplex* pcdCoeffs)
{
	int iCoeffIndex;
	int iIndex;
	int iMatRPos;
	int iMatYPos;
	int iMatROffset;
	int iMatCoeffOffset;
	doublecomplex cdZi;
	doublecomplex cdYiZi;
	doublecomplex cdTempResult;
	doublecomplex cdRii;
	doublecomplex cdRij;
	doublecomplex cdaj;
	double dDivide;
	
	for(iCoeffIndex = m_iCols; iCoeffIndex > 0; iCoeffIndex--)
	{
		// Initialize Accum
		cdZi.r = 0;
		cdZi.i = 0;
		
		// Index the current Row,of R
		//iMatRPos = iCoeffIndex * (MB_NUM_UNKNOWN_COEFF + 1) + iCoeffIndex;
		iMatRPos = (iCoeffIndex - 1) * (m_iCols + 1) + (iCoeffIndex - 1);
		
		iMatROffset = iMatRPos + 1;
		iMatCoeffOffset = iCoeffIndex;
		
		// Calculate Zi
		for(iIndex = iCoeffIndex; iIndex < m_iCols; iIndex++)
		{
			// MatrixOffsets (should use iIndex, can't figure out math)
			cdRij.r = pcdQRMatrix[iMatROffset].r;
			cdRij.i = pcdQRMatrix[iMatROffset].i;
			
			cdaj.r = pcdCoeffs[iMatCoeffOffset].r;
			cdaj.i = pcdCoeffs[iMatCoeffOffset].i;
			
			// Multiply and Accumulate
			cdZi.r = cdZi.r + ((cdRij.r * cdaj.r) - (cdRij.i * cdaj.i));
			cdZi.i = cdZi.i + ((cdRij.r * cdaj.i) + (cdRij.i * cdaj.r));

//			CMLTACCUM(pcdQRMatrix[iMatROffset], prgcdCoeffs[iMatCoeffOffset], cdZi);
			
			iMatROffset++;
			iMatCoeffOffset++;
		}
		
		// Index the y vector
		iMatYPos = (iCoeffIndex * (m_iCols + 1)) - 1;
		
		
		// yi - Zi
		cdYiZi.r = pcdQRMatrix[iMatYPos].r - cdZi.r;
		cdYiZi.i = pcdQRMatrix[iMatYPos].i - cdZi.i;
		
		// Divide by the R Position
		cdRii.r = pcdQRMatrix[iMatRPos].r;
		cdRii.i = pcdQRMatrix[iMatRPos].i;
		
		// multiply by conjugates on both to divide
		cdTempResult.r = (cdYiZi.r * cdRii.r) + (cdYiZi.i * cdRii.i);
		cdTempResult.i = (cdYiZi.i * cdRii.r) - (cdYiZi.r * cdRii.i);
//		CMLTCNJ2(cdYiZi, cdRii, cdTempResult);
		
		dDivide = (cdRii.r * cdRii.r) + (cdRii.i * cdRii.i);
		
		// waste of a couple of clock cycles.
		cdTempResult.r = cdTempResult.r / dDivide;
		cdTempResult.i = cdTempResult.i / dDivide;
		
		iMatCoeffOffset = iCoeffIndex - 1;
		
		// Store back
		pcdCoeffs[iMatCoeffOffset].r = cdTempResult.r;
		pcdCoeffs[iMatCoeffOffset].i = cdTempResult.i;
		
	}
	
	return;
}
