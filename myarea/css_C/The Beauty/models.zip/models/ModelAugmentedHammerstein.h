/// \file ModelAugmentedHammerstein.h
/// Header file for class ModelAugmentedHammerstein

#pragma once

#include "ModelHammerstein.h"

/// \class ModelAugmentedHammerstein
/// class for AugmentedHammerstein model
class ModelAugmentedHammerstein : public ModelHammerstein
{
public:
	ModelAugmentedHammerstein(void);
	~ModelAugmentedHammerstein(void);
	void RunModel(void);

private:

};
