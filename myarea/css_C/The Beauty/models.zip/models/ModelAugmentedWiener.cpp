/// \file ModelAugmentedWiener.cpp
/// Implementation file for class ModelAugmentedWiener

#include "stdafx.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include "ModelAugmentedWiener.h"
#include "..\MyExceptionTrace.h"
#include "..\nsmfunctions.h"
#include "..\matlab\MatlabFunctions.h"


////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for ModelAugmentedWiener.
/// Calls base class constructor ModelBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
ModelAugmentedWiener::ModelAugmentedWiener(void) : ModelWiener()
{
	// Set Model Type
	m_eModelType = MODEL_AUGMENTED_WIENER;
	m_csModelType = TypeNameToString(m_eModelType);
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for ModelAugmentedWiener.
/// Implicitly calls ModelBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
ModelAugmentedWiener::~ModelAugmentedWiener(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the ModelAugmentedWiener model.
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/solveFilter.m"> solveFilter.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelAugmentedWiener::RunModel(void)
{
	try
	{
		// Open Files
		OpenFiles();

		// Call Generate LUT
		GenerateLUT();

		// Extract the training data for the memory filters
		ExtractWienerMemoryEffects();

		// Run Filter Identification
		FilterIdentification();

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}

