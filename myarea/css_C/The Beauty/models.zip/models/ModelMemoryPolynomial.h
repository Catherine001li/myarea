/// \file ModelMemoryPolynomial.h
/// Header file for class MemoryPolynomial

#pragma once

#include "ModelBaseClass.h"
//#include "..\global.h"
#include "f2c.h"

/// \class ModelMemoryPolynomial
/// class for Memory Polynomial model
class ModelMemoryPolynomial : public ModelBaseClass
{
public:
	ModelMemoryPolynomial(void);
	~ModelMemoryPolynomial(void);
	void RunModel(void);

protected:
	//void GenerateMatrix(double* pdXinI, double* pdXinQ, double* pdYinI, double* pdYinQ, int iLength, doublecomplex* pcdA, doublecomplex* pcdX1, doublecomplex* pcdY1);
	//void GenerateMatrixA(double* pdXinI, double* pdXinQ, int iLength, int iTaps, int iOrder, bool bDoubleComplex, doublecomplex* pcdA);
	void CreateLUTMemoryPolynomial(doublecomplex* pcdXin, int iRows, doublecomplex* pcdCoeffs, int iCols);
//	void SetupOutputNames(void);

	void SaveLUTResults(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, CString csFileHeader, double dPinCutTh);
private:


	int m_iTraining;						///< Training Variable (MM in MATLAB)
};
