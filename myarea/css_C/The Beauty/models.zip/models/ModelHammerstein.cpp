/// \file ModelHammerstein.cpp
/// Implementation file for class ModelHammerstein

#include "stdafx.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include "ModelHammerstein.h"
#include "..\MyExceptionTrace.h"
#include "..\nsmfunctions.h"
#include "..\matlab\MatlabFunctions.h"
#include "..\resource.h"
#include "..\NtGraphDialog.h"

////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for ModelHammerstein.
/// Calls base class constructor ModelBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
ModelHammerstein::ModelHammerstein(void) : ModelFilterBaseClass()
{
	// Set Model Type
	m_eModelType = MODEL_HAMMERSTEIN;
	m_csModelType = TypeNameToString(m_eModelType);
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for ModelHammerstein.
/// Implicitly calls ModelBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
ModelHammerstein::~ModelHammerstein(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Executes the Hammerstein model.
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/solveFilter.m"> solveFilter.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelHammerstein::RunModel(void)
{
	try
	{
		// Open Files
		OpenFiles();

		// Call Generate LUT
		GenerateLUT();

		// Extract the training data for the memory filters
		ExtractHammersteinMemoryEffects();

		// Run Filter Identification
		FilterIdentification();

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);
		throw;
	}

	return;
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Extracts the Hammerstein Effects from the data
///
///
/// Reference MATLAB files:
/// - <a href = "../../NonlinearSystemModeler/NSM/extractHammerstainMemoryEffectsData.m"> extractHammerstainMemoryEffectsData.m </a>
///
////////////////////////////////////////////////////////////////////////////////////
void ModelHammerstein::ExtractHammersteinMemoryEffects()
{
	double dLinearGain;
	double dPhaseOffset;
	double dPhaseOffsetDPD;
	double dPhaseOffsetpostDPD;
	
	double dOffsetIn;
	double dOffsetOut;

	doublecomplex* pcdDataIn = NULL;
	doublecomplex* pcdDataOut = NULL;

	double* pdMagIn = NULL;
	double* pdMagOut = NULL;
	double* pdGain = NULL;
	double* pdGaindB = NULL;
	double* pdPhaseRad = NULL;
	double* pdPhaseTemp = NULL;
	double* pdPhaseRadShift = NULL;

	MAGGAINPHASE sInputLUT = MAGGAINPHASE_INIT;
	MAGGAINPHASE sInputLUTdB = MAGGAINPHASE_INIT;
	MAGGAINPHASE sOutputAfterLUT = MAGGAINPHASE_INIT;
	
	double* pdGainFilter = NULL;
	double* pdGainFilterdB = NULL;
	double* pdPhaseFilter = NULL;
	double* pdGainAfterLUT = NULL;

	doublecomplex* pcdX = NULL;
	double* pdReal = NULL;
	double* pdImag = NULL;

	CString csFilename;

	int iLength;
	int iDataNumLim;
	int iTruncateLength;
	int iStartIndex;

	int iIndex;

	// If the Extract Filter box has not been checked, exit.
	if(!m_iExtractFilter)
	{
		return;
	}

	try
	{
		// Load the linear gain file
		GetSmallSignalParameters(&dLinearGain, &dPhaseOffset, &dPhaseOffsetDPD, &dPhaseOffsetpostDPD);
		
		iLength = m_iLength;
		pcdDataIn = new doublecomplex[iLength];
		pcdDataOut = new doublecomplex[iLength];

		dOffsetIn = pow(10, m_dInputAttenuation / 20.0);
		dOffsetOut = pow(10, m_dOutputAttenuation / 20.0);

		// if DPD, reverse
		if(m_bAppType)
		{
			for(iIndex = 0; iIndex < iLength; iIndex++)
			{
				pcdDataOut[iIndex].r = m_pdInputI[iIndex] * dOffsetIn;
				pcdDataOut[iIndex].i = m_pdInputQ[iIndex] * dOffsetIn;
				pcdDataIn[iIndex].r = m_pdOutputI[iIndex] * dOffsetOut / dLinearGain;
				pcdDataIn[iIndex].i = m_pdOutputQ[iIndex] * dOffsetOut / dLinearGain;
			}
		}
		else
		{
			for(iIndex = 0; iIndex < iLength; iIndex++)
			{
				pcdDataIn[iIndex].r = m_pdInputI[iIndex] * dOffsetIn;
				pcdDataIn[iIndex].i = m_pdInputQ[iIndex] * dOffsetIn;
				pcdDataOut[iIndex].r = m_pdOutputI[iIndex] * dOffsetOut;
				pcdDataOut[iIndex].i = m_pdOutputQ[iIndex] * dOffsetOut;
			}
		}

		// Remove the first 1K data
		iStartIndex = 1000;
		for(iIndex = iStartIndex; iIndex < iLength; iIndex++)
		{
			pcdDataIn[iIndex - iStartIndex].r = pcdDataIn[iIndex].r;
			pcdDataIn[iIndex - iStartIndex].i = pcdDataIn[iIndex].i;
			pcdDataOut[iIndex - iStartIndex].r = pcdDataOut[iIndex].r;
			pcdDataOut[iIndex - iStartIndex].i = pcdDataOut[iIndex].i;
		}
		iLength = iLength - iStartIndex;

		// Find Truncation Length
		iDataNumLim = 30000;
		if(iLength > iDataNumLim)
		{
			iTruncateLength = iDataNumLim;
		}
		else
		{
			iTruncateLength = iLength;
		}

		// Truncate Input/Output (just rewrite the length variable)
		iLength = iTruncateLength;

		pdMagIn = new double[iLength];
		pdMagOut = new double[iLength];
		MatlabAbs(pcdDataIn, pdMagIn, iLength);
		MatlabAbs(pcdDataOut, pdMagOut, iLength);

		pdGain = new double[iLength];
		VectorDivide(pdMagOut, pdMagIn, iLength, pdGain);

		pdPhaseTemp = new double[iLength];
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			pdPhaseTemp[iIndex] = atan2(pcdDataIn[iIndex].r * pcdDataOut[iIndex].i - pcdDataOut[iIndex].r * pcdDataIn[iIndex].i,
										pcdDataIn[iIndex].r * pcdDataOut[iIndex].r + pcdDataIn[iIndex].i * pcdDataOut[iIndex].i);
		}

		pdPhaseRad = new double[iLength];
		MatlabUnwrap(pdPhaseTemp, pdPhaseRad, iLength);

		// Load the PA/DPD LUT Model Data
		pdPhaseRadShift = new double[iLength];
		if(m_bAppType)
		{
			csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_REVERSE_MODEL_NAME);
			for(iIndex = 0; iIndex < iLength; iIndex++)
			{
				pdPhaseRadShift[iIndex] = pdPhaseRad[iIndex] - dPhaseOffsetDPD;
			}
		}
		else
		{
			csFilename.Format(_T("%s%s_%s_%s_MaginGainPhi_LUT.txt"), m_csFilepath, m_csSystemType, m_csSignalType, APP_TYPE_FORWARD_MODEL_NAME);
			for(iIndex = 0; iIndex < iLength; iIndex++)
			{
				pdPhaseRadShift[iIndex] = pdPhaseRad[iIndex] - dPhaseOffset;
			}
		}

		LoadLUT(csFilename, &sInputLUT);

		// Now, generate the output of the LUT according to its inputs.
		// Need to copy the Input, that way don't have to worry about multiple deletes later in code
		sOutputAfterLUT.m_iLength = iLength;
		sOutputAfterLUT.m_pdMagIn = new double[iLength];
		sOutputAfterLUT.m_pdGain = new double[iLength];
		sOutputAfterLUT.m_pdPhase = new double[iLength];
		pdGaindB = new double[iLength];
		// in dBm
		for(iIndex = 0; iIndex < iLength; iIndex++)
		{
			sOutputAfterLUT.m_pdMagIn[iIndex] = 10 * log10((0.5 * pow(pdMagIn[iIndex], 2.0)) / 50) + 30;
			pdGaindB[iIndex] = 20 * log10(pdGain[iIndex]);
		}

		// Convert the LUT to dB/dBm
		sInputLUTdB.m_iLength = sInputLUT.m_iLength;
		sInputLUTdB.m_pdMagIn = new double[sInputLUT.m_iLength];
		sInputLUTdB.m_pdGain = new double[sInputLUT.m_iLength];
		sInputLUTdB.m_pdPhase = new double[sInputLUT.m_iLength];

		for(iIndex = 0; iIndex < sInputLUT.m_iLength; iIndex++)
		{
			sInputLUTdB.m_pdMagIn[iIndex] = 10 * log10((0.5 * pow(sInputLUT.m_pdMagIn[iIndex], 2.0)) / 50) + 30;
			sInputLUTdB.m_pdGain[iIndex] = 20 * log10(sInputLUT.m_pdGain[iIndex]);
			sInputLUTdB.m_pdPhase[iIndex] = sInputLUT.m_pdPhase[iIndex];
		}

		// Call Lookup function
		InterpolationGainPhase(&sInputLUTdB, &sOutputAfterLUT);

		// Transpose
		// Extract Dynamic Gain and Phase of Linear Filter
		pdGainFilter = new double[sOutputAfterLUT.m_iLength];
		pdGainFilterdB = new double[sOutputAfterLUT.m_iLength];
		pdPhaseFilter = new double[sOutputAfterLUT.m_iLength];
		pdGainAfterLUT = new double[sOutputAfterLUT.m_iLength];

		for(iIndex = 0; iIndex < sOutputAfterLUT.m_iLength; iIndex++)
		{
			pdGainFilterdB[iIndex] = pdGaindB[iIndex] - sOutputAfterLUT.m_pdGain[iIndex];
			pdGainFilter[iIndex] = pow(10.0, (pdGainFilterdB[iIndex]) / 20.0);
			pdPhaseFilter[iIndex] = pdPhaseRadShift[iIndex] - sOutputAfterLUT.m_pdPhase[iIndex];

			pdGainAfterLUT[iIndex] = pow(10.0, (sOutputAfterLUT.m_pdGain[iIndex]) / 20.0);
		}

		pcdX = new doublecomplex[sOutputAfterLUT.m_iLength];
		pdReal = new double[sOutputAfterLUT.m_iLength];
		pdImag = new double[sOutputAfterLUT.m_iLength];

		if(!m_bAppType)
		{
			for(iIndex = 0; iIndex < sOutputAfterLUT.m_iLength; iIndex++)
			{
				doublecomplex cdTemp;
				cdTemp.r = pdGainAfterLUT[iIndex] * cos(sOutputAfterLUT.m_pdPhase[iIndex] + dPhaseOffset);
				cdTemp.i = pdGainAfterLUT[iIndex] * sin(sOutputAfterLUT.m_pdPhase[iIndex] + dPhaseOffset);

				ComplexMultiply(&pcdDataIn[iIndex], &cdTemp, &pcdX[iIndex]);
			}
		}
		else
		{
			for(iIndex = 0; iIndex < sOutputAfterLUT.m_iLength; iIndex++)
			{
				doublecomplex cdTemp;
				cdTemp.r = pdGainAfterLUT[iIndex] * cos(sOutputAfterLUT.m_pdPhase[iIndex] + dPhaseOffsetDPD);
				cdTemp.i = pdGainAfterLUT[iIndex] * sin(sOutputAfterLUT.m_pdPhase[iIndex] + dPhaseOffsetDPD);

				ComplexMultiply(&pcdDataIn[iIndex], &cdTemp, &pcdX[iIndex]);
			}
		}

		// Write to files
		if(!m_bAppType)
		{
			csFilename.Format(_T("%s%s_IQin_%s_%s_HammFilterNT.txt"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType, m_csSignalType);
		}
		else
		{
			csFilename.Format(_T("%s%s_IQin_%s_%s_HammFilterNT.txt"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType, m_csSignalType);
		}
		
		for(iIndex = 0; iIndex < sOutputAfterLUT.m_iLength; iIndex++)
		{
			pdReal[iIndex] = pcdX[iIndex].r;
			pdImag[iIndex] = pcdX[iIndex].i;
		}

		Save2ColDataToTextFile(csFilename, pdReal, pdImag, sOutputAfterLUT.m_iLength);

		if(!m_bAppType)
		{
			csFilename.Format(_T("%s%s_IQout_%s_%s_HammFilterNT.txt"), m_csFilepath, APP_TYPE_FORWARD_MODEL_NAME, m_csSystemType, m_csSignalType);
		}
		else
		{
			csFilename.Format(_T("%s%s_IQout_%s_%s_HammFilterNT.txt"), m_csFilepath, APP_TYPE_REVERSE_MODEL_NAME, m_csSystemType, m_csSignalType);
		}

		for(iIndex = 0; iIndex < sOutputAfterLUT.m_iLength; iIndex++)
		{
			pdReal[iIndex] = pcdDataOut[iIndex].r;
			pdImag[iIndex] = pcdDataOut[iIndex].i;
		}

		Save2ColDataToTextFile(csFilename, pdReal, pdImag, sOutputAfterLUT.m_iLength);

		// Mar 30/08
		// Remove plots
		// Plot Linear Filter AM/AM and AM/PM Curves
		/*
		CNtGraphDialog* pAMAM;
		CNtGraphDialog* pAMPM;
		CString csTitle;

		CREATE_NTDIALOG_MODELESS(pAMAM);
		pAMAM->AddData(sOutputAfterLUT.m_pdMagIn, pdGainFilterdB, sOutputAfterLUT.m_iLength, _T("LUT"));
		pAMAM->SetDataProperties(0, RGB(0, 0, 0), 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		csTitle = _T("AM/AM characteristics of power amplifier");
		pAMAM->SetTitle(csTitle);
		pAMAM->SetXLabel(_T("Pin (dBm)"));
		pAMAM->SetYLabel(_T("Gain (dB)"));
		pAMAM->MyAutoFixAxis();
		pAMAM->ShowLegend(0);

		for(iIndex = 0; iIndex < sOutputAfterLUT.m_iLength; iIndex++)
		{
			pdPhaseTemp[iIndex] = pdPhaseFilter[iIndex] * 180 / M_PI;
		}

		CREATE_NTDIALOG_MODELESS(pAMPM);
		pAMPM->AddData(sOutputAfterLUT.m_pdMagIn, pdPhaseTemp, sOutputAfterLUT.m_iLength, _T("LUT"));
		pAMPM->SetDataProperties(0, RGB(0, 0, 0), 2, CNtgraphctrl1::Null, CNtgraphctrl1::Dots);

		csTitle = _T("AM/PM characteristics of power amplifier");
		pAMPM->SetTitle(csTitle);
		pAMPM->SetXLabel(_T("Pin (dBm)"));
		pAMPM->SetYLabel(_T("Phase (degree)"));
		pAMPM->MyAutoFixAxis();
		pAMPM->ShowLegend(0);
		*/

	}
	catch(CException* pEx)
	{
		EXCEPTION_ADDTRACE(pEx);

		SAFE_DELETE_ARRAY(pcdDataIn);
		SAFE_DELETE_ARRAY(pcdDataOut);

		SAFE_DELETE_ARRAY(pdMagIn);
		SAFE_DELETE_ARRAY(pdMagOut);
		SAFE_DELETE_ARRAY(pdGain);
		SAFE_DELETE_ARRAY(pdGaindB);
		SAFE_DELETE_ARRAY(pdPhaseRad);
		SAFE_DELETE_ARRAY(pdPhaseTemp);

		SAFE_DELETE_MAGGAINPHASE(sInputLUT);
		SAFE_DELETE_MAGGAINPHASE(sInputLUTdB);
		SAFE_DELETE_MAGGAINPHASE(sOutputAfterLUT);
		
		SAFE_DELETE_ARRAY(pdGainFilter);
		SAFE_DELETE_ARRAY(pdGainFilterdB);
		SAFE_DELETE_ARRAY(pdPhaseFilter);
		SAFE_DELETE_ARRAY(pdGainAfterLUT);
		SAFE_DELETE_ARRAY(pdReal);
		SAFE_DELETE_ARRAY(pdImag);

		SAFE_DELETE_ARRAY(pdPhaseRadShift);
		SAFE_DELETE_ARRAY(pcdX);

		throw;
	}

	// Epilogue
	SAFE_DELETE_ARRAY(pcdDataIn);
	SAFE_DELETE_ARRAY(pcdDataOut);

	SAFE_DELETE_ARRAY(pdMagIn);
	SAFE_DELETE_ARRAY(pdMagOut);
	SAFE_DELETE_ARRAY(pdGain);
	SAFE_DELETE_ARRAY(pdGaindB);
	SAFE_DELETE_ARRAY(pdPhaseRad);
	SAFE_DELETE_ARRAY(pdPhaseTemp);

	SAFE_DELETE_MAGGAINPHASE(sInputLUT);
	SAFE_DELETE_MAGGAINPHASE(sInputLUTdB);
	SAFE_DELETE_MAGGAINPHASE(sOutputAfterLUT);
	
	SAFE_DELETE_ARRAY(pdGainFilter);
	SAFE_DELETE_ARRAY(pdGainFilterdB);
	SAFE_DELETE_ARRAY(pdPhaseFilter);
	SAFE_DELETE_ARRAY(pdGainAfterLUT);
	SAFE_DELETE_ARRAY(pdReal);
	SAFE_DELETE_ARRAY(pdImag);

	SAFE_DELETE_ARRAY(pdPhaseRadShift);

	SAFE_DELETE_ARRAY(pcdX);

	return;
}
