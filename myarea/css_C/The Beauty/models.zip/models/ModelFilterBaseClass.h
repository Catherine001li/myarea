/// \file ModelFilterBaseClass.h
/// Header file for class ModelFilterBaseClass

#pragma once

#include "ModelBaseClass.h"
//#include "..\global.h"
#include "f2c.h"

/// \class ModelFilterBaseClass
/// base class for filter models
class ModelFilterBaseClass : public ModelBaseClass
{
public:
	ModelFilterBaseClass(void);
	~ModelFilterBaseClass(void);
	virtual void RunModel(void) = 0;		///< Virutal Function

	CString GetLinearGainFilename();

protected:
	void GenerateLUT(void);
//	void SetupOutputNames(void);
	void FilterIdentification(void);
	void InterpolationGainPhase(MAGGAINPHASE* psInitialLUT, MAGGAINPHASE* psOutput);
	bool m_bSmallSignalGain;					///< True if calculating small signal gain
private:
	int m_iTraining;							///< Training Variable
//	CString m_csPostDPDLUTFilename;				///< Post DPD Filename
//	CString m_csAddressNormalizationFilename;	///< Address Normalization Filename
//	CString m_csPALUTGainPhaseFilename;			///< PA LUT with Gain/Phase Filename
//	CString m_csDPDLUTGainPhaseFilename;		///< DPD LUT with Gain/Phase Filename
//	CString m_csDPDLUTIQFilename;				///< DPD LUT with I/Q Filename
//	CString m_csPostDPDLUTGainPhaseFilename;	///< PostDPD LUT with Gain/Phase Filename
//	CString m_csPostDPDLUTIQFilename;			///< PostDPD LUT with Gain/Phase Filename
//	CString m_csDPDADSFilename;					///< ADS filename for DPD
//	CString m_csPAADSFilename;					///< ADS filename for PA
//	CString m_csPALUTADSFilename;				///< ADS filename for PA LUT
//	CString m_csDPDLUTADSFilename;				///< ADS filename for DPD LUT
//	CString m_csPostDPDLUTADSFilename;			///< ADS filename for Post DPD LUT
	
//	CString m_csLinearGainFilename;				///< Linear Gain Filename

	void GenerateLUTwithEWMA(void);
	void GenerateLUTwithPoly(void);

	int ExtractModelTrainingData(doublecomplex* pcdInput,doublecomplex* pcdOutput, int iLength, int iNumTrainingData, doublecomplex* pcdXtrained, doublecomplex* pcdYtrained, int iComputeLength = 0);
	void DeembedNonlinearityDEWMA(int iMATimes, doublecomplex* pcdXTrained, doublecomplex* pcdYTrained, int iTrainedLength, int iLUTSize, double dPinThreshdB, MAGGAINPHASE* psOutputLUT, double* pdPhaseOffset);
	void DeembedNonlinearityLSE(int iTaps, int iOrder, doublecomplex* pcdXTrained, doublecomplex* pcdYTrained, int iTrainedLength, double dPinThreshdB, MAGGAINPHASE* psOutputLUT, double* pdPhaseOffset, doublecomplex* pcdCoeffs);
	void TimeToPowerDomain(double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double dInterval, double* pdMagInPdDs, double* pdGainPdDs, double* pdPhasePdDs, int* piDownsampledLength);
	void DownsamplingBasedOnInterval(double dInterval, double* pdMagInPd, double* pdGainPd, double* pdPhasePd, int iLength, double* pdMagInPdDs, double* pdGainPdDs, double* pdPhasePdDs, int* piDownsampledLength);
	void DEWMA(double* pdX, double* pdY, int iLength, double* pdOutput);
	void Derive(double* pdX, double* pdY, int iLength, double* pddX, double* pddY);
	void SaveLUTwithPhaseOffset(CString csFilename, double* pdMagIn, double* pdGain, double* pdPhase, int iLength, double dPhaseOffset);
	void SavePhaseOffset(double dGainLinear, double dPhaseOffset, double dPhaseOffsetDPD, double dPhaseOffsetPostDPD);
	void SaveNormalizationParameters(double dAmpPA, double dOffsetPA, double dMaxMagInPALUT, double dUpperBoundPA, double dAmpDPD, double dOffsetDPD, double dMaxMagInDPDLUT, double dUpperBoundDPD);
	void SaveBasebandADSFile(CString csFilename, double* pdI, double* pdQ, int iLength);

	void SaveMDFGainStartingPoint(CString csFilename, double dDPDGainOffset, double dPAGainOffset, double dPostDPDGainOffset = 0);
	void SaveLUTADS(CString csFilename, double* pdMagIn, double* pdGain, double* pdPhase, int iLength);
	void TrainMBPoly(doublecomplex* pcdDataIn, doublecomplex* pcdDataOut, int iLength, int iMM, int iOrder);
	void TrainX2FIR(doublecomplex* pcdDataIn, doublecomplex* pcdDataOut, int iLength, int iMM, int iOrder);

	void PolyLSESolver(int iTaps, int iOrder, doublecomplex* pcdXin, doublecomplex* pcdYin, int iInputLength, doublecomplex* pcdXout, doublecomplex* pcdYout, doublecomplex* pcdCoeffs);
	void SaveNNFiles(MAGGAINPHASE* psPALUT, MAGGAINPHASE* psDPDLUT);
public:
	void GenerateDPD(MAGGAINPHASE& rsPALUT, MAGGAINPHASE& rsDPDLUT, double dLUTTruncate, double dSmallSignalGain, double dSmallSignalPhase, int iLUTSize);
	void PlotMemoryless(doublecomplex* pcdInput, doublecomplex* pcdOutput, int iLength, MAGGAINPHASE& rsPALUT, MAGGAINPHASE& rsDPDLUT, MAGGAINPHASE& rsPostDPDLUT, double dSmallSignalGain, double dPhaseOffsetPA, double dPhaseOffsetDPD, double dPhaseOffsetPostDPD);
};
