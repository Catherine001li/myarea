/// \file ModelWiener.h
/// Header file for class ModelWiener

#pragma once

#include "ModelFilterBaseClass.h"
#include "ModelBaseClass.h"

/// \class ModelWiener
/// class for Wiener model
class ModelWiener : public ModelFilterBaseClass
{
public:
	ModelWiener(void);
	~ModelWiener(void);
	void RunModel(void);

protected:
	void ExtractWienerMemoryEffects();
private:

};
