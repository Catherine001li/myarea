/// \file SolverSVD.cpp
/// Implementation file for solving models using SVD


#include "stdafx.h"
#include "SolverSVD.h"
#include "SolverBaseClass.h"
#include "f2c.h"
#include "clapack.h"
#include "..\nsmfunctions.h"
#include "..\MATLAB\MatlabFunctions.h"

////////////////////////////////////////////////////////////////////////////////////
///
/// Prototype for zgelss_
///
////////////////////////////////////////////////////////////////////////////////////
extern "C" void zgelss_(integer*, integer*, integer*, doublecomplex*, integer*, doublecomplex*, integer*, doublereal*, doublereal*, integer*, doublecomplex*, integer*, doublereal*, integer*);

////////////////////////////////////////////////////////////////////////////////////
///
/// Default constructor for SolverSVD.
/// Calls base class constructor SolverBaseClass
///
////////////////////////////////////////////////////////////////////////////////////
SolverSVD::SolverSVD(void) : SolverBaseClass()
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Default destructor for SolverSVD.
/// Implicitly calls SolverBaseClass destructor
///
////////////////////////////////////////////////////////////////////////////////////
SolverSVD::~SolverSVD(void)
{
}


////////////////////////////////////////////////////////////////////////////////////
///
/// Solves according to input parameters specified...
///
////////////////////////////////////////////////////////////////////////////////////
void SolverSVD::SolveMatrix()
{
	integer iM;
	integer iN;
	integer iRank, iInfo;
	doublereal dRCOND;

	integer iLWORK;
	integer iLDA, iLDB;
	integer iNRHS;

	doublecomplex* pcdMatrixA = NULL;
	doublecomplex* pcdTempPtr = NULL;
	doublecomplex* pcdMatrixB = NULL;
	doublecomplex* pcdWORK = NULL;
	doublereal* pdS = NULL;
	doublereal* pdRWORK = NULL;

	int iRowIndex, iColIndex;
	int iMatIndex, iIndex;

	// Initialize 'A' Matrix
	// No rotation needed.  Since A is a N * M matrix, with N << M, to the
	// zgelss function, it will be viewed as a M * N matrix, which will result
	// in a smaller B matrix size and faster output calculation
	
	// However, matrix A gets destroyed, therefore, create new matrix and copy...
	// This code needs cleanup, anticipated that methods can do either double or complex_double...

	pcdMatrixA = new doublecomplex[m_iRows * m_iCols];
	pcdTempPtr = (doublecomplex*) m_pdA;
	for(iRowIndex = 0; iRowIndex < m_iRows; iRowIndex++)
	{
		for(iColIndex = 0; iColIndex < m_iCols; iColIndex++)
		{
			iMatIndex = iRowIndex * m_iCols + iColIndex;
			pcdMatrixA[iMatIndex].r = pcdTempPtr[iMatIndex].r;
			pcdMatrixA[iMatIndex].i = pcdTempPtr[iMatIndex].i;
		}
	}

	
	iM = m_iCols;
	iN = m_iRows;
	iNRHS = iM;
	iLDA = iM;
	iLDB = iN;
	iLWORK = (2 * iN) + iM;
	dRCOND = -1.0;

	iInfo = 0;
	iRank = 0;

	// Initialize Complex B to Identity Matrix (critical)
	//pcdMatrixB = (doublecomplex*) malloc(sizeof(doublecomplex) * iNRHS * iLDB);
	pcdMatrixB = new doublecomplex[iNRHS * iLDB];

	for(iRowIndex = 0; iRowIndex < iNRHS; iRowIndex++)
	{
		for(iColIndex = 0; iColIndex < iLDB; iColIndex++)
		{
			iMatIndex = iRowIndex * iLDB + iColIndex;
			if(iRowIndex == iColIndex)
			{
				pcdMatrixB[iMatIndex].r = 1.0;
			}
			else
			{
				pcdMatrixB[iMatIndex].r = 0.0;
			}
			pcdMatrixB[iMatIndex].i = 0.0;
		}
	}

	// Singular values of A, dim = min(M, N)
	pdS = new doublereal[iM];
	//pdS = (doublereal*) malloc(sizeof(doublereal) * iM);

	// double workspace, dim = 5 * min(M, N)
	//pdRWORK = (doublereal*) malloc(sizeof(doublereal) * 5 * iN);
	pdRWORK = new doublereal[5 * iN];

	// complex double workspace, use first call of zgelss_ to compute.
	//pcdWORK = (doublecomplex*) malloc(sizeof(doublecomplex) * 2);
	pcdWORK = new doublecomplex[2];

	// Find Optimal LWORK...
	iLWORK = -1;
	zgelss_(&iM, &iN, &iNRHS, pcdMatrixA, &iLDA, pcdMatrixB, &iLDB, pdS,
			&dRCOND, &iRank, pcdWORK, &iLWORK, pdRWORK, &iInfo);


	iLWORK = (int) pcdWORK[0].r;
	//free(pcdWORK);
	//pcdWORK = (doublecomplex*) malloc(sizeof(doublecomplex) * iLWORK);
	delete [] pcdWORK;
	pcdWORK = new doublecomplex[iLWORK];

	// Initialize Workspace Matrices (may not be needed)...

	for(iIndex = 0; iIndex < iM; iIndex++)
	{
		pdS[iIndex] = 0.0;
	}

	for(iIndex = 0; iIndex < (5 * iN); iIndex++)
	{
		pdRWORK[iIndex] = 0.0;
	}

	for(iIndex = 0; iIndex < iLWORK; iIndex++)
	{
		pcdWORK[iIndex].r = 0.0;
		pcdWORK[iIndex].i = 0.0;
	}

	// Perform pseudo inverse
	zgelss_(&iM, &iN, &iNRHS, pcdMatrixA, &iLDA, pcdMatrixB, &iLDB, pdS,
			&dRCOND, &iRank, pcdWORK, &iLWORK, pdRWORK, &iInfo);


	//doublecomplex* pcdB = (doublecomplex*) m_pdB;
	//doublecomplex* pcdX = (doublecomplex*) m_pdX;
	// Multiply to get 'X'.
	// x = pinv(A) * b;
	//for(iColIndex = 0; iColIndex < m_iCols; iColIndex++)
	//{
	//	doublecomplex dSum;
	//	dSum.r = 0.0;
	//	dSum.i = 0.0;

	//	for(iRowIndex = 0; iRowIndex < m_iRows; iRowIndex++)
	//	{
	//		iMatIndex = iColIndex * m_iRows + iRowIndex;

	//		dSum.r += (pcdMatrixB[iMatIndex].r * pcdB[iRowIndex].r) -
	//				  (pcdMatrixB[iMatIndex].i * pcdB[iRowIndex].i);
	//		dSum.i += (pcdMatrixB[iMatIndex].r * pcdB[iRowIndex].i) +
	//				  (pcdMatrixB[iMatIndex].i * pcdB[iRowIndex].r);
	//	}

	//	pcdX[iColIndex].r = dSum.r;
	//	pcdX[iColIndex].i = dSum.i;
	//}
	MatrixMultiply(pcdMatrixB, m_iCols, m_iRows, (doublecomplex*) m_pdB, 1, (doublecomplex*) m_pdX);

	//free(pcdWORK);
	//free(pdRWORK);
	//free(pdS);
	//free(pcdMatrixB);
	SAFE_DELETE_ARRAY(pcdMatrixA);
	SAFE_DELETE_ARRAY(pcdWORK);
	SAFE_DELETE_ARRAY(pdRWORK);
	SAFE_DELETE_ARRAY(pdS);
	SAFE_DELETE_ARRAY(pcdMatrixB);

	return;
}

#if 0
////////////////////////////////////////////////////////////////////////////////////
///
/// Solves according to input parameters specified
///
////////////////////////////////////////////////////////////////////////////////////
void SolverSVD::SolveMatrixSVD()
{
	// Many CLAPACK parameters...
	doublecomplex* pcdARowColSwap;	
	integer iM = m_iRows;
	integer iN = m_iCols;
	integer iLDA = iM;
	doublereal* pdSMatrix;
	doublecomplex* pcdUMatrix;
	integer iLDU = iM;
	doublecomplex* pcdVTMatrix;
	integer iLDVT = iN;
	doublecomplex* pcdWork;
	integer iLWORK = 1;
	doublereal* pdRWork;
	integer iInfo = 0;

	// Make sure parameters are correct
	if(m_iRows < 1 || m_iCols < 1)
	{
		AfxMessageBox(_T("Invalid Matrix Sizes, exiting..."));
		return;
	}

	if(m_pdA == NULL || m_pdB == NULL || m_pdX == NULL)
	{
		AfxMessageBox(_T("Invalid Matrix Pointers, exiting..."));
		return;
	}

	
	// Swap Rows and Columns of 'A' matrix
	pcdARowColSwap = RowColumnSwap((doublecomplex*) m_pdA, m_iRows, m_iCols);
	
	// Allocate Other Matrices
	pdSMatrix = (doublereal*) malloc(sizeof(doublereal) * iM);
	pcdUMatrix = (doublecomplex*) malloc(sizeof(doublecomplex) * iM * iLDU);
	pcdVTMatrix = (doublecomplex*) malloc(sizeof(doublecomplex) * iN * iLDVT);
	pcdWork = (doublecomplex*) malloc(sizeof(doublecomplex) * iLWORK);
	pdRWork = (doublereal*) malloc(sizeof(doublereal) * 5 * iM); // suppose to be 5*min(M,N)

	// Initial Call to retrieve optimal workspace
	iLWORK = -1;
	zgesvd_("A", "A", &iM, &iN,
				   pcdARowColSwap, &iLDA, pdSMatrix, pcdUMatrix,
				   &iLDU, pcdVTMatrix, &iLDVT, pcdWork,
				   &iLWORK, pdRWork, &iInfo);


	// initialize workspace and recall
	iLWORK = (integer) pcdWork[0].r;
	free(pcdWork);
	pcdWork = (doublecomplex*) malloc(sizeof(doublecomplex) * iLWORK);

	zgesvd_("A", "A", &iM, &iN,
				   pcdARowColSwap, &iLDA, pdSMatrix, pcdUMatrix,
				   &iLDU, pcdVTMatrix, &iLDVT, pcdWork,
				   &iLWORK, pdRWork, &iInfo);


	free(pdRWork);
	free(pcdWork);
	free(pcdVTMatrix);
	free(pcdUMatrix);
	free(pdSMatrix);
	free(pcdARowColSwap);

	return;
}
#endif


////////////////////////////////////////////////////////////////////////////////////
///
/// Important for matrix solving
///
////////////////////////////////////////////////////////////////////////////////////
doublecomplex* SolverSVD::RowColumnSwap(doublecomplex* prgdcMatrix, int iRowLength, int iColumnLength)
{
	int iIndexRow, iIndexColumn;
	int iIndexInitial, iIndexFinal;
	doublecomplex* prgdcReturnMatrix;

	prgdcReturnMatrix = new doublecomplex[iRowLength * iColumnLength];

	for(iIndexRow = 0; iIndexRow < iRowLength; iIndexRow++)
	{
		for(iIndexColumn = 0; iIndexColumn < iColumnLength; iIndexColumn++)
		{
			iIndexInitial = (iIndexRow * iColumnLength) + iIndexColumn;
			iIndexFinal = (iIndexColumn * iRowLength) + iIndexRow;

			prgdcReturnMatrix[iIndexFinal].r = prgdcMatrix[iIndexInitial].r;
			prgdcReturnMatrix[iIndexFinal].i = prgdcMatrix[iIndexInitial].i;
		}
	}

	return prgdcReturnMatrix;
}
